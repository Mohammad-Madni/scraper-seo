{
    "id": "01190727-1132-0216-0000-20471ef6b2ff",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0246 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.allroofingservices.com.au/roof-replacement-abbotsford/",
        "target": "www.allroofingservices.com.au",
        "start_url": "https://www.allroofingservices.com.au/roof-replacement-abbotsford/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Abbotsford-(NSW)\\organic\\type-organic_rg1_ra4_allroofingservices.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:27:48 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "About ARS",
                                    "url": "https://www.allroofingservices.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/about-us/",
                                            "anchor_text": "About ARS"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Specialist",
                                    "url": "https://www.allroofingservices.com.au/roof-specialist/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-specialist/",
                                            "anchor_text": "Roof Specialist"
                                        }
                                    ]
                                },
                                {
                                    "text": "Know Your Rights",
                                    "url": "https://www.allroofingservices.com.au/know-your-rights/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/know-your-rights/",
                                            "anchor_text": "Know Your Rights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roof",
                                    "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                            "anchor_text": "Colorbond Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://www.allroofingservices.com.au/metal-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/metal-roof/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Plumbing",
                                    "url": "https://www.allroofingservices.com.au/roof-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-plumbing/",
                                            "anchor_text": "Roof Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Free Quote",
                                    "url": "https://www.allroofingservices.com.au/free-quote/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/free-quote/",
                                            "anchor_text": "Free Quote"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.allroofingservices.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Get a Free Quote",
                                    "url": "https://www.allroofingservices.com.au/free-quote/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/free-quote/",
                                            "anchor_text": "Get a Free Quote"
                                        }
                                    ]
                                },
                                {
                                    "text": "About ARS",
                                    "url": "https://www.allroofingservices.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/about-us/",
                                            "anchor_text": "About ARS"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Specialist",
                                    "url": "https://www.allroofingservices.com.au/roof-specialist/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-specialist/",
                                            "anchor_text": "Roof Specialist"
                                        }
                                    ]
                                },
                                {
                                    "text": "Know Your Rights",
                                    "url": "https://www.allroofingservices.com.au/know-your-rights/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/know-your-rights/",
                                            "anchor_text": "Know Your Rights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roof",
                                    "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                            "anchor_text": "Colorbond Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://www.allroofingservices.com.au/metal-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/metal-roof/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Plumbing",
                                    "url": "https://www.allroofingservices.com.au/roof-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-plumbing/",
                                            "anchor_text": "Roof Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Free Quote",
                                    "url": "https://www.allroofingservices.com.au/free-quote/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/free-quote/",
                                            "anchor_text": "Free Quote"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.allroofingservices.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "About ARS",
                                    "url": "https://www.allroofingservices.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/about-us/",
                                            "anchor_text": "About ARS"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Specialist",
                                    "url": "https://www.allroofingservices.com.au/roof-specialist/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-specialist/",
                                            "anchor_text": "Roof Specialist"
                                        }
                                    ]
                                },
                                {
                                    "text": "Know Your Rights",
                                    "url": "https://www.allroofingservices.com.au/know-your-rights/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/know-your-rights/",
                                            "anchor_text": "Know Your Rights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roof",
                                    "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                            "anchor_text": "Colorbond Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://www.allroofingservices.com.au/metal-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/metal-roof/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Plumbing",
                                    "url": "https://www.allroofingservices.com.au/roof-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-plumbing/",
                                            "anchor_text": "Roof Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Free Quote",
                                    "url": "https://www.allroofingservices.com.au/free-quote/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/free-quote/",
                                            "anchor_text": "Free Quote"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.allroofingservices.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Get a Free Quote",
                                    "url": "https://www.allroofingservices.com.au/free-quote/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/free-quote/",
                                            "anchor_text": "Get a Free Quote"
                                        }
                                    ]
                                },
                                {
                                    "text": "About ARS",
                                    "url": "https://www.allroofingservices.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/about-us/",
                                            "anchor_text": "About ARS"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Specialist",
                                    "url": "https://www.allroofingservices.com.au/roof-specialist/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-specialist/",
                                            "anchor_text": "Roof Specialist"
                                        }
                                    ]
                                },
                                {
                                    "text": "Know Your Rights",
                                    "url": "https://www.allroofingservices.com.au/know-your-rights/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/know-your-rights/",
                                            "anchor_text": "Know Your Rights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roof",
                                    "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                            "anchor_text": "Colorbond Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://www.allroofingservices.com.au/metal-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/metal-roof/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Plumbing",
                                    "url": "https://www.allroofingservices.com.au/roof-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-plumbing/",
                                            "anchor_text": "Roof Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Free Quote",
                                    "url": "https://www.allroofingservices.com.au/free-quote/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/free-quote/",
                                            "anchor_text": "Free Quote"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.allroofingservices.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "ARS are local roofing contractors owned and operated by Julian Dirou. Julian is a very experienced and licensed metal roof plumber who believes in doing things properly the first time, without short cuts and never compromising on quality.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Copyright \u00a9 2026 All Roofing Services",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "On Time And On Budget.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "We Never Compromise On Quality.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Fully Insured And Licensed.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "A Great Team Of Experienced, Friendly & Competent Roofers.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Free Inspections, Consultations And Quotes.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Voted Top Roofing Business For 3 Years.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roof",
                                    "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                            "anchor_text": "Colorbond Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://www.allroofingservices.com.au/metal-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/metal-roof/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "618 Parramatta Road,",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Croydon NSW 2132 Australia",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Office: 02 8086 2059",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Mobile: 0406 969 061",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "info@allroofingservices. com.au",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Website by Nasyana Marketing",
                                    "url": "https://www.nasyana.com.au/",
                                    "urls": [
                                        {
                                            "url": "https://www.nasyana.com.au/",
                                            "anchor_text": "Nasyana Marketing"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Premier Roof Replacements in Abbotsford",
                                "main_title": "Premier Roof Replacements in Abbotsford",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Welcome to All Roofing Services, your trusted roofing contractor in Abbotsford and Sydney. We specialize in providing premier roof replacements, including re-roofing and Colorbond roof replacements, to enhance the durability and aesthetics of your property. With a team of fully licensed and insured roofers, we offer top-quality services for both residential and commercial properties.",
                                        "url": "https://www.allroofingservices.com.au/roofing-contractors/",
                                        "urls": [
                                            {
                                                "url": "https://www.allroofingservices.com.au/roofing-contractors/",
                                                "anchor_text": "roofing contractor"
                                            },
                                            {
                                                "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                                "anchor_text": "roof replacements"
                                            },
                                            {
                                                "url": "https://www.allroofingservices.com.au/re-roofing/",
                                                "anchor_text": "re-roofing"
                                            },
                                            {
                                                "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                                "anchor_text": "Colorbond roof replacements"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs: Ensuring the Integrity of Your Roof",
                                "main_title": "Premier Roof Replacements in Abbotsford",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "In addition to roof replacements, we also prioritize roof repairs, maintenance, and leak repairs. Our experienced and friendly roofers are equipped to handle any repair job, addressing issues promptly to maintain the integrity of your roof and protect your property.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose All Roofing Services?",
                                "main_title": "Premier Roof Replacements in Abbotsford",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "When you choose All Roofing Services, you can expect:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Full Licensing and Insurance: We are a fully licensed and insured roofing contractor, providing you with peace of mind and assurance of our professionalism and adherence to industry standards.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "7-Year Workmanship Guarantee: We stand behind the quality of our workmanship and offer a comprehensive 7-year guarantee, ensuring that you receive long-lasting and reliable results.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Experienced and Friendly Roofers: Our team consists of experienced, friendly, and skilled roofers who are committed to delivering exceptional service. They prioritize customer satisfaction and work closely with you to meet your roofing needs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Free Inspections, Consultations, and Quotes: We offer complimentary roof inspections, consultations, and detailed quotes tailored to your specific requirements. This allows us to understand your needs better and provide transparent and accurate pricing.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Serving Abbotsford, Inner West, and Surrounding Areas",
                                "main_title": "Premier Roof Replacements in Abbotsford",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "While our main service area is Abbotsford and the Inner West, we also extend our exceptional services to surrounding areas in Sydney. Whether you are in Abbotsford or nearby locations, our team is ready to provide top-notch roof replacements and repairs for both residential and commercial properties.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recognized for Excellence",
                                "main_title": "Premier Roof Replacements in Abbotsford",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "All Roofing Services takes pride in being recognized as a premier roofing company for our commitment to excellence. We have been awarded for our reputation and professionalism, standing out among numerous Sydney roofing companies. This recognition reflects our dedication to delivering outstanding results and exceeding customer expectations.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Contact All Roofing Services Today",
                                "main_title": "Premier Roof Replacements in Abbotsford",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "If you are in need of a reliable roofing contractor in Abbotsford or Sydney, contact All Roofing Services today at 02 8086 2059. Our friendly team is available to schedule a free inspection, consultation, and quote for your roof replacement or repair needs. Trust us to provide you with a high-quality, durable, and visually appealing roof that will protect your property for years to come.",
                                        "url": "https://www.allroofingservices.com.au/contact-us/",
                                        "urls": [
                                            {
                                                "url": "https://www.allroofingservices.com.au/contact-us/",
                                                "anchor_text": "contact"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": null,
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "02 8086 2059",
                                "0406%20969%20061",
                                "0280862059"
                            ],
                            "emails": [
                                "info@allroofingservices.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}