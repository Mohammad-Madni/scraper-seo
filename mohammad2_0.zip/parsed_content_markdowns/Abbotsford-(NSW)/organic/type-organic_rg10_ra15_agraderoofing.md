{
    "id": "01190727-1132-0216-0000-282920827a9c",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0219 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.agraderoofing.com.au/locations/inner-west/abbotsford/",
        "target": "www.agraderoofing.com.au",
        "start_url": "https://www.agraderoofing.com.au/locations/inner-west/abbotsford/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Abbotsford-(NSW)\\organic\\type-organic_rg10_ra15_agraderoofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:27:50 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "About Us",
                                    "url": "https://www.agraderoofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.agraderoofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://www.agraderoofing.com.au/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://www.agraderoofing.com.au/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Eastern Suburbs",
                                    "url": "https://www.agraderoofing.com.au/locations/eastern-suburbs/",
                                    "urls": [
                                        {
                                            "url": "https://www.agraderoofing.com.au/locations/eastern-suburbs/",
                                            "anchor_text": "Eastern Suburbs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Inner West",
                                    "url": "https://www.agraderoofing.com.au/locations/inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://www.agraderoofing.com.au/locations/inner-west/",
                                            "anchor_text": "Inner West"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.agraderoofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.agraderoofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "I would definitely recommend Terry and his team, Terry conducted a proper inspection of our heavily leaking roof inclusive of photos, he provided us with a quote that my wife and I felt was fair and reasonable, the team carried out the work and provided us again with photos of the work completed. Importantly we have since had 2 major rain events and the roof has not leaked, my wife and I feel happy with our decision to go with Terry and the A grade roofing team.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Response from the owner: Thank you so much for the great review Noel.\nTerry",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Terry and the team did an excellent job replacing and repairing our roof. They were incredibly efficient. Always leaving the roof water tight after leaving. Three days and they were done clearing all rubbish and they even cleaned out the mutterings. Truly professional. I highly recommend AGrade roofing.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Response from the owner: Thank you Teresa for your excellent review.\nTerry",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Terry came and inspected the roof. He identified the issue and his team fixed it. After the job Terry sent through pictures and explained where the leak was coming from and how the repairs were completed. Great service and communication.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Response from the owner: Thank you for your great review. We appreciate the feedback and the excellent star rating.\nBest Regards",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "A-Grade are just that. Terry & Scotty and the team replaced our old tiled roof with a fantastic new Colorbond with sleek lines and and excellent attention to detail. We were kept informed along every step of the way and would highly recommend A-Grade for any work on replacement and repairs.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Response from the owner: Thanks for the great review Joe.\nTerry",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Wasn't able to help with my specific carpentary job but provided a lot of advice and guidance. Great service and honest!",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Response from the owner: Thanks for the review, glad i was able to help out with some useful info!.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Had a full roof replacement completed by Terry and his team which encompassed a duplex tile roof, front porch colourbond and rear extension colourbond roof all replaced including gutters. I can't speak more highly of Terry. He is honest, has clear communication and says it as it is. Having any work done can be stressful however Terry's attention to detail and willingness to ensure the customers demands are met, set him apart from the others. We are stoked to have had the work completed and it has held up after a few weeks of heavy rain. We love the new roof and no longer have to worry about leaks. Thanks Terry",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Response from the owner: Thanks so much for the review. Was a pleasure working with you and glad to hear you are happy with the final product.\nTerry",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Reliable, competitive and great customer service \u2b50\ufe0f\u2b50\ufe0f\u2b50\ufe0f\u2b50\ufe0f\u2b50\ufe0f",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Response from the owner: Thank you.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Terry did our roof last year and I've been very slack about doing this review.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "I liked working with Terry, he tells you how it is, what he's going to deliver and then delivers it. His team appear to have a very efficient approach to the work and it's impressive how quickly the old roof is removed and the new one fitted.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "We did have some follow on work that needed to be done and he was prompt in getting back and sorting out our issue.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Response from the owner: Thank you for that great feedback, much appreciated.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "I highly recommend Terry and the team at A Grade Roofing. My roof replacement was tricky with scaffolding both sides of the house. Terry co ordinated scaffolding, on-site skip, multiple delivery\u2019s as well as managing 2 teams of roofers and dealing with the ramifications of Mother Nature!",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "He managed to replace the roof within a week. He\u2019s organised, has a great attention to detail, good communications and a bloody good roofer. I sat on his wait list for 10 months until he could fit me in but it was worth the wait. Thrilled with my new roof!",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "A quick shout out to Terry, Scott and the team at A-Grade roofing who did a great job on our roof and gutter replacement.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Firstly, Terry was the only roofing expert who came out to provide a quote after the terrential rain in Sydney last year. He maintained contact with us despite the huge demand for his services and backlog of jobs. Terry, Scott and his team were always friendly, polite and professional in our dealings with them.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Secondly, the team did a great job installing a new roof and gutters for our Federation house, which was a complicated and at times messy job (i.e. rotten timbers that needed to be replaced etc.). We understood that the roof might not be 100% waterproof given the size and complexity of the job, however Terry and the team were quick to respond and fix a small leak that appeared after recent rain. This was reassuring, considering there are many roofing companies that won't respond once they've completed the job.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "I'd highly recommend A-Grade roofing if you are looking for a team you can trust to complete your job and follow up any enquiries in this difficult post-COVID environment.",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Based on 66 reviews",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Highly recommend",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Highly recommended",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Address : Ashfield, NSW 2131",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Roof Maintenance Services To Abbotsford",
                                "main_title": "Abbotsford Roof Restoration & Repair",
                                "author": "A-Grade Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "A-Grade Roofing is your local Abbotsford roofer. We offer a range of roofing services to ensure the roof above your head is performing at its optimum level. From leaking roofs to damaged downpipes, you can be reassured that every job completed by the team at A-Grade Roofing will leave your roof looking and feeling brand new. With over 26 years of experience, we know how important your roof is. They protect you, your family and your belongings from external factors. That\u2019s why we make sure we use only the best technology and treatment on your roof so you can be sure it will last you years. Improve the look and feel of your home with A-Grade Roofing.",
                                        "url": "https://www.agraderoofing.com.au/services/gutter-and-downpipe-repair-and-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://www.agraderoofing.com.au/services/gutter-and-downpipe-repair-and-replacement/",
                                                "anchor_text": "damaged downpipes"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Services",
                                "main_title": "Abbotsford Roof Restoration & Repair",
                                "author": "A-Grade Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "A-Grade Roofing offers a wide range of roofing services to the Abbotsford area. Whether your gutter is blocked or your tiles have been damaged during a thunderstorm, no job is too big or too small for our professionals.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs",
                                "main_title": "Abbotsford Roof Restoration & Repair",
                                "author": "A-Grade Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We fix any kind of roof including metal, terracotta, tiled, and slate roofs. Roofs go through tough weather conditions and that\u2019s why it\u2019s important to regularly check the condition of your roof and repair any damage as soon as possible. We also make emergency\u00a0roof repairs to those roofs that have been struck during a thunderstorm.",
                                        "url": "https://www.agraderoofing.com.au/services/roof-repair/",
                                        "urls": [
                                            {
                                                "url": "https://www.agraderoofing.com.au/services/roof-repair/",
                                                "anchor_text": "roof repairs"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Repairs",
                                        "url": "https://www.agraderoofing.com.au/services/roof-repair/",
                                        "urls": [
                                            {
                                                "url": "https://www.agraderoofing.com.au/services/roof-repair/",
                                                "anchor_text": "Roof Repairs"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Replacement",
                                "main_title": "Abbotsford Roof Restoration & Repair",
                                "author": "A-Grade Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "If your roof is in serious need of repair or maybe it just needs a fresh look. A-Grade Roofing will perform a\u00a0complete roof replacement to ensure there will be no more need for continuous roof repairs. It\u2019s better to have your\u00a0roof replaced than constantly repairing small issues over time.",
                                        "url": "https://www.agraderoofing.com.au/services/roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://www.agraderoofing.com.au/services/roof-replacement/",
                                                "anchor_text": "complete roof replacement"
                                            },
                                            {
                                                "url": "https://www.agraderoofing.com.au/services/roof-replacement/",
                                                "anchor_text": "roof replaced"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Replacement",
                                        "url": "https://www.agraderoofing.com.au/services/roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://www.agraderoofing.com.au/services/roof-replacement/",
                                                "anchor_text": "Roof Replacement"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration & Installation",
                                "main_title": "Abbotsford Roof Restoration & Repair",
                                "author": "A-Grade Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Although roofs are meant to be resilient against harsh weather conditions, over time they will crumble. Whether you have a residential, commercial or industrial property A-Grade Roofing will deliver your roof back to its original state.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Restoration & Installation",
                                        "url": "https://www.agraderoofing.com.au/services/roof-restoration-and-installation/",
                                        "urls": [
                                            {
                                                "url": "https://www.agraderoofing.com.au/services/roof-restoration-and-installation/",
                                                "anchor_text": "Roof Restoration & Installation"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter & Downpipe Replacement",
                                "main_title": "Abbotsford Roof Restoration & Repair",
                                "author": "A-Grade Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Gutters and downpipes are often overlooked, however, they play one of the most important parts in our roofing system. Any cracks or leaks can cause serious damage to the interior of your property. It\u2019s important to regularly have your\u00a0gutters and downpipes maintained.",
                                        "url": "https://www.agraderoofing.com.au/services/gutter-and-downpipe-repair-and-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://www.agraderoofing.com.au/services/gutter-and-downpipe-repair-and-replacement/",
                                                "anchor_text": "Gutters and downpipes"
                                            },
                                            {
                                                "url": "https://www.agraderoofing.com.au/services/gutter-and-downpipe-repair-and-replacement/",
                                                "anchor_text": "gutters and downpipes"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Gutter & Downpipe Replacement",
                                        "url": "https://www.agraderoofing.com.au/services/gutter-and-downpipe-repair-and-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://www.agraderoofing.com.au/services/gutter-and-downpipe-repair-and-replacement/",
                                                "anchor_text": "Gutter & Downpipe Replacement"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Slate Roof Repairs Abbotsford",
                                "main_title": "Abbotsford Roof Restoration & Repair",
                                "author": "A-Grade Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "A-Grade Roofing offers slate roof repairs across the Abbotsford. Slate roofs are highly durable and will suit any style of commercial or residential property. Slate roofs are especially common in Australia due to the harsh weather conditions our properties endure throughout the year. Slate roof repairs are what our team at A-Grade Roofing does best. A-Grade Roofing will replace your damaged slate roof tile with a brand new tile in no time.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Abbotsford Roof Restoration & Repair",
                                "main_title": "Abbotsford Roof Restoration & Repair",
                                "author": "A-Grade Roofing",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "If you notice your roof has been damaged or you would just like a general check up on your roof call A-Grade Roofing today and we will inspect your roof to ensure if any damage is found, the necessary steps are taken to resolve the issue.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Your Local Roofer Today!",
                                "main_title": "Abbotsford Roof Restoration & Repair",
                                "author": "A-Grade Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "A-Grade Roofing is your reliable and efficient Abbotsford roofer. We pride ourselves on being the first choice of roofing solutions in Sydney\u2019s Inner West. Our company focus is on our customers, with customer service at our core. Every job we perform is at the highest quality as we use only the latest technology to clean, repair and restore your roof. A-Grade Roofing provides guaranteed workmanship, which is supplied and installed by our dedicated and qualified roofers.",
                                        "url": "https://www.agraderoofing.com.au/locations/inner-west/",
                                        "urls": [
                                            {
                                                "url": "https://www.agraderoofing.com.au/locations/inner-west/",
                                                "anchor_text": "roofing solutions in Sydney\u2019s Inner West"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Whether your roof has broken tiles or your gutter is leaking or maybe you\u2019re just looking to renovate your home, A-Grade Roofing has what you need to ensure your roof will last you years. Our professionals have the necessary skills and technology to perform any job on your roof. We will always provide a solution that is right for you. If you\u2019re unsure, read our testimonials and see for yourself!",
                                        "url": "https://www.agraderoofing.com.au/services/roof-repair/",
                                        "urls": [
                                            {
                                                "url": "https://www.agraderoofing.com.au/services/roof-repair/",
                                                "anchor_text": "broken tiles"
                                            },
                                            {
                                                "url": "https://www.agraderoofing.com.au/testimonials/",
                                                "anchor_text": "read our testimonials"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "If you\u2019re looking for a roofer in Abbotsford, contact A-Grade Roofing today on\u00a00430 070 149 or email us at agraderoofing@icloud.com and one of our friendly team members will be more than happy to assist you with your roofing needs. Don\u2019t let that leaking roof get any worse, call us today.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Improve the look and feel of your home.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Abbotsford Roof Restoration & Repair",
                                "main_title": "Abbotsford Roof Restoration & Repair",
                                "author": "A-Grade Roofing",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Are you living in Abbotsford and need your roof maintained?",
                                "main_title": "Abbotsford Roof Restoration & Repair",
                                "author": "A-Grade Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "A-Grade Roofing can help.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We know your area and can reach you swiftly.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Get a Fast Quote Now!\u200b",
                                "main_title": "Abbotsford Roof Restoration & Repair",
                                "author": "A-Grade Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Name *",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Email *",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Your Message",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "+61 0430 070 149",
                                "0430 070 149"
                            ],
                            "emails": [
                                "agraderoofing@icloud.com"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}