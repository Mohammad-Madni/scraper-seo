{
    "id": "01190727-1132-0216-0000-682d3f0e3f83",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0177 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.yellowpages.com.au/nsw/abbotsford/factor-1-roofing-and-guttering-15258391-listing.html",
        "target": "www.yellowpages.com.au",
        "start_url": "https://www.yellowpages.com.au/nsw/abbotsford/factor-1-roofing-and-guttering-15258391-listing.html",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Abbotsford-(NSW)\\organic\\type-organic_rg13_ra18_yellowpages.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:27:45 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": null,
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Factor 1 Roofing And Guttering opening hours in Abbotsford",
                                "main_title": "Factor 1 Roofing And Guttering",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Explore similar businesses nearby",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Business Owners - Is Factor 1 Roofing And Guttering in Abbotsford, NSW your business?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Attract more customers by adding more content such as opening hours, logo and more",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Remove your competitors from this page",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "FIVE DOCK NSW 2046",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "0485 800 063",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Factor 1 Roofing And Guttering",
                                "main_title": "Factor 1 Roofing And Guttering",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Sorry, maps are currently unavailable",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Loading map...",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration & Repairs",
                                "main_title": "Factor 1 Roofing And Guttering",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs",
                                        "url": "https://www.yellowpages.com.au/find/roof-restoration-repairs/abbotsford-nsw-2046",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/find/roof-restoration-repairs/abbotsford-nsw-2046",
                                                "anchor_text": "Roof Restoration & Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0424 495 172",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Factor 1 Roofing And Guttering opening hours in Abbotsford",
                                "main_title": "Factor 1 Roofing And Guttering",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Products and Services",
                                "main_title": "Factor 1 Roofing And Guttering",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Choose the best business for the job.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "People Also Viewed",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Restoration & Repairs",
                                        "url": "https://www.yellowpages.com.au/find/roof-restoration-repairs/abbotsford-nsw-2046",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/find/roof-restoration-repairs/abbotsford-nsw-2046",
                                                "anchor_text": "Roof Restoration & Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration & Repairs",
                                        "url": "https://www.yellowpages.com.au/find/roof-restoration-repairs/abbotsford-nsw-2046",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/find/roof-restoration-repairs/abbotsford-nsw-2046",
                                                "anchor_text": "Roof Restoration & Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Acid Proofing",
                                        "url": "https://www.yellowpages.com.au/find/acid-proofing/abbotsford-nsw-2046",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/find/acid-proofing/abbotsford-nsw-2046",
                                                "anchor_text": "Acid Proofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Insulation Installers & Contractors",
                                        "url": "https://www.yellowpages.com.au/find/insulation-installers-contractors/abbotsford-nsw-2046",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/find/insulation-installers-contractors/abbotsford-nsw-2046",
                                                "anchor_text": "Insulation Installers & Contractors"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing Construction & Services",
                                        "url": "https://www.yellowpages.com.au/find/roofing-construction-services/abbotsford-nsw-2046",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/find/roofing-construction-services/abbotsford-nsw-2046",
                                                "anchor_text": "Roofing Construction & Services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Tiles",
                                        "url": "https://www.yellowpages.com.au/find/roof-tiles/abbotsford-nsw-2046",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/find/roof-tiles/abbotsford-nsw-2046",
                                                "anchor_text": "Roof Tiles"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Popular Categories",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Plumbers in Abbotsford",
                                        "url": "https://www.yellowpages.com.au/find/plumbers-gas-fitters/abbotsford-nsw-2046",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/find/plumbers-gas-fitters/abbotsford-nsw-2046",
                                                "anchor_text": "Plumbers in Abbotsford"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Electricians in Abbotsford",
                                        "url": "https://www.yellowpages.com.au/find/electricians-electrical-contractors/abbotsford-nsw-2046",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/find/electricians-electrical-contractors/abbotsford-nsw-2046",
                                                "anchor_text": "Electricians in Abbotsford"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Lawyers in Abbotsford",
                                        "url": "https://www.yellowpages.com.au/find/lawyers-solicitors/abbotsford-nsw-2046",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/find/lawyers-solicitors/abbotsford-nsw-2046",
                                                "anchor_text": "Lawyers in Abbotsford"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Pest Control in Abbotsford",
                                        "url": "https://www.yellowpages.com.au/find/pest-control/abbotsford-nsw-2046",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/find/pest-control/abbotsford-nsw-2046",
                                                "anchor_text": "Pest Control  in Abbotsford"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Mechanics in Abbotsford",
                                        "url": "https://www.yellowpages.com.au/find/mechanics-motor-engineers/abbotsford-nsw-2046",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/find/mechanics-motor-engineers/abbotsford-nsw-2046",
                                                "anchor_text": "Mechanics in Abbotsford"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Locksmiths in Abbotsford",
                                        "url": "https://www.yellowpages.com.au/find/locksmiths-locksmith-services/abbotsford-nsw-2046",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/find/locksmiths-locksmith-services/abbotsford-nsw-2046",
                                                "anchor_text": "Locksmiths in Abbotsford"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Concreters in Abbotsford",
                                        "url": "https://www.yellowpages.com.au/find/concrete-contractors/abbotsford-nsw-2046",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/find/concrete-contractors/abbotsford-nsw-2046",
                                                "anchor_text": "Concreters in Abbotsford"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Fencing Contractors in Abbotsford",
                                        "url": "https://www.yellowpages.com.au/find/fencing-contractors/abbotsford-nsw-2046",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/find/fencing-contractors/abbotsford-nsw-2046",
                                                "anchor_text": "Fencing Contractors in Abbotsford"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Builders in Abbotsford",
                                        "url": "https://www.yellowpages.com.au/find/builders-building-contractors/abbotsford-nsw-2046",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/find/builders-building-contractors/abbotsford-nsw-2046",
                                                "anchor_text": "Builders in Abbotsford"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Accountants in Abbotsford",
                                        "url": "https://www.yellowpages.com.au/find/accountants-auditors/abbotsford-nsw-2046",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/find/accountants-auditors/abbotsford-nsw-2046",
                                                "anchor_text": "Accountants in Abbotsford"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Find out more",
                                        "url": "https://www.yellowpages.com.au/quotes",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/quotes",
                                                "anchor_text": "Find out more"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Our directory.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "About Yellow Pages",
                                        "url": "https://www.yellowpages.com.au/pages/about-us",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/pages/about-us",
                                                "anchor_text": "About Yellow Pages"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Contact us",
                                        "url": "https://www.yellowpages.com.au/pages/contact-us",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/pages/contact-us",
                                                "anchor_text": "Contact us"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Site Index",
                                        "url": "https://www.yellowpages.com.au/sitemap",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/sitemap",
                                                "anchor_text": "Site Index"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Order or cancel your book",
                                        "url": "https://www.directoryselect.com.au/action/home",
                                        "urls": [
                                            {
                                                "url": "https://www.directoryselect.com.au/action/home",
                                                "anchor_text": "Order or cancel your book"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Terms of use",
                                        "url": "https://www.yellowpages.com.au/pages/terms-of-use",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/pages/terms-of-use",
                                                "anchor_text": "Terms of use"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Our advertising.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Get a free listing",
                                        "url": "https://my.yellow.com.au/online-signup/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://my.yellow.com.au/online-signup/?referrer=yp_footer",
                                                "anchor_text": "Get a free listing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Digital marketing solutions",
                                        "url": "https://www.yellow.com.au/products/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://www.yellow.com.au/products/?referrer=yp_footer",
                                                "anchor_text": "Digital marketing solutions"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Business hub",
                                        "url": "https://www.yellow.com.au/business-hub/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://www.yellow.com.au/business-hub/?referrer=yp_footer",
                                                "anchor_text": "Business hub"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "myYellow login",
                                        "url": "https://my.yellow.com.au/login/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://my.yellow.com.au/login/?referrer=yp_footer",
                                                "anchor_text": "myYellow login"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Connect with us.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Features",
                                "main_title": "Factor 1 Roofing And Guttering",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Insured, Licensed, Registered",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": [
                            {
                                "name": "Factor 1 Roofing And Guttering",
                                "price": 0,
                                "price_currency": null,
                                "price_valid_until": null
                            }
                        ],
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0424 495 172",
                                "0424495172",
                                "0485800063"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}