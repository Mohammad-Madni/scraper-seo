{
    "id": "01190727-1132-0216-0000-01e43908f1fd",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0205 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://sydneywideroofingco.com.au/inner-west/abbotsford/",
        "target": "sydneywideroofingco.com.au",
        "start_url": "https://sydneywideroofingco.com.au/inner-west/abbotsford/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Abbotsford-(NSW)\\organic\\type-organic_rg12_ra17_sydneywideroofingco.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:27:43 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Roof Repair",
                                    "url": "https://sydneywideroofingco.com.au/roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-repair/",
                                            "anchor_text": "Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://sydneywideroofingco.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Repair",
                                    "url": "https://sydneywideroofingco.com.au/roof-leak-repair/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-leak-repair/",
                                            "anchor_text": "Roof Leak Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutters and Downpipes",
                                    "url": "https://sydneywideroofingco.com.au/gutters-and-downpipes/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/gutters-and-downpipes/",
                                            "anchor_text": "Gutters and Downpipes"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://sydneywideroofingco.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Tile Pointing and Bedding",
                                    "url": "https://sydneywideroofingco.com.au/roof-tile-pointing-bedding/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-tile-pointing-bedding/",
                                            "anchor_text": "Roof Tile Pointing and Bedding"
                                        }
                                    ]
                                },
                                {
                                    "text": "Copper Roofing",
                                    "url": "https://sydneywideroofingco.com.au/copper-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/copper-roofing/",
                                            "anchor_text": "Copper Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roofing",
                                    "url": "https://sydneywideroofingco.com.au/slate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/slate-roofing/",
                                            "anchor_text": "Slate Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Zinc Roofing",
                                    "url": "https://sydneywideroofingco.com.au/zinc-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/zinc-roofing/",
                                            "anchor_text": "Zinc Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Roofing",
                                    "url": "https://sydneywideroofingco.com.au/heritage-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/heritage-roofing/",
                                            "anchor_text": "Heritage Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sutherland Shire",
                                    "url": "https://sydneywideroofingco.com.au/sutherland-shire/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/sutherland-shire/",
                                            "anchor_text": "Sutherland Shire"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs in Randwick NSW",
                                    "url": "https://sydneywideroofingco.com.au/randwick/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/randwick/",
                                            "anchor_text": "Roof Repairs in Randwick NSW"
                                        }
                                    ]
                                },
                                {
                                    "text": "Eastern Suburbs",
                                    "url": "https://sydneywideroofingco.com.au/eastern-suburbs/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/eastern-suburbs/",
                                            "anchor_text": "Eastern Suburbs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Georges River",
                                    "url": "https://sydneywideroofingco.com.au/georges-river/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/georges-river/",
                                            "anchor_text": "Georges River"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sydney Inner West Roof Repairs",
                                    "url": "https://sydneywideroofingco.com.au/inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/inner-west/",
                                            "anchor_text": "Sydney Inner West Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "City of Sydney",
                                    "url": "https://sydneywideroofingco.com.au/city-of-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/city-of-sydney/",
                                            "anchor_text": "City of Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Northern Beaches",
                                    "url": "https://sydneywideroofingco.com.au/northern-beaches/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/northern-beaches/",
                                            "anchor_text": "Northern Beaches"
                                        }
                                    ]
                                },
                                {
                                    "text": "North Sydney",
                                    "url": "https://sydneywideroofingco.com.au/north-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/north-sydney/",
                                            "anchor_text": "North Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "GET QUOTE",
                                    "url": "https://sydneywideroofingco.com.au/get-quote/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/get-quote/",
                                            "anchor_text": "GET QUOTE"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "95 Bellingara Rd, Miranda NSW 2228.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Monday \u2013 Saturday: 7:00 AM \u2013 6:00 PM",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "(02) 8294 4654",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Safeguarding Your Abbotsford Property with Sydney Wide Roofing Co.",
                                "main_title": "Roofing Abbotsford",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "In the face of Australia\u2019s challenging climate, roofing solutions are essential to shield your Abbotsford home or business. Sydney Wide Roofing Co has emerged as the leading choice in the region, a testament to our unwavering dedication to excellence. Our adept team comprehends that a robust roof isn\u2019t just a protective layer but a significant investment in your property\u2019s future. With our extensive experience, we\u2019ve mastered roofing craftsmanship, ensuring every task underscores our commitment and dependability. Whether it\u2019s roofing repairs or installations, we\u2019re your partner in delivering the best roofing Abbotsford services, ensuring durability and confidence.",
                                        "url": "https://maps.app.goo.gl/JujS9N8xd5nB4uKJA",
                                        "urls": [
                                            {
                                                "url": "https://maps.app.goo.gl/JujS9N8xd5nB4uKJA",
                                                "anchor_text": "Abbotsford"
                                            },
                                            {
                                                "url": "https://sydneywideroofingco.com.au/",
                                                "anchor_text": "Sydney Wide Roofing Co"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Sydney Wide Roofing Co. proudly offers an expansive array of high-calibre roofing services tailored to meet your unique needs. With our seasoned professionals and a relentless pursuit of perfection, we assure unmatched solutions for your roofing endeavours. Here\u2019s a snapshot of what we bring to the table:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Roofing Services",
                                "main_title": "Roofing Abbotsford",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "As the reliable choice for all roofing undertakings in Abbotsford, we emphasise impeccable workmanship, lasting solutions, and client satisfaction. Our suite of services encompasses:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Replacement Abbotsford",
                                "main_title": "Roofing Abbotsford",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "When repair isn\u2019t an option, or your roof is nearing its end, our proficient crew ensures a smooth transition to a new one. Our roofing renewal promises not only aesthetic enhancement but robust defense against weather extremities. With over three decades of proficiency, Sydney Wide Roofing Co stands as the go-to experts in Abbotsford for tile, metal, colorbond, corrugated iron, and skylight renewals. We specialize in comprehensive roof renewal for both residential and commercial spaces.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Replacement Abbotsford",
                                        "url": "https://sydneywideroofingco.com.au/roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/roof-replacement/",
                                                "anchor_text": "Roof Replacement Abbotsford"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Installs Abbotsford",
                                "main_title": "Roofing Abbotsford",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Be it a new construction or an extension, our adept Abbotsford roofing specialists are equipped to manage installations, ensuring longevity and resilience.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Installs Abbotsford",
                                        "url": "https://sydneywideroofingco.com.au/roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/roof-replacement/",
                                                "anchor_text": "Roof Installs Abbotsford"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs Abbotsford",
                                "main_title": "Roofing Abbotsford",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Prompt interventions for roofing issues are pivotal. Our team excels in identifying and rectifying various challenges, from punctures to structural anomalies. Tell-tale signs include interior leaks, exterior water marks, moss or mould accumulation, or debris in your rainwater system.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Repairs Abbotsford",
                                        "url": "https://sydneywideroofingco.com.au/roof-repair/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/roof-repair/",
                                                "anchor_text": "Roof Repairs Abbotsford"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Leak Repairs in Abbotsford",
                                "main_title": "Roofing Abbotsford",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "With our seasoned expertise, we not only address leaks but guide on preventive strategies and suitable accessories to thwart future issues. Our methodical approach at Sydney Wide Roofing Co assures effective and enduring leak solutions. Be it due to extreme weather conditions or wear and tear, we are equipped to address diverse challenges.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Leak Repairs in Abbotsford",
                                        "url": "https://sydneywideroofingco.com.au/roof-leak-repair/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/roof-leak-repair/",
                                                "anchor_text": "Roof Leak Repairs in Abbotsford"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration Abbotsford",
                                "main_title": "Roofing Abbotsford",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "A roof in decent shape, but looking weary, can be rejuvenated. We engage in comprehensive cleansing, rectifications, and sealing to prolong its durability while uplifting its appeal. Our revamp solutions are tailored, considering your budget constraints, ensuring you get the most value.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Restoration Abbotsford",
                                        "url": "https://sydneywideroofingco.com.au/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/roof-restoration/",
                                                "anchor_text": "Roof Restoration Abbotsford"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Tile Repointing and Repointing Abbotsford",
                                "main_title": "Roofing Abbotsford",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Tiles can show signs of wear, affecting your property\u2019s safety. Our meticulous realignment ensures fortified protection, countering potential threats of loose or deteriorated tiles.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Tile Repointing and Repointing Abbotsford",
                                        "url": "https://sydneywideroofingco.com.au/gutters-and-downpipes/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/gutters-and-downpipes/",
                                                "anchor_text": "Roof Tile Repointing and Repointing Abbotsford"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose Us?",
                                "main_title": "Roofing Abbotsford",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Our reputation in Abbotsford is grounded on multiple pillars that make us stand out:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Rich Industry Know-how Our deep-seated experience is a cornerstone that clients value. We\u2019ve built our expertise over the years, refining our skills and gathering knowledge that benefits our clientele.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Intrinsic Connection to Abbotsford We are woven into the fabric of Abbotsford. Our team\u2019s intrinsic understanding of the locale ensures services that resonate with the spirit and essence of the region.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Unyielding Dedication to Client Contentment Our mantra revolves around client satisfaction. We focus on nurturing long-standing relationships, ensuring transparency and responsiveness in every interaction.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Staunch Commitment to Craftsmanship Each task is a showcase of our dedication, meticulousness, and passion, ensuring outcomes that speak volumes about our quality.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "For unparalleled roofing solutions in Leichhardt, reach out to Sydney Wide Roofing Co:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Abbotsford Roofing Insights",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Abbotsford, nestled in Sydney, Australia, is an enchanting enclave celebrated for its riveting vistas and waterside charm. For those looking at roofing solutions in Abbotsford, it\u2019s imperative to factor in local nuances and regulations.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Abbotsford, a vibrant precinct, features attractions like the Abbotsford Cove and heritage landmarks, reflecting its rich lineage. It houses prominent suburbs and offers myriad recreational options.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Local Roofing Directives Adherence to Abbotsford-specific roofing norms, set by the local council, is paramount:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Material & Style : Heritage zones may have stipulations to maintain aesthetic consistency.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Bushfire Measures : Using fire-resistant materials and other safety mechanisms is critical.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Rainwater Management : Efficient drainage systems prevent property damage.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Permit Necessities : Ensure alignment with local council guidelines for compliance.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sustainable Practices : Incorporation of green materials and methods may be emphasised.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Local Architectural Influence : Recognise and respect local architectural styles.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Entrust Sydney Wide Roofing Co with your roofing endeavours in Abbotsford. Our commitment ensures your peace of mind, prioritising unparalleled quality and service.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Contact Us Today",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Phone \u2013 (02) 8503 4416",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Email \u2013 [email\u00a0protected]",
                                        "url": "https://sydneywideroofingco.com.au/cdn-cgi/l/email-protection",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/cdn-cgi/l/email-protection",
                                                "anchor_text": "[email\u00a0protected]"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Website \u2013 https://sydneywideroofingco.com.au/",
                                        "url": "https://sydneywideroofingco.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/",
                                                "anchor_text": "https://sydneywideroofingco.com.au/"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roofing Abbotsford",
                                "main_title": "Roofing Abbotsford",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repair Abbotsford \u2013 Sydney Wide Roofing Co",
                                "main_title": "Roofing Abbotsford",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter Replacement Abbotsford",
                                "main_title": "Roofing Abbotsford",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Essential for channelling rainwater, we cater to installations, upkeep, and fixes for gutters and downpipes, ensuring your property\u2019s shield remains intact.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Gutter Replacement Abbotsford",
                                        "url": "https://sydneywideroofingco.com.au/gutters-and-downpipes/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/gutters-and-downpipes/",
                                                "anchor_text": "Gutter Replacement Abbotsford"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Highly Rated Roofing Company servicing Leichhardt, Inner West",
                                "main_title": "Roofing Abbotsford",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "For all your roofing needs, reach out to us today.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Contact Information",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "You can contact Sydney Wide Roofing Co \u2013 Leichhardt at the following:",
                                        "url": "https://maps.app.goo.gl/GZKPfLyAtY3H1Afn9",
                                        "urls": [
                                            {
                                                "url": "https://maps.app.goo.gl/GZKPfLyAtY3H1Afn9",
                                                "anchor_text": "Sydney Wide Roofing Co \u2013 Leichhardt"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Phone \u2013 (02) 8503 4416",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Email \u2013 [email\u00a0protected]",
                                        "url": "https://sydneywideroofingco.com.au/cdn-cgi/l/email-protection",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/cdn-cgi/l/email-protection",
                                                "anchor_text": "[email\u00a0protected]"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Website \u2013 https://sydneywideroofingco.com.au/",
                                        "url": "https://sydneywideroofingco.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/",
                                                "anchor_text": "https://sydneywideroofingco.com.au/"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Portfolio",
                                "main_title": "Roofing Abbotsford",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Burraneer Bay Residential",
                                "main_title": "Roofing Abbotsford",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Burraneer Bay Residential",
                                        "url": "https://sydneywideroofingco.com.au/portfolio-items/burraneer-bay-roofing-project/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/portfolio-items/burraneer-bay-roofing-project/",
                                                "anchor_text": "Burraneer Bay Residential"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Slate Roofing Project Sydney",
                                "main_title": "Roofing Abbotsford",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Slate Roofing Project Sydney",
                                        "url": "https://sydneywideroofingco.com.au/portfolio-items/slate-roofing-project-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/portfolio-items/slate-roofing-project-sydney/",
                                                "anchor_text": "Slate Roofing Project Sydney"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Roofing Project Eastern Suburbs",
                                "main_title": "Roofing Abbotsford",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Metal Roofing Project Eastern Suburbs",
                                        "url": "https://sydneywideroofingco.com.au/portfolio-items/metal-roofing-project-eastern-suburbs/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/portfolio-items/metal-roofing-project-eastern-suburbs/",
                                                "anchor_text": "Metal Roofing Project Eastern Suburbs"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Handy Tips About Roofing",
                                "main_title": "Roofing Abbotsford",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repair",
                                "main_title": "Roofing Abbotsford",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Repair",
                                        "url": "https://sydneywideroofingco.com.au/tips-proper-roof-repair/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/tips-proper-roof-repair/",
                                                "anchor_text": "Roof Repair"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Leaks",
                                "main_title": "Roofing Abbotsford",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Leaks",
                                        "url": "https://sydneywideroofingco.com.au/how-to-fix-a-roof-leak/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/how-to-fix-a-roof-leak/",
                                                "anchor_text": "Roof Leaks"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration",
                                "main_title": "Roofing Abbotsford",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Restoration",
                                        "url": "https://sydneywideroofingco.com.au/time-for-roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/time-for-roof-restoration/",
                                                "anchor_text": "Roof Restoration"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Re-roofing",
                                "main_title": "Roofing Abbotsford",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Re-roofing",
                                        "url": "https://sydneywideroofingco.com.au/tips-for-re-roofing-roof-installs/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/tips-for-re-roofing-roof-installs/",
                                                "anchor_text": "Re-roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gutters & Downpipes",
                                "main_title": "Roofing Abbotsford",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Gutters & Downpipes",
                                        "url": "https://sydneywideroofingco.com.au/tips-on-gutter-down-pipe-repair/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/tips-on-gutter-down-pipe-repair/",
                                                "anchor_text": "Gutters & Downpipes"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Tiling",
                                "main_title": "Roofing Abbotsford",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Tiling",
                                        "url": "https://sydneywideroofingco.com.au/roof-tile-repair/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/roof-tile-repair/",
                                                "anchor_text": "Roof Tiling"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Locations We Service",
                                "main_title": "Roofing Abbotsford",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Sutherland Shire",
                                        "url": "https://sydneywideroofingco.com.au/sutherland-shire/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/sutherland-shire/",
                                                "anchor_text": "Sutherland Shire"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Eastern Suburbs",
                                        "url": "https://sydneywideroofingco.com.au/eastern-suburbs/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/eastern-suburbs/",
                                                "anchor_text": "Eastern Suburbs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Georges River",
                                        "url": "https://sydneywideroofingco.com.au/georges-river/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/georges-river/",
                                                "anchor_text": "Georges River"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Inner West",
                                        "url": "https://sydneywideroofingco.com.au/inner-west/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/inner-west/",
                                                "anchor_text": "Inner West"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Northern Beaches",
                                        "url": "https://sydneywideroofingco.com.au/northern-beaches/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/northern-beaches/",
                                                "anchor_text": "Northern Beaches"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Lane Cove",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "North Sydney",
                                        "url": "https://sydneywideroofingco.com.au/north-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/north-sydney/",
                                                "anchor_text": "North Sydney"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Heritage Roofing",
                                "main_title": "Roofing Abbotsford",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Heritage Roofing",
                                        "url": "https://sydneywideroofingco.com.au/services/heritage-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/services/heritage-roofing/",
                                                "anchor_text": "Heritage Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Copper Roofing",
                                "main_title": "Roofing Abbotsford",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Copper Roofing",
                                        "url": "https://sydneywideroofingco.com.au/services/copper-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/services/copper-roofing/",
                                                "anchor_text": "Copper Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Slate Roofing",
                                "main_title": "Roofing Abbotsford",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Slate Roofing",
                                        "url": "https://sydneywideroofingco.com.au/services/slate-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/services/slate-roofing/",
                                                "anchor_text": "Slate Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Zinc Roofing",
                                "main_title": "Roofing Abbotsford",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Zinc Roofing",
                                        "url": "https://sydneywideroofingco.com.au/services/zinc-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/services/zinc-roofing/",
                                                "anchor_text": "Zinc Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Locations in the Inner West Council We Service",
                                "main_title": "Roofing Abbotsford",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Dulwich Hill",
                                        "url": "https://sydneywideroofingco.com.au/inner-west/dulwich-hill/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/inner-west/dulwich-hill/",
                                                "anchor_text": "Dulwich Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Russell Lea",
                                        "url": "https://sydneywideroofingco.com.au/inner-west/russell-lea/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/inner-west/russell-lea/",
                                                "anchor_text": "Russell Lea"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Five Dock",
                                        "url": "https://sydneywideroofingco.com.au/inner-west/five-dock/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/inner-west/five-dock/",
                                                "anchor_text": "Five Dock"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Rodd Point",
                                        "url": "https://sydneywideroofingco.com.au/inner-west/rodd-point/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/inner-west/rodd-point/",
                                                "anchor_text": "Rodd Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Summer Hill",
                                        "url": "https://sydneywideroofingco.com.au/inner-west/summer-hill/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/inner-west/summer-hill/",
                                                "anchor_text": "Summer Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Canada Bay",
                                        "url": "https://sydneywideroofingco.com.au/inner-west/canada-bay/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/inner-west/canada-bay/",
                                                "anchor_text": "Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Building Inspiring Roofs",
                                "main_title": "Roofing Abbotsford",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Only takes a few seconds!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "61282944654",
                                "+61282944654",
                                "+61285034416"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}