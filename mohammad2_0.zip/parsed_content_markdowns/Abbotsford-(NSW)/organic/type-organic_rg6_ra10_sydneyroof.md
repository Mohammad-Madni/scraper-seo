{
    "id": "01190727-1132-0216-0000-4011dfa0262d",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0219 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://sydneyroof.com.au/service-area/abbotsford/",
        "target": "sydneyroof.com.au",
        "start_url": "https://sydneyroof.com.au/service-area/abbotsford/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Abbotsford-(NSW)\\organic\\type-organic_rg6_ra10_sydneyroof.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:27:47 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Request a Quote",
                                    "url": "https://sydneyroof.com.au/request-a-quote/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroof.com.au/request-a-quote/",
                                            "anchor_text": "Request a Quote"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gallery 1",
                                    "url": "https://sydneyroof.com.au/portfolio/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroof.com.au/portfolio/",
                                            "anchor_text": "Gallery 1"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gallery 2",
                                    "url": "https://sydneyroof.com.au/gallery-2/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroof.com.au/gallery-2/",
                                            "anchor_text": "Gallery 2"
                                        }
                                    ]
                                },
                                {
                                    "text": "All Roofing Services",
                                    "url": "https://sydneyroof.com.au/roofing-service/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroof.com.au/roofing-service/",
                                            "anchor_text": "All Roofing Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Sydney",
                                    "url": "https://sydneyroof.com.au/?page_id=224304",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroof.com.au/?page_id=224304",
                                            "anchor_text": "Roof Repairs Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Domestic Roofing Info",
                                    "url": "https://sydneyroof.com.au/domestic-residential-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroof.com.au/domestic-residential-roofing/",
                                            "anchor_text": "Domestic Roofing Info"
                                        }
                                    ]
                                },
                                {
                                    "text": "Industrial Roofing Info",
                                    "url": "https://sydneyroof.com.au/commercial-industrial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroof.com.au/commercial-industrial-roofing/",
                                            "anchor_text": "Industrial Roofing Info"
                                        }
                                    ]
                                },
                                {
                                    "text": "Job Pics",
                                    "url": "https://sydneyroof.com.au/portfolio/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroof.com.au/portfolio/",
                                            "anchor_text": "Job Pics"
                                        }
                                    ]
                                },
                                {
                                    "text": "Service Area Sydney",
                                    "url": "https://sydneyroof.com.au/service-area/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroof.com.au/service-area/",
                                            "anchor_text": "Service Area Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://sydneyroof.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroof.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Job Pics & Info",
                                    "url": "https://sydneyroof.com.au/portfolio/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroof.com.au/portfolio/",
                                            "anchor_text": "Job Pics & Info"
                                        }
                                    ]
                                },
                                {
                                    "text": "FAQ \u2013 Roofing",
                                    "url": "https://sydneyroof.com.au/faq/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroof.com.au/faq/",
                                            "anchor_text": "FAQ \u2013 Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://sydneyroof.com.au/privacy-policy/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroof.com.au/privacy-policy/",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "SydneyRoof - 1300-170-090",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Abbotsford \u2013 Surrounded by Water",
                                "main_title": "Abbotsford NSW 2046, Australia",
                                "author": "Roof Repair Sydney - Metal roof repair, Tile roof reapir",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Abbotsford is a relatively small suburb located in the Inner West metropolitan area. According to a 2011 census, Abbotsford has a population of 5,112 people. It is governed by the local government area of the City of Canada Bay.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Surrounding suburbs include Henley, Cabarita, Chiswick, Five Dock, Wareemba, Russell Lea, and Gladesville. This New South Wales suburb has an interesting origin and opportunities for exciting sports and recreation activities.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Origin and Demographics, and Public Transportation",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Abbotsford, originally Feltham, was first recognized as a European settlement in 1837. According to Place-names of New South Wales, It got its name from doctor and politician Sir Authur Renwick, who owned the land that would later become the Abbotsford suburbs. Renwick was the original inhabitant of the famed Abbotsford House. In 1903, Renwick sold the property, and it was repurposed as a Nestle chocolate factory, which remained until 1991.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Colorbond Roofing \u2013 Free Quotes >",
                                "main_title": "Abbotsford NSW 2046, Australia",
                                "author": "Roof Repair Sydney - Metal roof repair, Tile roof reapir",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Abbotsford NSW",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Australians born residents dominate the demographics in Abbotsford, making up over 65 percent of the population. Other countries with notable born-presences in Abbotsford include Italy and England. Abbotsford is a predominantly Catholic region, with nearly half of its inhabitants identifying with Catholicism.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Abbotsford provides public transportation in the form of ferries and buses. The Parramatta River ferry services can be accessed from Abbotsford. Access to the Sydney Bus system is also available in Abbotsford. Abbotsford has an interesting history, a modest population, and a reliable public transportation system.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sports, Recreation, and Leisure",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "As for sports, Abbotsford is known for rowing and sailing. Abbotsford hoses a number of rowing sheds for high schools and colleges in the area. Schools include Newington College and Sydney High School. Abbotsford is also home to the Sydney Rowing Club, which is the oldest rowing club in New South Wales.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sailing is a popular form of recreation in Abbotsford. The suburb even has its own sailing club, The Abbotsford Sailing Club. The Abbotsford sailing club offers sailing classes to prepare residents for sailing.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Other recreational and leisurely activities in Abbotsford included cycling tracks, swimming pools, and bushwalking tracks. Shopping is available in Abbotsford with group shops on Great North Road. Residents enjoy the vast opportunities of sports, recreation, and leisure available in Abbotsford.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Interesting Facts",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Although it is a modest suburb, more than one of its residents achieved fame. Poet Henry Lawson. Lawson is a famed poet and even was featured on the Australian ten-dollar note. David Hicks, famous for his struggles while being detained in Guantanamo Bay, was also from Abbotsford. Hicks had a play wrote of his life, called X-Ray.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Abbotsford is a Sydney suburb with an interesting history that offers many opportunities for sports and leisure. It has housed famous residents such as Henry Lawson and David Hicks. It provides public transportation in the form of ferries and buses. It is a beacon of rowing and sailing in Sydney. The Abbotsford suburb in Sydney is a great place to call home.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Colorbond Roofing \u2013 Free Quotes >",
                                        "url": "https://sydneyroof.com.au/request-a-quote/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyroof.com.au/request-a-quote/",
                                                "anchor_text": "Colorbond Roofing \u2013 Free Quotes >"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Tell Us About Your Project",
                                "main_title": "Abbotsford NSW 2046, Australia",
                                "author": "Roof Repair Sydney - Metal roof repair, Tile roof reapir",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Fill in your details below and we will book a time for a free onsite inspection and quote",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "[gravityform id=\u201d1\u2033 title=\u201dfalse\u201d description=\u201dfalse\u201d ajax=\u201dtrue\u201d]",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Abbotsford NSW 2046, Australia",
                                "main_title": "Abbotsford NSW 2046, Australia",
                                "author": "Roof Repair Sydney - Metal roof repair, Tile roof reapir",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney Roof Service Area Abbotsford NSW 2046, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Abbotsford NSW 2046, Australia",
                                "main_title": "Abbotsford NSW 2046, Australia",
                                "author": "Roof Repair Sydney - Metal roof repair, Tile roof reapir",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Roofing Sydney \u2013 Request a Free Quote > >",
                                "main_title": "Abbotsford NSW 2046, Australia",
                                "author": "Roof Repair Sydney - Metal roof repair, Tile roof reapir",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Metal Roofing Sydney \u2013 Request a Free Quote > >",
                                        "url": "https://sydneyroof.com.au/request-a-quote/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyroof.com.au/request-a-quote/",
                                                "anchor_text": "Metal Roofing Sydney \u2013 Request a Free Quote > >"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Sydney Roof \u2013 Service Area",
                                "main_title": "Abbotsford NSW 2046, Australia",
                                "author": "Roof Repair Sydney - Metal roof repair, Tile roof reapir",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "SYDNEY ROOF LOCATIONS",
                                "main_title": "Abbotsford NSW 2046, Australia",
                                "author": "Roof Repair Sydney - Metal roof repair, Tile roof reapir",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "PADSTOW: 24 Curzon Rd, Padstow Heights, NSW, AU",
                                        "url": "https://maps.google.com/maps?cid=14518983816328799883&hl=en&_ga=2.254651979.298694568.1505795147-370615116.1503538216",
                                        "urls": [
                                            {
                                                "url": "https://maps.google.com/maps?cid=14518983816328799883&hl=en&_ga=2.254651979.298694568.1505795147-370615116.1503538216",
                                                "anchor_text": "PADSTOW:\u00a024 Curzon Rd, Padstow Heights, NSW, AU"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "CROWS NEST: 44 Huntington Street, Crows Nest, NSW, AU",
                                        "url": "https://maps.google.com/maps?cid=8170836184339282873&hl=en&_ga=2.213787095.298694568.1505795147-370615116.1503538216",
                                        "urls": [
                                            {
                                                "url": "https://maps.google.com/maps?cid=8170836184339282873&hl=en&_ga=2.213787095.298694568.1505795147-370615116.1503538216",
                                                "anchor_text": "CROWS NEST:\u00a044 Huntington Street, Crows Nest, NSW, AU"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "KINGSFORD: 170a Botany Street, Kingsford, NSW, AU",
                                        "url": "https://maps.google.com/maps?cid=10472414722849761560&hl=en&_ga=2.183283173.298694568.1505795147-889170095.1499606710",
                                        "urls": [
                                            {
                                                "url": "https://maps.google.com/maps?cid=10472414722849761560&hl=en&_ga=2.183283173.298694568.1505795147-889170095.1499606710",
                                                "anchor_text": "KINGSFORD:\u00a0170a Botany Street, Kingsford, NSW, AU"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "+1300170090"
                            ],
                            "emails": [
                                "info@sydneyroof.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}