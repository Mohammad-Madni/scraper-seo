{
    "id": "01191205-1132-0216-0000-ce98fec992d5",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0109 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://innercityplumbing.com.au/locations/abbotsford/roof-plumber",
        "target": "innercityplumbing.com.au",
        "start_url": "https://innercityplumbing.com.au/locations/abbotsford/roof-plumber",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "enable_javascript": true,
        "switch_pool": false,
        "load_resources": false,
        "enable_browser_rendering": false,
        "enable_xhr": false,
        "disable_cookie_popup": false,
        "browser_preset": "desktop",
        "tag": "parsed_content_markdowns\\Abbotsford-(NSW)\\organic\\type-organic_rg20_ra26_innercityplumbing.md"
    },
    "result": [
        {
            "crawl_progress": "in_progress",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 0
            },
            "items_count": 0,
            "items": null
        }
    ]
}