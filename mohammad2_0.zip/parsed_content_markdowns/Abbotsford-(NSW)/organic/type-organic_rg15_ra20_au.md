{
    "id": "01190727-1132-0216-0000-3006b6d5bf62",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0180 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://au.nextdoor.com/pages/inveria-roofing-abbotsford-nsw/",
        "target": "au.nextdoor.com",
        "start_url": "https://au.nextdoor.com/pages/inveria-roofing-abbotsford-nsw/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Abbotsford-(NSW)\\organic\\type-organic_rg15_ra20_au.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 0
            },
            "items_count": 0,
            "items": null
        }
    ]
}