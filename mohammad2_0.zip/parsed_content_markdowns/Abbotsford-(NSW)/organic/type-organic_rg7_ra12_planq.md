{
    "id": "01191136-1132-0216-0000-33d52ee084d7",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0138 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.planq.com.au/categories/roofing/new-south-wales/abbotsford",
        "target": "planq.com.au",
        "start_url": "https://www.planq.com.au/categories/roofing/new-south-wales/abbotsford",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "enable_javascript": true,
        "switch_pool": false,
        "load_resources": false,
        "enable_browser_rendering": false,
        "enable_xhr": false,
        "disable_cookie_popup": false,
        "browser_preset": "desktop",
        "tag": "parsed_content_markdowns\\Abbotsford-(NSW)\\organic\\type-organic_rg7_ra12_planq.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 07:37:02 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "List Your Business",
                                    "url": "https://www.planq.com.au/list-your-business",
                                    "urls": [
                                        {
                                            "url": "https://www.planq.com.au/list-your-business",
                                            "anchor_text": "List Your Business"
                                        }
                                    ]
                                },
                                {
                                    "text": "List Your Business",
                                    "url": "https://www.planq.com.au/list-your-business",
                                    "urls": [
                                        {
                                            "url": "https://www.planq.com.au/list-your-business",
                                            "anchor_text": "List Your Business"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "\u00a9 2025 Planq. All rights reserved.",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Help Center",
                                    "url": "https://www.planq.com.au/help-center",
                                    "urls": [
                                        {
                                            "url": "https://www.planq.com.au/help-center",
                                            "anchor_text": "Help Center"
                                        }
                                    ]
                                },
                                {
                                    "text": "Safety Tips",
                                    "url": "https://www.planq.com.au/safety-tips",
                                    "urls": [
                                        {
                                            "url": "https://www.planq.com.au/safety-tips",
                                            "anchor_text": "Safety Tips"
                                        }
                                    ]
                                },
                                {
                                    "text": "List Your Business",
                                    "url": "https://www.planq.com.au/list-your-business",
                                    "urls": [
                                        {
                                            "url": "https://www.planq.com.au/list-your-business",
                                            "anchor_text": "List Your Business"
                                        }
                                    ]
                                },
                                {
                                    "text": "Business Resources",
                                    "url": "https://www.planq.com.au/business-resources",
                                    "urls": [
                                        {
                                            "url": "https://www.planq.com.au/business-resources",
                                            "anchor_text": "Business Resources"
                                        }
                                    ]
                                },
                                {
                                    "text": "Success Stories",
                                    "url": "https://www.planq.com.au/success-stories",
                                    "urls": [
                                        {
                                            "url": "https://www.planq.com.au/success-stories",
                                            "anchor_text": "Success Stories"
                                        }
                                    ]
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://www.planq.com.au/privacy-policy",
                                    "urls": [
                                        {
                                            "url": "https://www.planq.com.au/privacy-policy",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terms of Service",
                                    "url": "https://www.planq.com.au/terms-of-service",
                                    "urls": [
                                        {
                                            "url": "https://www.planq.com.au/terms-of-service",
                                            "anchor_text": "Terms of Service"
                                        }
                                    ]
                                },
                                {
                                    "text": "Cookie Policy",
                                    "url": "https://www.planq.com.au/cookie-policy",
                                    "urls": [
                                        {
                                            "url": "https://www.planq.com.au/cookie-policy",
                                            "anchor_text": "Cookie Policy"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Find trusted Service in Abbotsford, New South Wales",
                                "main_title": "Find trusted Service in Abbotsford, New South Wales",
                                "author": "Planq",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Chat with our AI assistant to explain your service needs in plain words. Get instant clarity on costs, timelines, and what to expect\u2014before providers even call.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Hi \ud83d\udc4b I can help you find the best Service in Abbotsford, New South Wales. How can I help?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I need service for my project",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Here's what you can expect:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Planq Assistant",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Service Service",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Why choose local Service in Abbotsford",
                                "main_title": "Find trusted Service in Abbotsford, New South Wales",
                                "author": "Planq",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Connect with trusted local professionals who understand Abbotsford's unique needs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Less travel means more time on your job.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Flexible scheduling and competitive call-out.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Local suppliers and parts reduce delays.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Lower travel times",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Better availability",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Right first time",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Typical costs",
                                "main_title": "Find trusted Service in Abbotsford, New South Wales",
                                "author": "Planq",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Tell us about your job to get accurate quotes in .",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Prices vary by job scope and access.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Ready to find service in Abbotsford?",
                                "main_title": "Find trusted Service in Abbotsford, New South Wales",
                                "author": "Planq",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Get quotes from verified professionals in your area.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Local availability & service reach",
                                "main_title": "Find trusted Service in Abbotsford, New South Wales",
                                "author": "Planq",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Service coverage in",
                                "main_title": "Find trusted Service in Abbotsford, New South Wales",
                                "author": "Planq",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Coverage depends on job size and timing.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How to find the best service in Abbotsford",
                                "main_title": "Find trusted Service in Abbotsford, New South Wales",
                                "author": "Planq",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Describe your job",
                                "main_title": "Find trusted Service in Abbotsford, New South Wales",
                                "author": "Planq",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Tell us what you need done and we'll create a detailed brief.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Get matched with providers",
                                "main_title": "Find trusted Service in Abbotsford, New South Wales",
                                "author": "Planq",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We'll connect you with qualified professionals in your area.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Compare quotes & choose",
                                "main_title": "Find trusted Service in Abbotsford, New South Wales",
                                "author": "Planq",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Review quotes and select the provider that's right for you.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "+61-8-8166-0608"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}