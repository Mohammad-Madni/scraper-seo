{
    "id": "01190727-1132-0216-0000-d67ddbb9705d",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0172 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://sydneytileroofpainting.com.au/suburbs/roof-repairs-abbotsford/",
        "target": "sydneytileroofpainting.com.au",
        "start_url": "https://sydneytileroofpainting.com.au/suburbs/roof-repairs-abbotsford/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Abbotsford-(NSW)\\organic\\type-organic_rg14_ra19_sydneytileroofpainting.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:27:47 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "About Us",
                                    "url": "https://sydneytileroofpainting.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/roof-painting-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/roof-painting-sydney/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/roof-leak-detection/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/roof-leak-detection/",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Condition Reports",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/roof-condition-reports/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/roof-condition-reports/",
                                            "anchor_text": "Roof Condition Reports"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repair",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/roof-repair/",
                                            "anchor_text": "Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Flat Metal Roofing",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/flat-metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/flat-metal-roofing/",
                                            "anchor_text": "Flat Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Asbestos Roof Removal",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/asbestos-roof-removal/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/asbestos-roof-removal/",
                                            "anchor_text": "Asbestos Roof Removal"
                                        }
                                    ]
                                },
                                {
                                    "text": "Solar Pigeon Proofing",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/solar-pigeon-proofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/solar-pigeon-proofing/",
                                            "anchor_text": "Solar Pigeon Proofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/gutter-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/gutter-cleaning/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/roof-repointing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/roof-repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Asbestos Roof Removal",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/asbestos-roof-removal/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/asbestos-roof-removal/",
                                            "anchor_text": "Asbestos Roof Removal"
                                        }
                                    ]
                                },
                                {
                                    "text": "Flat Metal Roofing",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/flat-metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/flat-metal-roofing/",
                                            "anchor_text": "Flat Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/roof-painting-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/roof-painting-sydney/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repair",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/roof-repair/",
                                            "anchor_text": "Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Condition Reports",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/roof-condition-reports/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/roof-condition-reports/",
                                            "anchor_text": "Roof Condition Reports"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/roof-leak-detection/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/roof-leak-detection/",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Solar Pigeon Proofing",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/solar-pigeon-proofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/solar-pigeon-proofing/",
                                            "anchor_text": "Solar Pigeon Proofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/gutter-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/gutter-cleaning/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/roof-repointing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/roof-repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "What Are The Consequences Of Not Fixing A Leaking Roof?",
                                    "url": "https://sydneytileroofpainting.com.au/what-are-the-consequences-of-not-fixing-a-leaking-roof/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/what-are-the-consequences-of-not-fixing-a-leaking-roof/",
                                            "anchor_text": "What Are The Consequences Of Not Fixing A Leaking Roof?"
                                        }
                                    ]
                                },
                                {
                                    "text": "How Can You Make Sure Your Metal Roof Is Properly Flashed?",
                                    "url": "https://sydneytileroofpainting.com.au/how-can-you-make-sure-your-metal-roof-is-properly-flashed/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/how-can-you-make-sure-your-metal-roof-is-properly-flashed/",
                                            "anchor_text": "How Can You Make Sure Your Metal Roof Is Properly Flashed?"
                                        }
                                    ]
                                },
                                {
                                    "text": "Why Is Metal Roofing Better Than Other Roofing Materials?",
                                    "url": "https://sydneytileroofpainting.com.au/why-is-metal-roofing-better-than-other-roofing-materials/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/why-is-metal-roofing-better-than-other-roofing-materials/",
                                            "anchor_text": "Why Is Metal Roofing Better Than Other Roofing Materials?"
                                        }
                                    ]
                                },
                                {
                                    "text": "What Are The Causes Of A Roof Leak?",
                                    "url": "https://sydneytileroofpainting.com.au/what-are-the-causes-of-a-roof-leak/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/what-are-the-causes-of-a-roof-leak/",
                                            "anchor_text": "What Are The Causes Of A Roof Leak?"
                                        }
                                    ]
                                },
                                {
                                    "text": "What Happens If Your Roof Leaks Around A Vent Pipe?",
                                    "url": "https://sydneytileroofpainting.com.au/what-happens-if-your-roof-leaks-around-a-vent-pipe/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/what-happens-if-your-roof-leaks-around-a-vent-pipe/",
                                            "anchor_text": "What Happens If Your Roof Leaks Around A Vent Pipe?"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://sydneytileroofpainting.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://sydneytileroofpainting.com.au/privacy-policy/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/privacy-policy/",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Call: 0492 000 020",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "\u00a9 [y] Sydney Tile Roof Painting by Nifty Marketing Australia",
                                    "url": "https://sydneytileroofpainting.com.au/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/",
                                            "anchor_text": "Sydney Tile Roof Painting"
                                        },
                                        {
                                            "url": "https://niftymarketing.com.au/",
                                            "anchor_text": "Nifty Marketing Australia"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Professional Tile Roof Repair Services In Abbotsford",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": "Sydney Tile Roof Painting",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Tile roofs are beautiful but require specialised care to maintain functionality and appearance. At Sydney Tile Roof Painting, our services are designed to extend the life of your roof while maintaining its aesthetic appeal. We provide high-quality repairs and maintenance to ensure your roof is functional and enhances your property\u2019s overall value.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Expert leak detection and fixes",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Replacement of cracked or missing tiles",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Cleaning and resealing to protect tiles from weather damage",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ridge capping repairs to prevent water ingress",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our tile roof repair services are centred around long-term durability and aesthetic appeal. Contact us today to protect your tile roof\u2019s beauty and integrity, so it can continue to safeguard your home for years.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "We offer:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Abbotsford\u2019s Trusted Roofing Repairs",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": "Sydney Tile Roof Painting",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "If you\u2019re looking for Abbotsford roofing repairs, look no further than Sydney Tile Roof Painting. We provide expert roofing solutions to safeguard your home from the weather. Here\u2019s what we offer when you choose us:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fast response times for emergency repairs, minimising interruptions.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Comprehensive inspections to identify possible issues early, keeping expensive repairs at bay.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Repairs tailored to your roofing material, delivering exact and proven results.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Long-lasting results using only the best materials to give you confidence in lasting durability.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ensuring durable and resilient roofs for Abbotsford homeowners is our top priority at Sydney Tile Roof Painting. Our team\u2019s dedication and skill guarantee weatherproof solutions. Don\u2019t let minor issues escalate\u2014contact us now for trusted roofing repairs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Roof Repair Services In Abbotsford",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": "Sydney Tile Roof Painting",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Metal roofs are highly durable, but like all roofing materials, they may face issues over time. Sydney Tile Roof Painting offers expert metal roofing repair services to maintain your roof\u2019s performance.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our team removes rust and corrosion, safeguarding your roof\u2019s structure. We fix or replace broken panels, keeping your roof functional and secure. To avoid leaks, we seal gaps, preventing water damage. With expert repainting, we enhance your roof\u2019s appearance and durability. High-quality materials and skilled techniques ensure long-lasting performance.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Depend on Sydney Tile Roof Painting for metal roof repair that\u2019s affordable, reliable, and guaranteed to deliver great results.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Abbotsford\u2019s Reliable Emergency Roof Repairs",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": "Sydney Tile Roof Painting",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Your roof can sustain unexpected damage anytime. Count on Sydney Tile Roof Painting for prompt and trustworthy roof emergency repair services. We offer:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Immediate attention to leaks or storm damage.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Temporary fixes to minimise further damage.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Comprehensive evaluations to identify and address underlying issues.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Assistance with insurance claims for a hassle-free experience.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our experienced team is committed to delivering fast, efficient, and effective emergency roof repairs. When you need immediate and trustworthy roof repairs, rely on Sydney Tile Roof Painting to get your home protected again. Contact us today for prompt service!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs Abbotsford",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": "Sydney Tile Roof Painting",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Providing high-quality roof repair services at unbeatable rates across local communities such as:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Repairs Chiswick, Roof Repairs Wareemba",
                                        "url": "https://sydneytileroofpainting.com.au/suburbs/roof-repairs-chiswick/",
                                        "urls": [
                                            {
                                                "url": "https://sydneytileroofpainting.com.au/suburbs/roof-repairs-chiswick/",
                                                "anchor_text": "Roof Repairs Chiswick"
                                            },
                                            {
                                                "url": "https://sydneytileroofpainting.com.au/suburbs/roof-repairs-wareemba/",
                                                "anchor_text": "Roof Repairs Wareemba"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "What Is The Process Of Boarding A Roof Repair Specialist At Abbotsford?",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": "Sydney Tile Roof Painting",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "We\u2019ve designed our roof repair process to be smooth, transparent, and free of stress. From beginning to end, we make sure you\u2019re kept in the loop and happy with the results. This is how it works:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Initial inspection to identify all issues.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Detailed cost estimate with no hidden fees.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Scheduling repairs at a convenient time for you.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Completing repairs with high-quality workmanship.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Final inspection to ensure your satisfaction.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our roof repairs are seamless and stress-free. Sydney Tile Roof Painting guarantees professional, reliable, and transparent service.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Frequently Asked Questions",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": "Sydney Tile Roof Painting",
                                "language": "en",
                                "level": 5,
                                "primary_content": [
                                    {
                                        "text": "What is the typical duration for a roof repair job?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "For minor repairs, expect 1\u20132 days of work, while larger repairs may extend to a week.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Are emergency roof repairs available in Abbotsford?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yes, we specialise in urgent roof repairs for all locations in Abbotsford.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "What kind of materials are used for tile roof repairs?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our repairs use high-grade tiles and sealants that blend seamlessly with your current roof.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Can you replace damaged metal roofing?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yes, we provide services to repair or replace damaged metal roofing.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "What are the average roof repair costs in Abbotsford?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof repair costs can vary based on the damage and materials required. Contact us for a complimentary estimate.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roof Repairs Abbotsford",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": "Sydney Tile Roof Painting",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Preserving the integrity of your roof is essential for protecting your home from unpredictable weather. Sydney Tile Roof Painting provides dependable roof repairs in Abbotsford NSW, 2046. From small leaks to large damages, we make sure your roof remains sturdy and visually appealing. Our expert team works promptly, using premium materials to restore your roof\u2019s functionality and increase its longevity.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "With a wealth of experience in all roofing repairs, we are committed to keeping your home safe and secure.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Submit Your Details for a FREE Inspection & Quote",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "OPTIONAL: You may upload some images to describe your enquiry",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Our Reviews",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose Sydney Tile Roof Painting As Your Roof Repairer?",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": "Sydney Tile Roof Painting",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Here\u2019s why customers trust Sydney Tile Roof Painting for their roof repairs & maintenance needs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "With over a decade in the business, we have established a reputation for excellent service. We use only the finest materials and practice detailed craftsmanship to make sure every repair is perfect. Our team is well-known for being dependable, providing clear communication and punctuality, so you are always informed. In addition, we offer a warranty, ensuring long-lasting results.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "When you choose us, you\u2019re partnering with the best for all roofing repairs in the area.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "OPTIONAL: You may upload some images to describe your enquiry",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Best Pricing",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "7 Days",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Top Quality Paints",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "10 Yr Warranty",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 5,
                                "max_rating_value": 5,
                                "rating_count": 1289,
                                "relative_rating": 1
                            }
                        ],
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0492 000 020",
                                "+61 492 000 020"
                            ],
                            "emails": [
                                "info@sydneytileroofpainting.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}