# Type: people_also_ask | Rank: 11 | RG: 1
### Raw Row Data:
{
    "rank_group": "1",
    "rank_absolute": "11",
    "service": "roofer",
    "suburb": "Abbotsford (NSW)",
    "title": "",
    "domain": "",
    "url": "",
    "description": "",
    "type": "people_also_ask"
}