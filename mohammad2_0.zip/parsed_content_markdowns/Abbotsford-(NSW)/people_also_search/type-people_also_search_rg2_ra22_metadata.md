# Type: people_also_search | Rank: 22 | RG: 2
### Raw Row Data:
{
    "rank_group": "2",
    "rank_absolute": "22",
    "service": "roofer",
    "suburb": "Abbotsford (NSW)",
    "title": "People also search for",
    "domain": "",
    "url": "",
    "description": "",
    "type": "people_also_search"
}