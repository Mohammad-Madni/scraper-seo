# Type: local_pack | Rank: 2 | RG: 2
### Raw Row Data:
{
    "rank_group": "2",
    "rank_absolute": "2",
    "service": "roofer",
    "suburb": "Abbotsford (NSW)",
    "title": "Abbotsford Tough Roofing",
    "domain": "www.google.com",
    "url": "https://www.google.com/viewer/place?sca_esv=ed956a20e7b48028&hl=en&gl=AU&output=search&mid=/g/11whdz1mnb&pip=Cgtyb29mZXIgTlNXKRAC",
    "description": "Closed \u00b7 Abbotsford, BC, Canada",
    "type": "local_pack"
}