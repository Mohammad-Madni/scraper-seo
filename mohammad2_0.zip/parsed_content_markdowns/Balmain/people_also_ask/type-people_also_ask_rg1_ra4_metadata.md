# Type: people_also_ask | Rank: 4 | RG: 1
### Raw Row Data:
{
    "rank_group": "1",
    "rank_absolute": "4",
    "service": "roofer",
    "suburb": "Balmain",
    "title": "",
    "domain": "",
    "url": "",
    "description": "",
    "type": "people_also_ask"
}