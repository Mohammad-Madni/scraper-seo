{
    "id": "01190727-1132-0216-0000-1b518574c153",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0212 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://sparrowroofing.com.au/f/balmain-courtyard-roof-timber-and-gutter-replacement?blogcategory=Gutter",
        "target": "sparrowroofing.com.au",
        "start_url": "https://sparrowroofing.com.au/f/balmain-courtyard-roof-timber-and-gutter-replacement?blogcategory=Gutter",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Balmain\\organic\\type-organic_rg17_ra22_sparrowroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:10 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Pictorial Blog",
                                    "url": "https://sparrowroofing.com.au/pictorial-blog",
                                    "urls": [
                                        {
                                            "url": "https://sparrowroofing.com.au/pictorial-blog",
                                            "anchor_text": "Pictorial Blog"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://sparrowroofing.com.au/contact-us",
                                    "urls": [
                                        {
                                            "url": "https://sparrowroofing.com.au/contact-us",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pictorial Blog",
                                    "url": "https://sparrowroofing.com.au/pictorial-blog",
                                    "urls": [
                                        {
                                            "url": "https://sparrowroofing.com.au/pictorial-blog",
                                            "anchor_text": "Pictorial Blog"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://sparrowroofing.com.au/contact-us",
                                    "urls": [
                                        {
                                            "url": "https://sparrowroofing.com.au/contact-us",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pictorial Blog",
                                    "url": "https://sparrowroofing.com.au/pictorial-blog",
                                    "urls": [
                                        {
                                            "url": "https://sparrowroofing.com.au/pictorial-blog",
                                            "anchor_text": "Pictorial Blog"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://sparrowroofing.com.au/contact-us",
                                    "urls": [
                                        {
                                            "url": "https://sparrowroofing.com.au/contact-us",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Roofing Specialists",
                                "main_title": "SPARROW ROOFING - Inner West Roofing specialists",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Welcome to Sparrow Roofing, where fresh, modern expertise meets timeless craftsmanship.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Nestled in the vibrant Inner West Sydney, we specialise in delivering high-quality roofing services, repairs and unparalleled workmanship tailored to exceed your expectations.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our customer-centric approach ensures that every interaction is focused on guaranteeing a seamless experience from consultation to completion.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We will elevate your roofing experience to new heights.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our mission is to ensure that every roof we install or repair provides the utmost protection and longevity, keeping our clients homes and businesses safe and secure for years to come.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Add our roofing skills to your next project.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What we do",
                                "main_title": "SPARROW ROOFING - Inner West Roofing specialists",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "With expertise spanning metal and tile roofing for both new installations and repairs, we cater to all your roofing needs, regardless of age or scale.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our skilled team boasts a proven track record of successful repairs and collaborates closely with homeowners and designers to deliver exceptional results consistently.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Explore our work for insights into our recent projects.",
                                        "url": "https://sparrowroofing.com.au/gallery",
                                        "urls": [
                                            {
                                                "url": "https://sparrowroofing.com.au/gallery",
                                                "anchor_text": "our work"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Why choose us?",
                                "main_title": "SPARROW ROOFING - Inner West Roofing specialists",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "As a licensed and qualified roofing specialist company, we prioritise meticulous attention to detail and strive to ensure clarity regarding the scope of work for your project's successful completion.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Regularly updated, this webpage serves as a direct point of contact with our experienced roofing specialists, ensuring a seamless and personalised customer experience.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "SPARROW ROOFING - Inner West Roofing specialists",
                                "main_title": "SPARROW ROOFING - Inner West Roofing specialists",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Pictorial Blog",
                                "main_title": "SPARROW ROOFING - Inner West Roofing specialists",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Project gallery",
                                "main_title": "SPARROW ROOFING - Inner West Roofing specialists",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "In Connection With:",
                                "main_title": "SPARROW ROOFING - Inner West Roofing specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "SPARROW ROOFING - Inner West Roofing specialists",
                                "main_title": "SPARROW ROOFING - Inner West Roofing specialists",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Copyright \u00a9 2026 Sparrow Roofing - All Rights Reserved.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Powered by",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Socials",
                                "main_title": "SPARROW ROOFING - Inner West Roofing specialists",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": null
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}