{
    "id": "01190727-1132-0216-0000-c3f8b35229a4",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0332 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://sydneyslateroofing.com.au/sydney-roofing-testamonials/jaimie-balmain/",
        "target": "sydneyslateroofing.com.au",
        "start_url": "https://sydneyslateroofing.com.au/sydney-roofing-testamonials/jaimie-balmain/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Balmain\\organic\\type-organic_rg16_ra21_sydneyslateroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:15 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": null,
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Experienced traditional and contemporary slate roofing specialists in Sydney",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "\u00a9 2007 \u2014 2026 The Sydney Slate Roofing Co. Designed by Red Ant Media",
                                    "url": "https://www.redantmedia.com.au/",
                                    "urls": [
                                        {
                                            "url": "https://www.redantmedia.com.au/",
                                            "anchor_text": "Red Ant Media"
                                        }
                                    ]
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Slate Roof Installation, Repair and Maintenance",
                                    "url": "https://sydneyslateroofing.com.au/sydney-slate-roofing-services/slate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyslateroofing.com.au/sydney-slate-roofing-services/slate-roofing/",
                                            "anchor_text": "Slate Roof Installation, Repair and Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Timber Shingle Roof Installation, Repair and Maintenance",
                                    "url": "https://sydneyslateroofing.com.au/sydney-slate-roofing-services/timber-shingle-roofs/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyslateroofing.com.au/sydney-slate-roofing-services/timber-shingle-roofs/",
                                            "anchor_text": "Timber Shingle Roof Installation, Repair and Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Shingle Roof Roof Installation, Repair and Maintenance",
                                    "url": "https://sydneyslateroofing.com.au/sydney-slate-roofing-services/tile-shingle-roofs/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyslateroofing.com.au/sydney-slate-roofing-services/tile-shingle-roofs/",
                                            "anchor_text": "Tile Shingle Roof Roof Installation, Repair and Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Roof Installation, Repair and Maintenance",
                                    "url": "https://sydneyslateroofing.com.au/sydney-slate-roofing-services/heritage-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyslateroofing.com.au/sydney-slate-roofing-services/heritage-roofing/",
                                            "anchor_text": "Heritage Roof Installation, Repair and Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sydney Roof Repairs",
                                    "url": "https://sydneyslateroofing.com.au/sydney-slate-roofing-services/sydney-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyslateroofing.com.au/sydney-slate-roofing-services/sydney-roof-repairs/",
                                            "anchor_text": "Sydney Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Guttering and Downpipes",
                                    "url": "https://sydneyslateroofing.com.au/sydney-slate-roofing-services/guttering-and-downpipes/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyslateroofing.com.au/sydney-slate-roofing-services/guttering-and-downpipes/",
                                            "anchor_text": "Guttering and Downpipes"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://sydneyslateroofing.com.au/about-sydney-slate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyslateroofing.com.au/about-sydney-slate-roofing/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://sydneyslateroofing.com.au/contact-sydney-slate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyslateroofing.com.au/contact-sydney-slate-roofing/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "The Best Traditional and Contemporary Slate Roofing Specialists in Sydney",
                                "main_title": "Sydney Slate Roofing",
                                "author": null,
                                "language": null,
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "For new roof installations, re-roofing, roof repairs and roof maintenance of slate roofs, tile shingle roofs, timber shingle roofs and guttering and downpipes call Jeff at Sydney Slate Roofing on 0409 100 164 for a roofing quote today.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Sydney Slate Roofing - Experienced Professional Roofers",
                                "main_title": "Sydney Slate Roofing",
                                "author": null,
                                "language": null,
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Sydney Slate Roofing are Sydney's leading licenced slate roof specialists with over 30 years experience in slate, tiles, metal and colorbond roofs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Experienced Roofers",
                                "main_title": "Sydney Slate Roofing",
                                "author": null,
                                "language": null,
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney Slate Roofing is owned and managed by Jeff Brett, whose 30 years of experience in the roofing industry covers all aspects of roofing, from heritage projects through to modern contemporary projects.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Licenced Roofers",
                                "main_title": "Sydney Slate Roofing",
                                "author": null,
                                "language": null,
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney Slate Roofing are fully licenced NSW Roofing Contractors (NSW LIC. 152806C) and Jeff and his team always deliver consistent, quality workmanship on every roof, every time, without compromise.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "All Roofing Services",
                                "main_title": "Sydney Slate Roofing",
                                "author": null,
                                "language": null,
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney Slate Roofing don't just specialise in slate roofs. Sydney Slate Roofing can install new roofs, re-roof, and provide roof repairs and roof maintenance for timber shingle, tile shingle and heritage roofs too!!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Sydney Roofing Projects",
                                "main_title": "Sydney Slate Roofing",
                                "author": null,
                                "language": null,
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Recent roofing projects by Sydney Slate Roofing",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "View all of the Sydney Slate Roofing Company's recent roofing projects here",
                                        "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/",
                                                "anchor_text": "here"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Sydney Roofing Projects",
                                        "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/",
                                                "anchor_text": "Sydney Roofing Projects"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Recycled Welsh Slate. Balmain Sydney NSW",
                                "main_title": "Sydney Slate Roofing",
                                "author": null,
                                "language": null,
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Recycled Welsh Slate Roof by the Sydney Slate Roofing Company in Balmain, Sydney NSW",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Recycled Welsh Slate. Balmain Sydney NSW",
                                        "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/recycled-welsh-slate-balmain-sydney-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/recycled-welsh-slate-balmain-sydney-nsw/",
                                                "anchor_text": "Recycled Welsh Slate. Balmain Sydney NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "View Project",
                                        "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/recycled-welsh-slate-balmain-sydney-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/recycled-welsh-slate-balmain-sydney-nsw/",
                                                "anchor_text": "View Project"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Welsh Slate Roof, Vaucluse Sydney NSW",
                                "main_title": "Sydney Slate Roofing",
                                "author": null,
                                "language": null,
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Welsh Slate Roof in Vaucluse Sydney NSW, by the Sydney Slate Roofing Company, with terracotta ridge cappings and finials.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Welsh Slate Roof, Vaucluse Sydney NSW",
                                        "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/welsh-slate-roof-vaucluse-sydney-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/welsh-slate-roof-vaucluse-sydney-nsw/",
                                                "anchor_text": "Welsh Slate Roof, Vaucluse Sydney NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "View Project",
                                        "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/welsh-slate-roof-vaucluse-sydney-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/welsh-slate-roof-vaucluse-sydney-nsw/",
                                                "anchor_text": "View Project"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Heritage Slate Roof. St Thomas Church. Enfield Sydney NSW",
                                "main_title": "Sydney Slate Roofing",
                                "author": null,
                                "language": null,
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Heritage slate roofing project, by the Sydney Slate Roofing Company, St Thomas Church.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Heritage Slate Roof. St Thomas Church. Enfield Sydney NSW",
                                        "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/heritage-slate-roof-st-thomas-church-enfield-sydney-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/heritage-slate-roof-st-thomas-church-enfield-sydney-nsw/",
                                                "anchor_text": "Heritage Slate Roof. St Thomas Church. Enfield Sydney NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "View Project",
                                        "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/heritage-slate-roof-st-thomas-church-enfield-sydney-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/heritage-slate-roof-st-thomas-church-enfield-sydney-nsw/",
                                                "anchor_text": "View Project"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Sydney Slate Roofing Client Testimonials",
                                "main_title": "Sydney Slate Roofing",
                                "author": null,
                                "language": null,
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Don't just take our word for it \u2014 here are some testimonials from our clients!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "If you are looking for the best slate roofing company in Sydney, you need to get in touch with Jeff. The work completed on our house looks amazing \u2013 thanks guys, you did an awesome job.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Jeff and his team did a fantastic job on our house. The care and attention to detail was exceptional and I am happy to recommend Sydney Slate Roofing to anyone looking for a roofer in Sydney.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Sydney Slate Roofing",
                                "main_title": "Sydney Slate Roofing",
                                "author": null,
                                "language": null,
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Sydney Slate Roofing",
                                        "url": "https://sydneyslateroofing.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyslateroofing.com.au/",
                                                "anchor_text": ""
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing Services",
                                        "url": "https://sydneyslateroofing.com.au/sydney-slate-roofing-services/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyslateroofing.com.au/sydney-slate-roofing-services/",
                                                "anchor_text": "Roofing Services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing Projects",
                                        "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/",
                                                "anchor_text": "Roofing Projects"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "About Us",
                                        "url": "https://sydneyslateroofing.com.au/about-sydney-slate-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyslateroofing.com.au/about-sydney-slate-roofing/",
                                                "anchor_text": "About Us"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Contact Us",
                                        "url": "https://sydneyslateroofing.com.au/contact-sydney-slate-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyslateroofing.com.au/contact-sydney-slate-roofing/",
                                                "anchor_text": "Contact Us"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Recycled Welsh Slate. Balmain Sydney NSW",
                                "main_title": "Sydney Slate Roofing",
                                "author": null,
                                "language": null,
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Recycled Welsh Slate. Balmain Sydney NSW",
                                        "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/recycled-welsh-slate-balmain-sydney-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/recycled-welsh-slate-balmain-sydney-nsw/",
                                                "anchor_text": "Recycled Welsh Slate. Balmain Sydney NSW"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Welsh Slate Roof, Vaucluse Sydney NSW",
                                "main_title": "Sydney Slate Roofing",
                                "author": null,
                                "language": null,
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Welsh Slate Roof, Vaucluse Sydney NSW",
                                        "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/welsh-slate-roof-vaucluse-sydney-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/welsh-slate-roof-vaucluse-sydney-nsw/",
                                                "anchor_text": "Welsh Slate Roof, Vaucluse Sydney NSW"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Heritage Slate Roof. St Thomas Church. Enfield Sydney NSW",
                                "main_title": "Sydney Slate Roofing",
                                "author": null,
                                "language": null,
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Heritage Slate Roof. St Thomas Church. Enfield Sydney NSW",
                                        "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/heritage-slate-roof-st-thomas-church-enfield-sydney-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/heritage-slate-roof-st-thomas-church-enfield-sydney-nsw/",
                                                "anchor_text": "Heritage Slate Roof. St Thomas Church. Enfield Sydney NSW"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Tile Shingle Roof. Newtown Train Station",
                                "main_title": "Sydney Slate Roofing",
                                "author": null,
                                "language": null,
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Tile Shingle Roof. Newtown Train Station",
                                        "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/tile-shingle-roof-newtown-train-station/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/tile-shingle-roof-newtown-train-station/",
                                                "anchor_text": "Tile Shingle Roof. Newtown Train Station"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Canadian Slate Roof, Bishops Court. Darling Point",
                                "main_title": "Sydney Slate Roofing",
                                "author": null,
                                "language": null,
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Canadian Slate Roof, Bishops Court. Darling Point",
                                        "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/bishops-court-new-slate-roof-darling-point/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/bishops-court-new-slate-roof-darling-point/",
                                                "anchor_text": "Canadian Slate Roof, Bishops Court. Darling Point"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "New Slate Roof. Killara, Sydney",
                                "main_title": "Sydney Slate Roofing",
                                "author": null,
                                "language": null,
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "New Slate Roof. Killara, Sydney",
                                        "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/new-slate-roof-killara-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/new-slate-roof-killara-sydney/",
                                                "anchor_text": "New Slate Roof. Killara, Sydney"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Heritage Roofing, Recycled Welsh Slate. Hunters Hill",
                                "main_title": "Sydney Slate Roofing",
                                "author": null,
                                "language": null,
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Heritage Roofing, Recycled Welsh Slate. Hunters Hill",
                                        "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/slate-copper-and-colorbond-roofing-hunters-hill/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/slate-copper-and-colorbond-roofing-hunters-hill/",
                                                "anchor_text": "Heritage Roofing, Recycled Welsh Slate. Hunters Hill"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Heritage Slate Roofing, Balmain",
                                "main_title": "Sydney Slate Roofing",
                                "author": null,
                                "language": null,
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Heritage Slate Roofing, Balmain",
                                        "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/slate-copper-roofing-and-leadwork-balmain/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/slate-copper-roofing-and-leadwork-balmain/",
                                                "anchor_text": "Heritage Slate Roofing, Balmain"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Timber Shingles. North Sydney, Sydney",
                                "main_title": "Sydney Slate Roofing",
                                "author": null,
                                "language": null,
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Timber Shingles. North Sydney, Sydney",
                                        "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/timber-shingle-roof-north-sydney-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/timber-shingle-roof-north-sydney-sydney/",
                                                "anchor_text": "Timber Shingles. North Sydney, Sydney"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Heritage Roofing. Central Station, Sydney NSW",
                                "main_title": "Sydney Slate Roofing",
                                "author": null,
                                "language": null,
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Heritage Roofing. Central Station, Sydney NSW",
                                        "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/heritage-roofing-central-station-sydney-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/heritage-roofing-central-station-sydney-nsw/",
                                                "anchor_text": "Heritage Roofing. Central Station, Sydney NSW"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Slate Roof. Leichhardt, Sydney",
                                "main_title": "Sydney Slate Roofing",
                                "author": null,
                                "language": null,
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Slate Roof. Leichhardt, Sydney",
                                        "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/slate-roof-leichhardt-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyslateroofing.com.au/sydney-slate-roof-projects/slate-roof-leichhardt-sydney/",
                                                "anchor_text": "Slate Roof. Leichhardt, Sydney"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Slate Roof Installation, Repair and Maintenance",
                                "main_title": "Sydney Slate Roofing",
                                "author": null,
                                "language": null,
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Slate Roof Installation, Repair and Maintenance",
                                        "url": "https://sydneyslateroofing.com.au/sydney-slate-roofing-services/slate-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyslateroofing.com.au/sydney-slate-roofing-services/slate-roofing/",
                                                "anchor_text": "Slate Roof Installation, Repair and Maintenance"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Tile Shingle Roof Roof Installation, Repair and Maintenance",
                                "main_title": "Sydney Slate Roofing",
                                "author": null,
                                "language": null,
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Tile Shingle Roof Roof Installation, Repair and Maintenance",
                                        "url": "https://sydneyslateroofing.com.au/sydney-slate-roofing-services/tile-shingle-roofs/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyslateroofing.com.au/sydney-slate-roofing-services/tile-shingle-roofs/",
                                                "anchor_text": "Tile Shingle Roof Roof Installation, Repair and Maintenance"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Timber Shingle Roof Installation, Repair and Maintenance",
                                "main_title": "Sydney Slate Roofing",
                                "author": null,
                                "language": null,
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Timber Shingle Roof Installation, Repair and Maintenance",
                                        "url": "https://sydneyslateroofing.com.au/sydney-slate-roofing-services/timber-shingle-roofs/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyslateroofing.com.au/sydney-slate-roofing-services/timber-shingle-roofs/",
                                                "anchor_text": "Timber Shingle Roof Installation, Repair and Maintenance"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Heritage Roof Installation, Repair and Maintenance",
                                "main_title": "Sydney Slate Roofing",
                                "author": null,
                                "language": null,
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Heritage Roof Installation, Repair and Maintenance",
                                        "url": "https://sydneyslateroofing.com.au/sydney-slate-roofing-services/heritage-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyslateroofing.com.au/sydney-slate-roofing-services/heritage-roofing/",
                                                "anchor_text": "Heritage Roof Installation, Repair and Maintenance"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "+61409100164"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}