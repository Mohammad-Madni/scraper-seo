{
    "id": "01190727-1132-0216-0000-67e4d2ea8b85",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0162 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://roofingcorp.net.au/roof-restoration/balmain",
        "target": "roofingcorp.net.au",
        "start_url": "https://roofingcorp.net.au/roof-restoration/balmain",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Balmain\\organic\\type-organic_rg13_ra18_roofingcorp.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:10 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "Sydney's trusted roofing specialists with over 30 years of experience. Expert roof leak detection, repairs, restoration, and painting services throughout Sydney.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "\u00a9 2025 RoofingCorp Pty Ltd",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "About Us",
                                    "url": "https://roofingcorp.net.au/about",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/about",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://roofingcorp.net.au/services/roof-leak-detection-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/roof-leak-detection-sydney",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Reports",
                                    "url": "https://roofingcorp.net.au/services/roof-reports-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/roof-reports-sydney",
                                            "anchor_text": "Roof Reports"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://roofingcorp.net.au/services/roof-repairs-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/roof-repairs-sydney",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://roofingcorp.net.au/services/roof-maintenance-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/roof-maintenance-sydney",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://roofingcorp.net.au/services/roof-cleaning-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/roof-cleaning-sydney",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://roofingcorp.net.au/services/roof-restoration-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/roof-restoration-sydney",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://roofingcorp.net.au/services/roof-painting-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/roof-painting-sydney",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://roofingcorp.net.au/services/metal-roofing-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/metal-roofing-sydney",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Asbestos Roof Removal",
                                    "url": "https://roofingcorp.net.au/services/asbestos-roof-removal-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/asbestos-roof-removal-sydney",
                                            "anchor_text": "Asbestos Roof Removal"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Replacement",
                                    "url": "https://roofingcorp.net.au/services/gutter-replacement-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/gutter-replacement-sydney",
                                            "anchor_text": "Gutter Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Fascia Replacement",
                                    "url": "https://roofingcorp.net.au/services/fascia-replacement-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/fascia-replacement-sydney",
                                            "anchor_text": "Fascia Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://roofingcorp.net.au/contact",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/contact",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Call us now",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://roofingcorp.net.au/about",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/about",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our Services",
                                    "url": "https://roofingcorp.net.au/services",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services",
                                            "anchor_text": "Our Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://roofingcorp.net.au/contact",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/contact",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Service Areas",
                                    "url": "https://roofingcorp.net.au/service-areas",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/service-areas",
                                            "anchor_text": "Service Areas"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://roofingcorp.net.au/services/roof-leak-detection-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/roof-leak-detection-sydney",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Reports",
                                    "url": "https://roofingcorp.net.au/services/roof-reports-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/roof-reports-sydney",
                                            "anchor_text": "Roof Reports"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://roofingcorp.net.au/services/roof-repairs-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/roof-repairs-sydney",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://roofingcorp.net.au/services/roof-maintenance-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/roof-maintenance-sydney",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://roofingcorp.net.au/services/roof-cleaning-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/roof-cleaning-sydney",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://roofingcorp.net.au/services/roof-restoration-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/roof-restoration-sydney",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://roofingcorp.net.au/services/roof-painting-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/roof-painting-sydney",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://roofingcorp.net.au/services/metal-roofing-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/metal-roofing-sydney",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Asbestos Roof Removal",
                                    "url": "https://roofingcorp.net.au/services/asbestos-roof-removal-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/asbestos-roof-removal-sydney",
                                            "anchor_text": "Asbestos Roof Removal"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Replacement",
                                    "url": "https://roofingcorp.net.au/services/gutter-replacement-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/gutter-replacement-sydney",
                                            "anchor_text": "Gutter Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Fascia Replacement",
                                    "url": "https://roofingcorp.net.au/services/fascia-replacement-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/fascia-replacement-sydney",
                                            "anchor_text": "Fascia Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Call us",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Email us",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "14 Stamford Avenue",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Ermington, NSW 2115",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Business Hours",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Mon-Sat: 7:00 AM - 4:00 PM",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Sunday: Closed",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "ABN: 30 600 295 323",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Roof Restoration Balmain",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Professional roof restoration services in Balmain. Transform your roof and protect your home for decades",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "From $3,500",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Full Restoration",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Warranty included",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Based on 239 reviews",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Complete Roof Transformation",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "A roof restoration is more than just painting\u2014it's a complete rejuvenation that extends your roof's life by 15-20 years. We use premium Dulux Acratex and Monier coating systems to deliver stunning results that last.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Balmain residents trust RoofingCorp for professional roof restoration services. With over 30 years of experience working throughout Inner West, we understand the specific roofing needs of homes and businesses in Balmain and surrounding suburbs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Premium Coating Systems",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We use only Dulux Acratex and Monier roofing systems\u2014Australia's leading roof coatings with proven performance.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "15-Year Warranty",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our restorations come with comprehensive warranties of up to 15 years on coating systems and workmanship.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Complete Restoration",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Not just paint\u2014we clean, repair, rebedand repoint ridge caps, replace broken tiles, and apply premium coatings.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Extend Roof Life 20+ Years",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "A quality restoration can add 15-20 years to your roof's life, saving thousands compared to replacement.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "High-Pressure Cleaning",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We thoroughly clean your roof to remove all moss, lichen, dirt, and debris, preparing the surface for coating.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Fungal Treatment",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Application of fungicide treatment to kill any remaining organic growth and prevent future regrowth.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Repairs & Repointing",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We replace broken tiles, rebedand repoint all ridge caps, and repair any damaged flashing or valleys.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Primer Application",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "A quality sealer/primer is applied to ensure optimal adhesion and longevity of the topcoats.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Premium Coating",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Two coats of premium Dulux Acratex or Monier membrane are applied for maximum protection and appearance.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Final Inspection",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Complete inspection and touch-ups ensure a flawless finish. Site clean-up and warranty documentation provided.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Signs Your Roof Needs Restoration",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Don't wait until major problems develop\u2014these signs indicate your roof would benefit from restoration.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Faded or Discoloured Tiles",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Original colour has faded, making your home look tired and reducing street appeal.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Moss & Lichen Growth",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Green or white growth on tiles indicates moisture retention and potential tile damage.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Cracked Bedding & Pointing",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ridge caps with cracked or missing mortar allow water entry and need rebedding.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Chalking Paint Surface",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "White powdery residue on tiles shows the existing coating has failed.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Age 15+ Years",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofs over 15 years old typically benefit from restoration to extend their life.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Signs Your Roof Needs Restoration",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Noticed any of these signs on your Balmain property? Don't wait until a small problem becomes expensive water damage. Our team regularly works in Balmain and can usually inspect your roof within days.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Your Local Restoration Experts",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Here's why homeowners and businesses across Balmain choose RoofingCorp for their roofing needs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Premium Products Only",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We exclusively use Dulux Acratex and Monier systems\u2014no cheap imports or inferior coatings.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Comprehensive Warranties",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Up to 15-year warranties on coating systems plus our workmanship guarantee for peace of mind.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Complete Restoration",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We don't cut corners. Every restoration includes cleaning, repairs, rebedding, and premium coating.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Experienced Craftsmen",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "30+ years of restoration experience means we understand what it takes to deliver lasting results.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Years Experience",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "5-Star Reviews",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Licensed & Insured",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Support Available",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Common Questions About Roof Restoration",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Everything you need to know about our roof restoration services for Balmain homes.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What Our Customers Say",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Don't just take our word for it. Here's what our customers say about our roofing services.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u201c Just had our entire roof restored by RoofingCorp using the Dulux Acratex system. The transformation is incredible - our 30-year-old tile roof looks brand new. The team was professional from the quote right through to completion. Very happy with the quality and the price was competitive. \u201d",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u201c Complete roof restoration using the Monier system. They cleaned, repaired, repointed and painted our tile roof. The 10-year warranty gave us peace of mind. Couldn't be happier with the results - the roof looks better than when the house was new! \u201d",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What Our Customers Say",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "\u201c Full restoration of our 40-year-old tile roof. RoofingCorp replaced broken tiles, rebedded and repointed all ridge caps, then applied the Dulux Acratex coating. Our roof is now waterproof and looks brand new. Worth every dollar. \u201d",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u201c Complete restoration of our heritage home's slate roof. RoofingCorp understood the importance of maintaining the original character. They sourced matching replacement slates and the restoration is seamless. Outstanding craftsmanship. \u201d",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What Our Customers Say",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "\u201c Our concrete tile roof was badly weathered after 25 years. The restoration process was comprehensive - cleaning, repairs, rebedding, repointing and painting. The result is spectacular. Like a brand new roof! \u201d",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u201c Complete restoration has transformed our home. The Dulux Acratex coating in a modern grey colour has given our 1980s house a contemporary look. Fantastic result! \u201d",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration Near Balmain",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We also service these suburbs near Balmain in the Inner West region",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Explore Our Roofing Services in Balmain",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "In addition to roof restoration, we offer a comprehensive range of roofing solutions in Balmain and throughout Inner West.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Need Roof Restoration in Balmain?",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Contact RoofingCorp today for professional roof restoration services. We're just a phone call away.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Request a Restoration Quote",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We'll get back to you as soon as possible",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Click to upload or drag and drop",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "By submitting this form, you agree to our Privacy Policy. Your information is secure.",
                                        "url": "https://roofingcorp.net.au/privacy-policy",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/privacy-policy",
                                                "anchor_text": "Privacy Policy"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "0 /5 images \u2022 Optional",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our Restoration Process",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "A systematic approach that delivers exceptional, long-lasting results.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Broken or Cracked Tiles",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Multiple damaged tiles indicate ageing and vulnerability to leaks.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How much does roof restoration cost in Balmain?",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How long does a roof restoration take in Balmain?",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How long will a roof restoration last in Balmain?",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Is roof restoration better than replacement in Balmain?",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What's included in your Balmain roof restoration?",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Still have questions? Our friendly team is here to help.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Sarah Chen",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Mark Johnson",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Baulkham Hills",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Daniel Mitchell",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Joseph Phillips",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Lane Cove",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Catherine Evans",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Hannah Price",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Leak Detection Balmain",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Leak Detection Balmain",
                                        "url": "https://roofingcorp.net.au/roof-leak-detection-and-repairs/balmain",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/roof-leak-detection-and-repairs/balmain",
                                                "anchor_text": "Roof Leak Detection Balmain"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "At RoofingCorp we are the industry leaders in roof leak detection Balmain and leaking roof repairs. For $99 we will find the source of your leak guaranteed.",
                                        "url": "https://roofingcorp.net.au/roof-leak-detection-and-repairs/balmain",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/roof-leak-detection-and-repairs/balmain",
                                                "anchor_text": "At RoofingCorp we are the industry leaders in roof leak detection Balmain and leaking roof repairs. For $99 we will find the source of your leak guaranteed."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Reports Balmain",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Reports Balmain",
                                        "url": "https://roofingcorp.net.au/services/roof-reports-sydney",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/services/roof-reports-sydney",
                                                "anchor_text": "Roof Reports Balmain"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "We are able to deliver an honest and thorough assessment on the current condition of your roof. Detailed reports for $299.",
                                        "url": "https://roofingcorp.net.au/services/roof-reports-sydney",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/services/roof-reports-sydney",
                                                "anchor_text": "We are able to deliver an honest and thorough assessment on the current condition of your roof. Detailed reports for $299."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs Balmain",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Repairs Balmain",
                                        "url": "https://roofingcorp.net.au/services/roof-repairs-sydney",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/services/roof-repairs-sydney",
                                                "anchor_text": "Roof Repairs Balmain"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Balmain residents can trust us to find the source and address any roof issues quickly and efficiently. Quality repairs with a money-back guarantee.",
                                        "url": "https://roofingcorp.net.au/services/roof-repairs-sydney",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/services/roof-repairs-sydney",
                                                "anchor_text": "Balmain residents can trust us to find the source and address any roof issues quickly and efficiently. Quality repairs with a money-back guarantee."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Maintenance Balmain",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Maintenance Balmain",
                                        "url": "https://roofingcorp.net.au/services/roof-maintenance-sydney",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/services/roof-maintenance-sydney",
                                                "anchor_text": "Roof Maintenance Balmain"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "We are able to service your roof maintenance and complete all repairs that will last you into the future.",
                                        "url": "https://roofingcorp.net.au/services/roof-maintenance-sydney",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/services/roof-maintenance-sydney",
                                                "anchor_text": "We are able to service your roof maintenance and complete all repairs that will last you into the future."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Cleaning Balmain",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Cleaning Balmain",
                                        "url": "https://roofingcorp.net.au/roof-cleaning/balmain",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/roof-cleaning/balmain",
                                                "anchor_text": "Roof Cleaning Balmain"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof cleaning is a great, affordable way to restore pride to your weary and untidy looking roof.",
                                        "url": "https://roofingcorp.net.au/roof-cleaning/balmain",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/roof-cleaning/balmain",
                                                "anchor_text": "Roof cleaning is a great, affordable way to restore pride to your weary and untidy looking roof."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Painting Balmain",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Painting Balmain",
                                        "url": "https://roofingcorp.net.au/roof-painting/balmain",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/roof-painting/balmain",
                                                "anchor_text": "Roof Painting Balmain"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Rejuvenate your roof, ensuring it continues to protect your family whilst adding value to your home's appeal.",
                                        "url": "https://roofingcorp.net.au/roof-painting/balmain",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/roof-painting/balmain",
                                                "anchor_text": "Rejuvenate your roof, ensuring it continues to protect your family whilst adding value to your home's appeal."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Roofing Balmain",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Metal Roofing Balmain",
                                        "url": "https://roofingcorp.net.au/services/metal-roofing-sydney",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/services/metal-roofing-sydney",
                                                "anchor_text": "Metal Roofing Balmain"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "We provide all flat metal roofing tasks, whether you need repairs, maintenance or a new flat metal roof.",
                                        "url": "https://roofingcorp.net.au/services/metal-roofing-sydney",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/services/metal-roofing-sydney",
                                                "anchor_text": "We provide all flat metal roofing tasks, whether you need repairs, maintenance or a new flat metal roof."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Asbestos Roof Removal Balmain",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Asbestos Roof Removal Balmain",
                                        "url": "https://roofingcorp.net.au/services/asbestos-roof-removal-sydney",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/services/asbestos-roof-removal-sydney",
                                                "anchor_text": "Asbestos Roof Removal Balmain"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "We are the specialists in the safe removal of asbestos roofs, and we make sure to comply with all regulations.",
                                        "url": "https://roofingcorp.net.au/services/asbestos-roof-removal-sydney",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/services/asbestos-roof-removal-sydney",
                                                "anchor_text": "We are the specialists in the safe removal of asbestos roofs, and we make sure to comply with all regulations."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter Replacement Balmain",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Gutter Replacement Balmain",
                                        "url": "https://roofingcorp.net.au/services/gutter-replacement-sydney",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/services/gutter-replacement-sydney",
                                                "anchor_text": "Gutter Replacement Balmain"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "We are your go-to experts for efficient gutter replacement services in Balmain, ensuring top-quality materials and workmanship.",
                                        "url": "https://roofingcorp.net.au/services/gutter-replacement-sydney",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/services/gutter-replacement-sydney",
                                                "anchor_text": "We are your go-to experts for efficient gutter replacement services in Balmain, ensuring top-quality materials and workmanship."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Fascia Replacement Balmain",
                                "main_title": "Roof Restoration Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Fascia Replacement Balmain",
                                        "url": "https://roofingcorp.net.au/services/fascia-replacement-sydney",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/services/fascia-replacement-sydney",
                                                "anchor_text": "Fascia Replacement Balmain"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Specialising in fascia replacement, we provide durable and aesthetically pleasing solutions that stand the test of time.",
                                        "url": "https://roofingcorp.net.au/services/fascia-replacement-sydney",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/services/fascia-replacement-sydney",
                                                "anchor_text": "Specialising in fascia replacement, we provide durable and aesthetically pleasing solutions that stand the test of time."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 5,
                                "max_rating_value": 5,
                                "rating_count": 69,
                                "relative_rating": 1
                            },
                            {
                                "name": null,
                                "rating_value": 5,
                                "max_rating_value": 5,
                                "rating_count": 69,
                                "relative_rating": 1
                            }
                        ],
                        "offers": null,
                        "comments": [
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-11-14 22:00:00 +00:00",
                                "author": "Eva Shui",
                                "primary_content": [
                                    {
                                        "text": "Cannot speak highly enough of RoofingCorp. They did high pressure clean and fungal treatment for us recently on an extremely hot weather nearly 45c outside, no reschedule, show up on time and the roof look like brand new after the wash. Asked them to come back to do repointing, replace broken tiles and fix leaking roof due to storm damage. Fast and efficient service at competitive price. Highly recommended.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-10-27 22:00:00 +00:00",
                                "author": "Kate Merrick",
                                "primary_content": [
                                    {
                                        "text": "Had some fibreglass panels on the roof changed out for sheet metal and while they were here I asked them to have a look at re-pointing the roof caps on the tile part of our roof. They went above and beyond, even finding and swapping out some severely broken tiles. The re-pointing and new roof panels look amazing! They were fast, friendly and professional. Have already recommended them to a few friends and will be keeping their details for future roofing needs. Thanks guys!!!",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-10-14 21:00:00 +00:00",
                                "author": "Ian Stokes",
                                "primary_content": [
                                    {
                                        "text": "I hired the guys from RoofingCorp to clean and repaint our steel roof. They were by far the most responsive, helpful, and value for money of all the companies I contacted in regards to the work I wanted done. Quick and efficient, well mannered, no fuss and the quality of the work was excellent. I would highly recommend them.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-09-29 21:00:00 +00:00",
                                "author": "Dennis Kalkandis",
                                "primary_content": [
                                    {
                                        "text": "Yesser and the team at Roofing Corp came out to my property and replaced my old tile roof to Colorbond. They did a great job. My new roof looks amazing, the job was completed within a few days and the boys removed and disposed of all the rubbish and excess materials from the site. They replaced all my batons to the correct spacing required for a metal roof and provided new insulation underneath. Great work.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-11-19 22:00:00 +00:00",
                                "author": "Michael Thompson",
                                "primary_content": [
                                    {
                                        "text": "We had a persistent leak that two other roofers couldn't find. RoofingCorp came out, found the source within an hour, and fixed it the same day. Their leak detection service is worth every cent. The $99 detection fee was deducted from the repair cost too. Highly recommend for anyone with a leaking roof in Sydney.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-11-17 22:00:00 +00:00",
                                "author": "Sarah Chen",
                                "primary_content": [
                                    {
                                        "text": "Just had our entire roof restored by RoofingCorp using the Dulux Acratex system. The transformation is incredible - our 30-year-old tile roof looks brand new. The team was professional from the quote right through to completion. Very happy with the quality and the price was competitive.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-11-11 22:00:00 +00:00",
                                "author": "David Williams",
                                "primary_content": [
                                    {
                                        "text": "Had all our gutters replaced with Colorbond gutters by RoofingCorp. The old gutters were rusted and leaking everywhere. The new ones look fantastic and the water flows perfectly now. The team cleaned up after themselves and were very professional throughout.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-11-07 22:00:00 +00:00",
                                "author": "Jennifer Brown",
                                "primary_content": [
                                    {
                                        "text": "Needed a roof condition report for insurance purposes after the recent storms. RoofingCorp provided a detailed, professional report with photos and recommendations. The report helped us claim the repair costs from our insurance. Well worth the $299.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-11-04 22:00:00 +00:00",
                                "author": "Robert Anderson",
                                "primary_content": [
                                    {
                                        "text": "Our tile roof was leaking in multiple spots after the heavy rains. RoofingCorp came out promptly, identified all the problem areas, and fixed everything in one visit. They even fixed some ridge capping issues we didn't know about. Fair price and excellent work.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-10-29 22:00:00 +00:00",
                                "author": "Michelle Lee",
                                "primary_content": [
                                    {
                                        "text": "The spray and wait cleaning method they use is amazing! No harsh chemicals or high pressure damage to our tiles. The moss and lichen are completely gone and the roof looks years younger. Will definitely use them again for regular maintenance.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-11-14 22:00:00 +00:00",
                                "author": "Eva Shui",
                                "primary_content": [
                                    {
                                        "text": "Cannot speak highly enough of RoofingCorp. They did high pressure clean and fungal treatment for us recently on an extremely hot weather nearly 45c outside, no reschedule, show up on time and the roof look like brand new after the wash. Asked them to come back to do repointing, replace broken tiles and fix leaking roof due to storm damage. Fast and efficient service at competitive price. Highly recommended.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-10-27 22:00:00 +00:00",
                                "author": "Kate Merrick",
                                "primary_content": [
                                    {
                                        "text": "Had some fibreglass panels on the roof changed out for sheet metal and while they were here I asked them to have a look at re-pointing the roof caps on the tile part of our roof. They went above and beyond, even finding and swapping out some severely broken tiles. The re-pointing and new roof panels look amazing! They were fast, friendly and professional. Have already recommended them to a few friends and will be keeping their details for future roofing needs. Thanks guys!!!",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-10-14 21:00:00 +00:00",
                                "author": "Ian Stokes",
                                "primary_content": [
                                    {
                                        "text": "I hired the guys from RoofingCorp to clean and repaint our steel roof. They were by far the most responsive, helpful, and value for money of all the companies I contacted in regards to the work I wanted done. Quick and efficient, well mannered, no fuss and the quality of the work was excellent. I would highly recommend them.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-09-29 21:00:00 +00:00",
                                "author": "Dennis Kalkandis",
                                "primary_content": [
                                    {
                                        "text": "Yesser and the team at Roofing Corp came out to my property and replaced my old tile roof to Colorbond. They did a great job. My new roof looks amazing, the job was completed within a few days and the boys removed and disposed of all the rubbish and excess materials from the site. They replaced all my batons to the correct spacing required for a metal roof and provided new insulation underneath. Great work.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-11-19 22:00:00 +00:00",
                                "author": "Michael Thompson",
                                "primary_content": [
                                    {
                                        "text": "We had a persistent leak that two other roofers couldn't find. RoofingCorp came out, found the source within an hour, and fixed it the same day. Their leak detection service is worth every cent. The $99 detection fee was deducted from the repair cost too. Highly recommend for anyone with a leaking roof in Sydney.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-11-17 22:00:00 +00:00",
                                "author": "Sarah Chen",
                                "primary_content": [
                                    {
                                        "text": "Just had our entire roof restored by RoofingCorp using the Dulux Acratex system. The transformation is incredible - our 30-year-old tile roof looks brand new. The team was professional from the quote right through to completion. Very happy with the quality and the price was competitive.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-11-11 22:00:00 +00:00",
                                "author": "David Williams",
                                "primary_content": [
                                    {
                                        "text": "Had all our gutters replaced with Colorbond gutters by RoofingCorp. The old gutters were rusted and leaking everywhere. The new ones look fantastic and the water flows perfectly now. The team cleaned up after themselves and were very professional throughout.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-11-07 22:00:00 +00:00",
                                "author": "Jennifer Brown",
                                "primary_content": [
                                    {
                                        "text": "Needed a roof condition report for insurance purposes after the recent storms. RoofingCorp provided a detailed, professional report with photos and recommendations. The report helped us claim the repair costs from our insurance. Well worth the $299.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-11-04 22:00:00 +00:00",
                                "author": "Robert Anderson",
                                "primary_content": [
                                    {
                                        "text": "Our tile roof was leaking in multiple spots after the heavy rains. RoofingCorp came out promptly, identified all the problem areas, and fixed everything in one visit. They even fixed some ridge capping issues we didn't know about. Fair price and excellent work.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-10-29 22:00:00 +00:00",
                                "author": "Michelle Lee",
                                "primary_content": [
                                    {
                                        "text": "The spray and wait cleaning method they use is amazing! No harsh chemicals or high pressure damage to our tiles. The moss and lichen are completely gone and the roof looks years younger. Will definitely use them again for regular maintenance.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            }
                        ],
                        "contacts": {
                            "telephones": [
                                "0414424878",
                                "0414 424 878"
                            ],
                            "emails": [
                                "sales@roofingcorp.net.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}