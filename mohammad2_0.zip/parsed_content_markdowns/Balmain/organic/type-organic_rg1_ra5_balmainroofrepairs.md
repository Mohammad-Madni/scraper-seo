{
    "id": "01191221-1132-0216-0000-475272042549",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0191 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://balmainroofrepairs.com.au/",
        "target": "balmainroofrepairs.com.au",
        "start_url": "https://balmainroofrepairs.com.au/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "enable_javascript": true,
        "switch_pool": true,
        "load_resources": true,
        "enable_browser_rendering": true,
        "enable_xhr": true,
        "disable_cookie_popup": true,
        "browser_preset": "desktop",
        "custom_js": "window.scrollTo(0, document.body.scrollHeight);",
        "tag": "parsed_content_markdowns\\Balmain\\organic\\type-organic_rg1_ra5_balmainroofrepairs.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 08:22:33 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Customer satisfaction guaranteed",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Now open",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "9:22 pm",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "24 hours, 7 days a week",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Everyday, 24 / 7",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Now Open",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Balmain Roof Repairs & Restoration",
                                "main_title": "Balmain Roof Repairs & Restoration",
                                "author": "admin",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Professional Team of Roofing Experts",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Efficient and Reliable Customer Service",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "\ue934 \ue934 \ue934 \ue934 \ue934 5/5",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Competitive upfront pricing",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Quality workmanship",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Extensive industry experience",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Timely Response Rate",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Now Open",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing\nRepairs",
                                "main_title": "Balmain Roof Repairs & Restoration",
                                "author": "admin",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Create a safe, secure home for your loved ones by ensuring that your roof is in its top shape. We handle roof repairs, including general roof leakages, roof damage, broken or missing roof tiles, ridge capping cracks, leaking skylights, and leaking chimneys.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof\nInstallations",
                                "main_title": "Balmain Roof Repairs & Restoration",
                                "author": "admin",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We offer affordable and durable roofing installation for new properties, designing show-stopping, reliable roofs in line with your individual preferences. Combining our quality workmanship and superior material choices, we will deliver roof installations that exceed your expectations.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof\nReplacements",
                                "main_title": "Balmain Roof Repairs & Restoration",
                                "author": "admin",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "An ageing outdated roof can retract from your property\u2019s aesthetic and curb appeal. From the replacement of specific roof elements to the entire roof, we are your trusted roofing contractors. Additionally, for rusty roofs, we offer the most high-performance metal roofing Balmain has ever had.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof\nRestoration",
                                "main_title": "Balmain Roof Repairs & Restoration",
                                "author": "admin",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "At Balmain Roof Repairs & Restoration, we offer the ultimate roof restoration services that will instantly boost your property value. Our roof cleaning, roof coating, and roof painting services will leave your roof looking as good as new.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter Installation\n& Cleaning",
                                "main_title": "Balmain Roof Repairs & Restoration",
                                "author": "admin",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "In addition to installing new stunning gutters to your property, we offer occasional cleaning of the gutters and valleys. Clogged gutters and valleys may cause water seepage and downpipe inflows which may result in flooding following heavy rains.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Waterproofing\nSolutions",
                                "main_title": "Balmain Roof Repairs & Restoration",
                                "author": "admin",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We provide effective roof waterproofing solutions that will protect your home from any dampness, leakages, or water damage. We combine a number of roofing solutions such as waterproof membranes, sealants, roof flashing, and roof drainage depending on our assessment of your waterproofing needs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Emergency\nRepairs",
                                "main_title": "Balmain Roof Repairs & Restoration",
                                "author": "admin",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Leaking roof repairs often have to be done urgently to minimise the water damage that may be caused to your finishes, building structure, and electrical works. We are on call 24/7 for all your emergency Balmain roof repairs, ensuring that your repairs are managed as soon as possible.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof\nInspections",
                                "main_title": "Balmain Roof Repairs & Restoration",
                                "author": "admin",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We are also available for roof inspections that will help you identify any maintenance and repair works that must be done early to prevent further damage. We also assess and provide quotations for any roof restoration works that need to be done.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Call us now for all things roofing!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We build sturdy roofs that can withstand harsh weather conditions without any compromise to the structural integrity of your roofing frame.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "02 9073 4786",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our customer reviews speak for themselves",
                                "main_title": "Balmain Roof Repairs & Restoration",
                                "author": "admin",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Balmain Roof Repairs & Restoration handled my roof restoration when I was doing my home renovations. It was so transformative, I could hardly recognise my own house.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "When I realised I had a leaky roof, I needed a slate roof repairs Balmain Company that would respond and fix it as soon as possible. Balmain Roof Repairs & Restoration were swift, and the leakage was repaired on the same day. I was truly impressed.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "\ue934 \ue934 \ue934 \ue934 \ue934 5/5",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Dorcas A.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\ue934 \ue934 \ue934 \ue934 \ue934 5/5",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "George S.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\ue934 \ue934 \ue934 \ue934 \ue934 5/5",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Dorcas A.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\ue934 \ue934 \ue934 \ue934 \ue934 5/5",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "George S.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Your search for reliable roofing companies is over!",
                                "main_title": "Balmain Roof Repairs & Restoration",
                                "author": "admin",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Call us now for all things roofing!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "As trusted roofing specialists, we have developed an exceptional track record of quality service and a vast client base of loyal, satisfied customers. We have an unmatched commitment to professionalism and efficiency in our roofing solutions.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "For any roof repairs in Sydney Balmain Area, we are the roof tiler, roof repair, and roof installation company for you!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Call us today for quality roofs that will stand the test of time.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "02 9073 4786",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "02 9073 4786",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Repairs",
                                        "url": "https://balmainroofrepairs.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://balmainroofrepairs.com.au/",
                                                "anchor_text": "Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement",
                                        "url": "https://balmainroofrepairs.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://balmainroofrepairs.com.au/",
                                                "anchor_text": "Roof Replacement"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration",
                                        "url": "https://balmainroofrepairs.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://balmainroofrepairs.com.au/",
                                                "anchor_text": "Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Installations",
                                        "url": "https://balmainroofrepairs.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://balmainroofrepairs.com.au/",
                                                "anchor_text": "Roof Installations"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gutter Installation & Cleaning",
                                        "url": "https://balmainroofrepairs.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://balmainroofrepairs.com.au/",
                                                "anchor_text": "Gutter Installation & Cleaning"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Waterproofing Solutions",
                                        "url": "https://balmainroofrepairs.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://balmainroofrepairs.com.au/",
                                                "anchor_text": "Roof Waterproofing Solutions"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Emergency Repairs",
                                        "url": "https://balmainroofrepairs.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://balmainroofrepairs.com.au/",
                                                "anchor_text": "Emergency Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Inspections",
                                        "url": "https://balmainroofrepairs.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://balmainroofrepairs.com.au/",
                                                "anchor_text": "Roof Inspections"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Contact us",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Repairs",
                                        "url": "https://balmainroofrepairs.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://balmainroofrepairs.com.au/",
                                                "anchor_text": "Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement",
                                        "url": "https://balmainroofrepairs.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://balmainroofrepairs.com.au/",
                                                "anchor_text": "Roof Replacement"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration",
                                        "url": "https://balmainroofrepairs.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://balmainroofrepairs.com.au/",
                                                "anchor_text": "Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Installations",
                                        "url": "https://balmainroofrepairs.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://balmainroofrepairs.com.au/",
                                                "anchor_text": "Roof Installations"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Installations",
                                        "url": "https://balmainroofrepairs.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://balmainroofrepairs.com.au/",
                                                "anchor_text": "Roof Installations"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gutter Installation & Cleaning",
                                        "url": "https://balmainroofrepairs.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://balmainroofrepairs.com.au/",
                                                "anchor_text": "Gutter Installation & Cleaning"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Waterproofing Solutions",
                                        "url": "https://balmainroofrepairs.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://balmainroofrepairs.com.au/",
                                                "anchor_text": "Roof Waterproofing Solutions"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Emergency Repairs",
                                        "url": "https://balmainroofrepairs.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://balmainroofrepairs.com.au/",
                                                "anchor_text": "Emergency Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Inspections",
                                        "url": "https://balmainroofrepairs.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://balmainroofrepairs.com.au/",
                                                "anchor_text": "Roof Inspections"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Contact us",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Website Safe & Secure",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "2026 Rights Reserved",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Balmain Roof Repairs & Restoration",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Book In A Schedule With Us Today!",
                                "main_title": "Balmain Roof Repairs & Restoration",
                                "author": "admin",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "*Get your roof inspected and fixed before more damages occur.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Your reliable Balmain Roofing experts",
                                "main_title": "Balmain Roof Repairs & Restoration",
                                "author": "admin",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Balmain Roof Repairs & Restoration has got you covered! With extensive industry experience, we specialise in durable roofing solutions using the highest quality of materials and proven leading-edge techniques.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Trusted by",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "We specialise in the following roofing & Roof Repairs Balmain Services",
                                "main_title": "Balmain Roof Repairs & Restoration",
                                "author": "admin",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Say goodbye to endless repairs with our roof repairs inner west services",
                                "main_title": "Balmain Roof Repairs & Restoration",
                                "author": "admin",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "At Balmain Roof Repairs & Restoration, we understand the frustration that comes with roofing problems. As such, we strive to create sturdy, durable, and reliable roofing solutions that will serve our clients for many years to come.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Leaking roofs can cause significant water damage to your floors, ceilings, and walls if not immediately mitigated. Usually, most leakages often occur due to deterioration as the roof ages with time. However, they can also be caused by severe weather, such as storm damage, windstorms, or hailstorms that significantly damage the roof structure and roof covering.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Damaged or missing roofing tiles can compromise your roof integrity, leaving your property susceptible to leakages, pests, and other safety hazards.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Energy loss is another common issue that comes with poorly insulated and damaged roofs, making your energy bills go over the roof. Having roofing solutions that increase the energy efficiency of your home can highly reduce your utility costs and increase the value of your home. That is where we come in!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our Balmain Roofing solutions are built to last",
                                "main_title": "Balmain Roof Repairs & Restoration",
                                "author": "admin",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "We offer Balmain Roofing Services that address all your roofing concerns, building roofs that will keep your property dry, secure, and well-protected for ages. We go above and beyond to ensure that our solutions enhance the aesthetics and curb appeal of your home, increasing its value in the property market.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "We specialise in the following roofing & roof repairs inner west services",
                                "main_title": "Balmain Roof Repairs & Restoration",
                                "author": "admin",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "We take great pride in our industry expertise, staying ahead of all new technology and techniques to provide our clients with the best roofing solutions in the market. We centre our services around the client\u2019s needs by offering a wide selection of roofing materials, roofing designs, and roofing elements. Our roofing services include, but are not limited to, the following:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Balmain roofing & roof repairs has been servicing the suburbs within the Sydney Balmain region for years",
                                "main_title": "Balmain Roof Repairs & Restoration",
                                "author": "admin",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "We have been catering to the diverse roofing needs of property owners within the Balmain Region, ranging from residential roofs to industrial roofs, commercial roofs, and heritage roofing Balmain services.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "02%209073%204786"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}