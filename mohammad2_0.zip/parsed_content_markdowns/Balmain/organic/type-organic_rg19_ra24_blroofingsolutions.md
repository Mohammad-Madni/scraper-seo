{
    "id": "01190727-1132-0216-0000-cbe9d83a8634",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0343 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.blroofingsolutions.com.au/locations/balmain",
        "target": "www.blroofingsolutions.com.au",
        "start_url": "https://www.blroofingsolutions.com.au/locations/balmain",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Balmain\\organic\\type-organic_rg19_ra24_blroofingsolutions.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:11 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Service Areas",
                                    "url": "https://www.blroofingsolutions.com.au/locations",
                                    "urls": [
                                        {
                                            "url": "https://www.blroofingsolutions.com.au/locations",
                                            "anchor_text": "Service Areas"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Expert roofing specialists with 10 years of experience providing high-quality roofing solutions throughout Sydney's Inner West and surrounding suburbs. Our qualified team delivers exceptional residential and commercial roofing services including repairs, restoration, maintenance, replacement, and metal roofing.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "\u00a9 2025 BL Roofing Solutions Pty Ltd. All rights reserved.",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "About Us",
                                    "url": "https://www.blroofingsolutions.com.au/about",
                                    "urls": [
                                        {
                                            "url": "https://www.blroofingsolutions.com.au/about",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our Services",
                                    "url": "https://www.blroofingsolutions.com.au/services",
                                    "urls": [
                                        {
                                            "url": "https://www.blroofingsolutions.com.au/services",
                                            "anchor_text": "Our Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.blroofingsolutions.com.au/contact",
                                    "urls": [
                                        {
                                            "url": "https://www.blroofingsolutions.com.au/contact",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Service Areas",
                                    "url": "https://www.blroofingsolutions.com.au/locations",
                                    "urls": [
                                        {
                                            "url": "https://www.blroofingsolutions.com.au/locations",
                                            "anchor_text": "Service Areas"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Roofing",
                                    "url": "https://www.blroofingsolutions.com.au/services/residential-roofing-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.blroofingsolutions.com.au/services/residential-roofing-sydney",
                                            "anchor_text": "Residential Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://www.blroofingsolutions.com.au/services/roof-repairs-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.blroofingsolutions.com.au/services/roof-repairs-sydney",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://www.blroofingsolutions.com.au/services/roof-restoration-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.blroofingsolutions.com.au/services/roof-restoration-sydney",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://www.blroofingsolutions.com.au/services/roof-maintenance-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.blroofingsolutions.com.au/services/roof-maintenance-sydney",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://www.blroofingsolutions.com.au/services/roof-replacement-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.blroofingsolutions.com.au/services/roof-replacement-sydney",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://www.blroofingsolutions.com.au/services/roof-painting-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.blroofingsolutions.com.au/services/roof-painting-sydney",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://www.blroofingsolutions.com.au/services/metal-roofing-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.blroofingsolutions.com.au/services/metal-roofing-sydney",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://www.blroofingsolutions.com.au/services/commercial-roofing-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.blroofingsolutions.com.au/services/commercial-roofing-sydney",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roof Repairs",
                                    "url": "https://www.blroofingsolutions.com.au/services/commercial-roof-repairs-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.blroofingsolutions.com.au/services/commercial-roof-repairs-sydney",
                                            "anchor_text": "Commercial Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roof Restoration",
                                    "url": "https://www.blroofingsolutions.com.au/services/commercial-roof-restoration-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.blroofingsolutions.com.au/services/commercial-roof-restoration-sydney",
                                            "anchor_text": "Commercial Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roof Maintenance",
                                    "url": "https://www.blroofingsolutions.com.au/services/commercial-roof-maintenance-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.blroofingsolutions.com.au/services/commercial-roof-maintenance-sydney",
                                            "anchor_text": "Commercial Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roof Replacement",
                                    "url": "https://www.blroofingsolutions.com.au/services/commercial-roof-replacement-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.blroofingsolutions.com.au/services/commercial-roof-replacement-sydney",
                                            "anchor_text": "Commercial Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roof Painting",
                                    "url": "https://www.blroofingsolutions.com.au/services/commercial-roof-painting-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.blroofingsolutions.com.au/services/commercial-roof-painting-sydney",
                                            "anchor_text": "Commercial Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Metal Roofing",
                                    "url": "https://www.blroofingsolutions.com.au/services/commercial-metal-roofing-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.blroofingsolutions.com.au/services/commercial-metal-roofing-sydney",
                                            "anchor_text": "Commercial Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sydney, NSW",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "ABN: 30 663 961 804",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Licence: 350277C",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Roofing Services Balmain",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Expert roof repairs, restoration and metal roofing specialists serving Balmain NSW. Professional roofing solutions with 10+ years local experience.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Our Services",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Professional Roofing Contractors in Balmain NSW",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "BL Roofing Solutions is your trusted local roofing specialist serving Balmain and surrounding Inner West suburbs. As experienced roofing contractors, we understand the unique challenges that Balmain properties face, from local building considerations to the Sydney climate effects on roofing materials.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our comprehensive roofing services in Balmain include professional roof repairs, complete roof restoration, preventative maintenance, roof replacement, and metal roofing installations. Whether you own a heritage terrace, modern apartment, commercial office building, or industrial property in Balmain, our skilled team delivers exceptional workmanship tailored to your specific roofing needs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Located in Sydney's Inner West, Balmain's unique architectural mix and local conditions require specialised roofing expertise. From residential homes to commercial warehouses and office complexes, our local knowledge combined with modern roofing techniques ensures your Balmain property receives the highest quality roofing solutions that protect and enhance your investment.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Complete Roofing Services in Balmain",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Comprehensive roofing solutions designed specifically for Balmain properties, from heritage homes to modern developments and commercial buildings.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose BL Roofing Solutions in Balmain",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Local expertise, professional workmanship, and exceptional customer service for all your Balmain roofing needs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Get Your Free Roofing Quote in Balmain",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Ready to protect your Balmain residential or commercial property with professional roofing services? Contact BL Roofing Solutions today for a comprehensive roof inspection and obligation-free quote.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Free comprehensive roof inspections in Balmain",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Detailed quotes with no hidden costs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Licensed and insured roofing professionals",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Workmanship and materials warranties",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Local Inner West roofing specialists",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "24/7 emergency service availability",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Client Testimonials",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "What Balmain residents say about our roofing services",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "BL Roofing Solutions completely transformed our weathered tile roof in Balmain. Their attention to detail and professional approach exceeded our expectations. Highly recommend their restoration services.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Quick response to our emergency leak repair in Balmain. The team was professional, efficient, and provided excellent value. Our roof has been problem-free since the repair.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Outstanding metal roofing installation on our Balmain property. The project was completed on time and the workmanship is exceptional. Great communication throughout the process.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Sarah Mitchell",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "James Thompson",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Maria Gonzalez",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Protect Your Balmain Property with Expert Roofing Services",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "From emergency repairs to complete roof restorations, BL Roofing Solutions provides comprehensive residential and commercial roofing services throughout Balmain NSW. Contact us today for professional advice and a free quote.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roof Leak Repairs Balmain",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Fast, reliable roof leak detection and repair services for Balmain homes and businesses.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration Balmain",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Complete roof restoration services to revitalise and protect your Balmain property.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Roofing Balmain",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Professional metal roofing installation and repair for durable, energy-efficient roofing solutions.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Replacement Balmain",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Complete roof replacement services when restoration isn't sufficient, providing new, reliable roofing systems.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Painting Balmain",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Professional roof painting and protective coating services to enhance appearance and weather resistance.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Tile Roof Repairs Balmain",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Expert tile roof repairs, re-bedding and pointing for heritage and modern tile roofs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Maintenance Balmain",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Preventative roof maintenance programs to identify issues early and extend your roof's lifespan.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter Replacement Balmain",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Complete gutter and downpipe replacement services for optimal water drainage protection.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Emergency Roof Repairs Balmain",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "24/7 emergency roofing services for urgent repairs in Balmain and surrounding areas.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Commercial Roofing Balmain",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Professional commercial roofing services for offices, warehouses, and industrial properties in Balmain.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Commercial Roof Maintenance Balmain",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Scheduled maintenance programs for commercial properties to prevent costly roof failures.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Storm Damage Repairs Balmain",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Expert assessment and repair of storm-damaged roofs with insurance claim assistance.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Colorbond Roofing Balmain",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Premium Colorbond steel roofing installation for superior durability and coastal corrosion resistance.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Inspections Balmain",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Comprehensive roof inspections to assess condition and identify potential issues before they worsen.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Flat Roof Solutions Balmain",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Specialised flat roof repairs, waterproofing, and maintenance for commercial and residential properties.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Local Balmain Expertise",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Deep understanding of Balmain's architectural styles, local requirements, and regional building regulations.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Licensed & Insured Roofers",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Fully licensed roof plumbers with comprehensive insurance coverage for complete peace of mind.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Fast Response Times",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Quick response to emergency calls and efficient project completion timelines for Balmain clients.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Quality Workmanship Guarantee",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Professional installation and repairs backed by comprehensive workmanship warranties.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Modern Roofing Solutions",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Latest roofing technologies and materials for energy efficiency and long-lasting performance.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Transparent Communication",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Clear, honest communication throughout your roofing project with detailed quotes and progress updates.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Frequently Asked Questions - Roofing Services Balmain",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How quickly can you respond to emergency roof repairs in Balmain?",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Do you work on heritage properties in Balmain?",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What roofing materials work best for Balmain's climate?",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How much does roof restoration cost in Balmain?",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Do you provide warranties on roofing work in Balmain?",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Can you help with council approvals for roofing work in Balmain?",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Do you provide commercial roofing services in Balmain?",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Request A Free Quote",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "(Maximum 5 images)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "This site is protected by reCAPTCHA and the Google Privacy Policy and Terms of Service apply.",
                                        "url": "https://policies.google.com/privacy",
                                        "urls": [
                                            {
                                                "url": "https://policies.google.com/privacy",
                                                "anchor_text": "Privacy Policy"
                                            },
                                            {
                                                "url": "https://policies.google.com/terms",
                                                "anchor_text": "Terms of Service"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our Complete Roofing Services",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Explore our comprehensive roofing services available in Balmain and surrounding areas",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Residential Roofing",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Residential Roofing",
                                        "url": "https://www.blroofingsolutions.com.au/services/residential-roofing-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.blroofingsolutions.com.au/services/residential-roofing-sydney",
                                                "anchor_text": "Residential Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Comprehensive residential roofing services delivering durable, attractive and weather-resistant roof solutions for Sydney homes.",
                                        "url": "https://www.blroofingsolutions.com.au/services/residential-roofing-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.blroofingsolutions.com.au/services/residential-roofing-sydney",
                                                "anchor_text": "Comprehensive residential roofing services delivering durable, attractive and weather-resistant roof solutions for Sydney homes."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Repairs",
                                        "url": "https://www.blroofingsolutions.com.au/services/roof-repairs-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.blroofingsolutions.com.au/services/roof-repairs-sydney",
                                                "anchor_text": "Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Professional roof repair services addressing leaks, damaged tiles, and structural issues to protect your property from water damage and restore roof integrity.",
                                        "url": "https://www.blroofingsolutions.com.au/services/roof-repairs-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.blroofingsolutions.com.au/services/roof-repairs-sydney",
                                                "anchor_text": "Professional roof repair services addressing leaks, damaged tiles, and structural issues to protect your property from water damage and restore roof integrity."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Restoration",
                                        "url": "https://www.blroofingsolutions.com.au/services/roof-restoration-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.blroofingsolutions.com.au/services/roof-restoration-sydney",
                                                "anchor_text": "Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Complete roof restoration services to revitalise your existing roof, extending its lifespan and improving your property's appearance and value.",
                                        "url": "https://www.blroofingsolutions.com.au/services/roof-restoration-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.blroofingsolutions.com.au/services/roof-restoration-sydney",
                                                "anchor_text": "Complete roof restoration services to revitalise your existing roof, extending its lifespan and improving your property's appearance and value."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Maintenance",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Maintenance",
                                        "url": "https://www.blroofingsolutions.com.au/services/roof-maintenance-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.blroofingsolutions.com.au/services/roof-maintenance-sydney",
                                                "anchor_text": "Roof Maintenance"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Preventative roof maintenance programs designed to identify and address potential issues before they become costly problems, extending the life of your roof.",
                                        "url": "https://www.blroofingsolutions.com.au/services/roof-maintenance-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.blroofingsolutions.com.au/services/roof-maintenance-sydney",
                                                "anchor_text": "Preventative roof maintenance programs designed to identify and address potential issues before they become costly problems, extending the life of your roof."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Replacement",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Replacement",
                                        "url": "https://www.blroofingsolutions.com.au/services/roof-replacement-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.blroofingsolutions.com.au/services/roof-replacement-sydney",
                                                "anchor_text": "Roof Replacement"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Full roof replacement services when repairs or restoration aren't sufficient, providing you with a brand new, reliable roofing system.",
                                        "url": "https://www.blroofingsolutions.com.au/services/roof-replacement-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.blroofingsolutions.com.au/services/roof-replacement-sydney",
                                                "anchor_text": "Full roof replacement services when repairs or restoration aren't sufficient, providing you with a brand new, reliable roofing system."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Painting",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Painting",
                                        "url": "https://www.blroofingsolutions.com.au/services/roof-painting-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.blroofingsolutions.com.au/services/roof-painting-sydney",
                                                "anchor_text": "Roof Painting"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Professional roof painting services to protect your roof from the elements while enhancing your property's appearance with quality, weather-resistant coatings.",
                                        "url": "https://www.blroofingsolutions.com.au/services/roof-painting-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.blroofingsolutions.com.au/services/roof-painting-sydney",
                                                "anchor_text": "Professional roof painting services to protect your roof from the elements while enhancing your property's appearance with quality, weather-resistant coatings."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Roofing",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Metal Roofing",
                                        "url": "https://www.blroofingsolutions.com.au/services/metal-roofing-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.blroofingsolutions.com.au/services/metal-roofing-sydney",
                                                "anchor_text": "Metal Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Specialised metal roofing installation and repair services offering durable, energy-efficient and stylish roofing solutions for residential properties.",
                                        "url": "https://www.blroofingsolutions.com.au/services/metal-roofing-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.blroofingsolutions.com.au/services/metal-roofing-sydney",
                                                "anchor_text": "Specialised metal roofing installation and repair services offering durable, energy-efficient and stylish roofing solutions for residential properties."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Commercial Roofing",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Commercial Roofing",
                                        "url": "https://www.blroofingsolutions.com.au/services/commercial-roofing-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.blroofingsolutions.com.au/services/commercial-roofing-sydney",
                                                "anchor_text": "Commercial Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Expert commercial roofing solutions for businesses, industrial facilities and multi-unit buildings throughout Sydney.",
                                        "url": "https://www.blroofingsolutions.com.au/services/commercial-roofing-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.blroofingsolutions.com.au/services/commercial-roofing-sydney",
                                                "anchor_text": "Expert commercial roofing solutions for businesses, industrial facilities and multi-unit buildings throughout Sydney."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Commercial Roof Repairs",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Commercial Roof Repairs",
                                        "url": "https://www.blroofingsolutions.com.au/services/commercial-roof-repairs-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.blroofingsolutions.com.au/services/commercial-roof-repairs-sydney",
                                                "anchor_text": "Commercial Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Prompt and efficient commercial roof repair services with minimal disruption to your business operations.",
                                        "url": "https://www.blroofingsolutions.com.au/services/commercial-roof-repairs-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.blroofingsolutions.com.au/services/commercial-roof-repairs-sydney",
                                                "anchor_text": "Prompt and efficient commercial roof repair services with minimal disruption to your business operations."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Commercial Roof Restoration",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Commercial Roof Restoration",
                                        "url": "https://www.blroofingsolutions.com.au/services/commercial-roof-restoration-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.blroofingsolutions.com.au/services/commercial-roof-restoration-sydney",
                                                "anchor_text": "Commercial Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Comprehensive commercial roof restoration services to extend roof life and improve energy efficiency for business properties.",
                                        "url": "https://www.blroofingsolutions.com.au/services/commercial-roof-restoration-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.blroofingsolutions.com.au/services/commercial-roof-restoration-sydney",
                                                "anchor_text": "Comprehensive commercial roof restoration services to extend roof life and improve energy efficiency for business properties."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Commercial Roof Maintenance",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Commercial Roof Maintenance",
                                        "url": "https://www.blroofingsolutions.com.au/services/commercial-roof-maintenance-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.blroofingsolutions.com.au/services/commercial-roof-maintenance-sydney",
                                                "anchor_text": "Commercial Roof Maintenance"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Scheduled maintenance programs for commercial properties to prevent costly roof failures and protect your business investment.",
                                        "url": "https://www.blroofingsolutions.com.au/services/commercial-roof-maintenance-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.blroofingsolutions.com.au/services/commercial-roof-maintenance-sydney",
                                                "anchor_text": "Scheduled maintenance programs for commercial properties to prevent costly roof failures and protect your business investment."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Commercial Roof Replacement",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Commercial Roof Replacement",
                                        "url": "https://www.blroofingsolutions.com.au/services/commercial-roof-replacement-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.blroofingsolutions.com.au/services/commercial-roof-replacement-sydney",
                                                "anchor_text": "Commercial Roof Replacement"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Complete commercial roof replacement services with minimal business disruption and tailored solutions for various business property types.",
                                        "url": "https://www.blroofingsolutions.com.au/services/commercial-roof-replacement-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.blroofingsolutions.com.au/services/commercial-roof-replacement-sydney",
                                                "anchor_text": "Complete commercial roof replacement services with minimal business disruption and tailored solutions for various business property types."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Commercial Roof Painting",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Commercial Roof Painting",
                                        "url": "https://www.blroofingsolutions.com.au/services/commercial-roof-painting-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.blroofingsolutions.com.au/services/commercial-roof-painting-sydney",
                                                "anchor_text": "Commercial Roof Painting"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Professional roof coating and painting services for commercial buildings to enhance protection and energy efficiency.",
                                        "url": "https://www.blroofingsolutions.com.au/services/commercial-roof-painting-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.blroofingsolutions.com.au/services/commercial-roof-painting-sydney",
                                                "anchor_text": "Professional roof coating and painting services for commercial buildings to enhance protection and energy efficiency."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Commercial Metal Roofing",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Commercial Metal Roofing",
                                        "url": "https://www.blroofingsolutions.com.au/services/commercial-metal-roofing-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.blroofingsolutions.com.au/services/commercial-metal-roofing-sydney",
                                                "anchor_text": "Commercial Metal Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Specialised commercial metal roofing solutions offering durability, low maintenance and energy efficiency for business properties throughout Sydney.",
                                        "url": "https://www.blroofingsolutions.com.au/services/commercial-metal-roofing-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.blroofingsolutions.com.au/services/commercial-metal-roofing-sydney",
                                                "anchor_text": "Specialised commercial metal roofing solutions offering durability, low maintenance and energy efficiency for business properties throughout Sydney."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing Services Balmain",
                                "main_title": "Roofing Services Balmain",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "What Our Clients Say",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "1300986966",
                                "1300 986 966"
                            ],
                            "emails": [
                                "sales@blroofingsolutions.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}