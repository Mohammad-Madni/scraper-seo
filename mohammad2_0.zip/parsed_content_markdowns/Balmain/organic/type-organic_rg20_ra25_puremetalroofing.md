{
    "id": "01190727-1132-0216-0000-be2345e60601",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0290 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://puremetalroofing.com.au/roof-repairs-balmain/",
        "target": "puremetalroofing.com.au",
        "start_url": "https://puremetalroofing.com.au/roof-repairs-balmain/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Balmain\\organic\\type-organic_rg20_ra25_puremetalroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:29:20 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "About Us",
                                    "url": "https://puremetalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://puremetalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://puremetalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://puremetalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://puremetalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://puremetalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://puremetalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://puremetalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Pure Metal Roofing Pty Ltd",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Quick Links",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://puremetalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://puremetalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://puremetalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://puremetalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://puremetalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://puremetalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://puremetalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://puremetalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Newtown NSW 2042",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Berala NSW 2141",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "ABN: 18 664 818 357",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Lic No. 388625C",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "100% Satisfaction Guaranteed",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Roof Repairs in Balmain",
                                "main_title": "Roof Repairs in Balmain",
                                "author": "",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "With over 30 years of experience, Pure Metal Roofing delivers trusted roof repairs across Balmain homes, businesses, and strata properties. From small leaks to major storm damage, we provide fast, expert service that lasts.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Expert Roof Repairs for Balmain Properties",
                                "main_title": "Roof Repairs in Balmain",
                                "author": "",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Balmain\u2019s mix of heritage homes, classic terraces, and modern builds brings unique roofing challenges\u2014ones we know inside and out. At Pure Metal Roofing, we specialise in diagnosing and fixing all kinds of roof issues, including leaking flashings, cracked tiles, rusted metal sheets, water ingress, and storm damage.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "With over 30 years of hands-on experience, we deliver quality workmanship backed by honest advice. Our licensed, in-house team never cuts corners and uses only premium materials like Colorbond for long-lasting durability and a seamless finish. Whether it\u2019s an urgent leak after heavy rain or the first signs of wear and tear, we act fast to protect your property and prevent further issues.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We handle repairs across all property types in Balmain\u2014from family homes and heritage terraces to commercial premises and strata-managed complexes. No matter the scale, we take the time to assess your roof thoroughly and tailor a solution that suits your structure, style, and budget.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "As a trusted local roofing company, we\u2019re known for our fast response, clear communication, and reliable results. Balmain clients count on us not just to fix the problem, but to restore confidence in the roof over their heads.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Request a Roof Inspection",
                                "main_title": "Roof Repairs in Balmain",
                                "author": "",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Book an inspection at a time that suits you. We\u2019ll visit your Balmain property promptly.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Assessment",
                                "main_title": "Roof Repairs in Balmain",
                                "author": "",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our licensed roofers assess the issue, document findings, and explain the next steps clearly.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Quote & Approval",
                                "main_title": "Roof Repairs in Balmain",
                                "author": "",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "You\u2019ll receive a detailed, itemised quote. Once approved, we schedule your repair.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Repair Work Begins",
                                "main_title": "Roof Repairs in Balmain",
                                "author": "",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our in-house team carries out the repairs using top-grade materials and proven techniques.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Final Inspection",
                                "main_title": "Roof Repairs in Balmain",
                                "author": "",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We review every detail and ensure your roof is secure, watertight, and ready to last.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Benefits of Choosing Pure Metal Roofing",
                                "main_title": "Roof Repairs in Balmain",
                                "author": "",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Fast response to leaks, storm damage, and urgent repair needs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Over 30 years of hands-on roofing experience across Sydney",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fully licensed, insured, and compliant with Australian standards",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "No subcontractors\u2014all work handled by our trusted in-house team",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Premium materials like Colorbond for durability and performance",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Repairs tailored to suit heritage, contemporary, and mixed roof types",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Clear communication and transparent, itemised quotes",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "10-Year Workmanship Guarantee on all repair work",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Clients Who Trust Us in Balmain",
                                "main_title": "Roof Repairs in Balmain",
                                "author": "",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We\u2019re proud to support a diverse range of clients across Balmain, delivering high-quality roof repairs that stand the test of time. Our local clients include:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Homeowners in heritage terraces and freestanding houses",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Property managers and strata committees maintaining multi-unit buildings",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Local business owners needing fast, effective repairs for shops, caf\u00e9s, and offices",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Builders and developers requiring dependable roofing support during renovations",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Real estate agents arranging pre-sale inspections and urgent roof fixes",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "No matter the client, we bring the same attention to detail, clear communication, and expert care to every job.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Frequently Asked Questions",
                                "main_title": "Roof Repairs in Balmain",
                                "author": "",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "How quickly can you respond to an urgent roof leak in Balmain?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We prioritise urgent repairs and aim to attend as soon as possible to minimise damage and protect your property.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Do you service heritage-listed homes with special roofing requirements?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yes. We have extensive experience repairing heritage homes while preserving their character and meeting all regulations.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "What types of roofing materials do you repair?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We work with a wide range of materials, including Colorbond metal, terracotta and concrete tiles, slate, and other common roofing types in Balmain.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Is there a warranty on your roof repair work?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Absolutely. All roof repairs are covered by our 10-Year Workmanship Guarantee.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Can you assist with insurance claims for storm or accidental damage?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yes. We provide supporting documentation and liaise directly with your insurer to help streamline the claims process.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Testimonials",
                                "main_title": "Roof Repairs in Balmain",
                                "author": "",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Binbin Liang",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How It Works",
                                "main_title": "Roof Repairs in Balmain",
                                "author": "",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gallery",
                                "main_title": "Roof Repairs in Balmain",
                                "author": "",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Areas We Serve",
                                "main_title": "Roof Repairs in Balmain",
                                "author": "",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Dulwich Hill",
                                        "url": "https://puremetalroofing.com.au/roof-repairs-dulwich-hill/",
                                        "urls": [
                                            {
                                                "url": "https://puremetalroofing.com.au/roof-repairs-dulwich-hill/",
                                                "anchor_text": "Dulwich Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Croydon Park",
                                        "url": "https://puremetalroofing.com.au/roof-repairs-dulwich-hill/",
                                        "urls": [
                                            {
                                                "url": "https://puremetalroofing.com.au/roof-repairs-dulwich-hill/",
                                                "anchor_text": "Croydon Park"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0422088256"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}