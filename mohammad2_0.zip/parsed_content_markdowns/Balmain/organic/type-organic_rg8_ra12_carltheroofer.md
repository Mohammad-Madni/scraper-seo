{
    "id": "01190727-1132-0216-0000-0434051a5f48",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0184 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://carltheroofer.com.au/",
        "target": "carltheroofer.com.au",
        "start_url": "https://carltheroofer.com.au/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Balmain\\organic\\type-organic_rg8_ra12_carltheroofer.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:29:17 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Servicing Sydney Only",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "All Types of Roof Repairs",
                                    "url": "https://carltheroofer.com.au/roof-repair-service/",
                                    "urls": [
                                        {
                                            "url": "https://carltheroofer.com.au/roof-repair-service/",
                                            "anchor_text": "All Types of Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "All Roof Leaks",
                                    "url": "https://carltheroofer.com.au/roof-leaks-repair/",
                                    "urls": [
                                        {
                                            "url": "https://carltheroofer.com.au/roof-leaks-repair/",
                                            "anchor_text": "All Roof Leaks"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://carltheroofer.com.au/roof-restoration-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://carltheroofer.com.au/roof-restoration-sydney/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Ridge Cap Repairs",
                                    "url": "https://carltheroofer.com.au/ridge-cap-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://carltheroofer.com.au/ridge-cap-repairs/",
                                            "anchor_text": "Ridge Cap Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "New and Old Roof Services",
                                    "url": "https://carltheroofer.com.au/new-and-old-roof-services/",
                                    "urls": [
                                        {
                                            "url": "https://carltheroofer.com.au/new-and-old-roof-services/",
                                            "anchor_text": "New and Old Roof Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta and Concrete Roofs",
                                    "url": "https://carltheroofer.com.au/terracotta-and-concrete-roofs/",
                                    "urls": [
                                        {
                                            "url": "https://carltheroofer.com.au/terracotta-and-concrete-roofs/",
                                            "anchor_text": "Terracotta and Concrete Roofs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colourbond and All Metal Roofing",
                                    "url": "https://carltheroofer.com.au/colourbond-and-all-metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://carltheroofer.com.au/colourbond-and-all-metal-roofing/",
                                            "anchor_text": "Colourbond and All Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Guttering and Downpipes",
                                    "url": "https://carltheroofer.com.au/guttering-and-downpipes/",
                                    "urls": [
                                        {
                                            "url": "https://carltheroofer.com.au/guttering-and-downpipes/",
                                            "anchor_text": "Guttering and Downpipes"
                                        }
                                    ]
                                },
                                {
                                    "text": "All Types of Roof Repairs",
                                    "url": "https://carltheroofer.com.au/roof-repair-service/",
                                    "urls": [
                                        {
                                            "url": "https://carltheroofer.com.au/roof-repair-service/",
                                            "anchor_text": "All Types of Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "All Roof Leaks",
                                    "url": "https://carltheroofer.com.au/roof-leaks-repair/",
                                    "urls": [
                                        {
                                            "url": "https://carltheroofer.com.au/roof-leaks-repair/",
                                            "anchor_text": "All Roof Leaks"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://carltheroofer.com.au/roof-restoration-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://carltheroofer.com.au/roof-restoration-sydney/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Ridge Cap Repairs",
                                    "url": "https://carltheroofer.com.au/ridge-cap-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://carltheroofer.com.au/ridge-cap-repairs/",
                                            "anchor_text": "Ridge Cap Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "New and Old Roof Services",
                                    "url": "https://carltheroofer.com.au/new-and-old-roof-services/",
                                    "urls": [
                                        {
                                            "url": "https://carltheroofer.com.au/new-and-old-roof-services/",
                                            "anchor_text": "New and Old Roof Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta and Concrete Roofs",
                                    "url": "https://carltheroofer.com.au/terracotta-and-concrete-roofs/",
                                    "urls": [
                                        {
                                            "url": "https://carltheroofer.com.au/terracotta-and-concrete-roofs/",
                                            "anchor_text": "Terracotta and Concrete Roofs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colourbond and All Metal Roofing",
                                    "url": "https://carltheroofer.com.au/colourbond-and-all-metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://carltheroofer.com.au/colourbond-and-all-metal-roofing/",
                                            "anchor_text": "Colourbond and All Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Guttering and Downpipes",
                                    "url": "https://carltheroofer.com.au/guttering-and-downpipes/",
                                    "urls": [
                                        {
                                            "url": "https://carltheroofer.com.au/guttering-and-downpipes/",
                                            "anchor_text": "Guttering and Downpipes"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "We pride ourselves on delivering top-quality roofing solutions with a smile. Our friendly team of experts is committed to providing the highest level of service and craftsmanship to ensure your complete satisfaction.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "119 Willoughby Rd, Crows Nest NSW\n2065",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Please contact our team at:\ninfo@carltheroofer.com.au",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "0480 012 601",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "All Types of Roof Repairs",
                                    "url": "https://carltheroofer.com.au/service/",
                                    "urls": [
                                        {
                                            "url": "https://carltheroofer.com.au/service/",
                                            "anchor_text": "All Types of Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "All Roof Leaks",
                                    "url": "https://carltheroofer.com.au/roof-leaks-repair/",
                                    "urls": [
                                        {
                                            "url": "https://carltheroofer.com.au/roof-leaks-repair/",
                                            "anchor_text": "All Roof Leaks"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://carltheroofer.com.au/roof-restoration-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://carltheroofer.com.au/roof-restoration-sydney/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Ridge Cap Repairs",
                                    "url": "https://carltheroofer.com.au/ridge-cap-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://carltheroofer.com.au/ridge-cap-repairs/",
                                            "anchor_text": "Ridge Cap Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "New and Old Roof Services",
                                    "url": "https://carltheroofer.com.au/new-and-old-roof-services/",
                                    "urls": [
                                        {
                                            "url": "https://carltheroofer.com.au/new-and-old-roof-services/",
                                            "anchor_text": "New and Old Roof Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta and Concrete Roofs",
                                    "url": "https://carltheroofer.com.au/terracotta-and-concrete-roofs/",
                                    "urls": [
                                        {
                                            "url": "https://carltheroofer.com.au/terracotta-and-concrete-roofs/",
                                            "anchor_text": "Terracotta and Concrete Roofs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colourbond and All Metal Roofing",
                                    "url": "https://carltheroofer.com.au/colourbond-and-all-metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://carltheroofer.com.au/colourbond-and-all-metal-roofing/",
                                            "anchor_text": "Colourbond and All Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Guttering and Downpipes",
                                    "url": "https://carltheroofer.com.au/guttering-and-downpipes/",
                                    "urls": [
                                        {
                                            "url": "https://carltheroofer.com.au/guttering-and-downpipes/",
                                            "anchor_text": "Guttering and Downpipes"
                                        }
                                    ]
                                },
                                {
                                    "text": "\u00a9 High Top Roofing Pty Limited ACN 168 216 411 - LIC 254652c",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Sydney\u2019s Trusted Roofing Experts \u2013 From Leaks to Looks!",
                                "main_title": "Sydney\u2019s Trusted Roofing Experts \u2013 From Leaks to Looks!",
                                "author": "SEO_Manager",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Proudly repairing and restoring roofs across Sydney\u2019s Eastern Suburbs. Book a free inspection with your local expert!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Proudly Servicing the Greater Sydney Area \u2013 Specialising in the Eastern Suburbs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Expert Roofing Solutions in Action!",
                                "main_title": "Sydney\u2019s Trusted Roofing Experts \u2013 From Leaks to Looks!",
                                "author": "SEO_Manager",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At Carl the Roofer, we pride ourselves on delivering top-quality roofing solutions with a smile. Our friendly team of experts is committed to providing the highest level of service and craftsmanship to ensure your complete satisfaction. Trust us to get the job done right the first time, every time. We specialize in:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All Types of Roof Repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ridge Cap Repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "New & Old Roof Services",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Colourbond & All Metal Roofing",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "All Roof Leaks",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Restoration",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Terracotta & Concrete",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Guttering & Downpipes",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Expert Roofing Solutions\nfor Your Needs",
                                "main_title": "Sydney\u2019s Trusted Roofing Experts \u2013 From Leaks to Looks!",
                                "author": "SEO_Manager",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "If you\u2019re in need of top-quality roofing services, look no further than our trusted roofing business! Our team of skilled roofing professionals is dedicated to providing you with the highest level of service and expertise.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Whether you need a new roof installation, repairs, or routine maintenance, our team has the experience and knowledge to get the job done right. We use only the best materials and equipment to ensure that your roof is not only functional but also visually appealing and long-lasting.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Don\u2019t let a leaky or damaged roof jeopardize the safety and security of your home or business. Call us today for a free estimate and let us show you why we\u2019re the preferred roofing company in the area. Your satisfaction is our top priority, and we\u2019re committed to exceeding your expectations every step of the way.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roofing Experties",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Customer Satisfaction",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Projects Completed",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Costs Transparency",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Google Reviews",
                                "main_title": "Sydney\u2019s Trusted Roofing Experts \u2013 From Leaks to Looks!",
                                "author": "SEO_Manager",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Scott and Laura Reid",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Camelia Boulos",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Arancha Bilbao",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Georgia Allen",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "david hutton",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sara Garcia",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "laura Reid",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Steve Mitchell",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Robyn Kane",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Simon Finniecome",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Get Your Free Quote Now!",
                                "main_title": "Sydney\u2019s Trusted Roofing Experts \u2013 From Leaks to Looks!",
                                "author": "SEO_Manager",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Currently servicing the Greater Sydney region only.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Please include as much details as possible to assist us with providing the correct quotation.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "First Name",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Last Name",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Email Address",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Contact Number",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Job Type",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Comment or Message",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0480%20012%20601"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}