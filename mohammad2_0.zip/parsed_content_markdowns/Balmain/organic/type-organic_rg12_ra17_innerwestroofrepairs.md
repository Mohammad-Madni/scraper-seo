{
    "id": "01190727-1132-0216-0000-e203676c0748",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0190 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.innerwestroofrepairs.com.au/",
        "target": "www.innerwestroofrepairs.com.au",
        "start_url": "https://www.innerwestroofrepairs.com.au/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Balmain\\organic\\type-organic_rg12_ra17_innerwestroofrepairs.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:15 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Sydney NSW",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "24 hours a day",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "7 days a week",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Email Us",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "EMERGENCY 24/7",
                                    "url": "https://www.innerwestroofrepairs.com.au/emergency-24-7/",
                                    "urls": [
                                        {
                                            "url": "https://www.innerwestroofrepairs.com.au/emergency-24-7/",
                                            "anchor_text": "EMERGENCY 24/7"
                                        }
                                    ]
                                },
                                {
                                    "text": "GUTTER REPAIR & REPLACEMENT",
                                    "url": "https://www.innerwestroofrepairs.com.au/gutter-repair-replacement-2/",
                                    "urls": [
                                        {
                                            "url": "https://www.innerwestroofrepairs.com.au/gutter-repair-replacement-2/",
                                            "anchor_text": "GUTTER REPAIR & REPLACEMENT"
                                        }
                                    ]
                                },
                                {
                                    "text": "METAL ROOF REPLACEMENT",
                                    "url": "https://www.innerwestroofrepairs.com.au/metal-roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://www.innerwestroofrepairs.com.au/metal-roof-replacement/",
                                            "anchor_text": "METAL ROOF REPLACEMENT"
                                        }
                                    ]
                                },
                                {
                                    "text": "ROOF TILE REPAIR & REPLACEMENT",
                                    "url": "https://www.innerwestroofrepairs.com.au/roof-tile-repair-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://www.innerwestroofrepairs.com.au/roof-tile-repair-replacement/",
                                            "anchor_text": "ROOF TILE REPAIR & REPLACEMENT"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Replacement of broken tiles",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Gutter repair and replacement",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Blocked gutters and downpipes",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Valley and Flashing replacement",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Leaking Roof repairs",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Sydney storm repair experts",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Commercial and Domestic Work",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "We cover all areas of the Sydney Metropolitan area",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "24hours a day 7 days a week",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "609/1 Rothschild Avenue Rosebery NSW 2108",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Re-Bed and Pointing",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Emergency 24/7 Service",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Free Quotes",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Roof Repairs & Replacement Sydney",
                                    "url": "https://www.innerwestroofrepairs.com.au/roof-repairs-replacement-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.innerwestroofrepairs.com.au/roof-repairs-replacement-sydney/",
                                            "anchor_text": "Roof Repairs & Replacement Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "EMERGENCY 24/7",
                                    "url": "https://www.innerwestroofrepairs.com.au/emergency-24-7/",
                                    "urls": [
                                        {
                                            "url": "https://www.innerwestroofrepairs.com.au/emergency-24-7/",
                                            "anchor_text": "EMERGENCY 24/7"
                                        }
                                    ]
                                },
                                {
                                    "text": "GUTTER REPAIR & REPLACEMENT",
                                    "url": "https://www.innerwestroofrepairs.com.au/gutter-repair-replacement-2/",
                                    "urls": [
                                        {
                                            "url": "https://www.innerwestroofrepairs.com.au/gutter-repair-replacement-2/",
                                            "anchor_text": "GUTTER REPAIR & REPLACEMENT"
                                        }
                                    ]
                                },
                                {
                                    "text": "METAL ROOF REPLACEMENT",
                                    "url": "https://www.innerwestroofrepairs.com.au/metal-roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://www.innerwestroofrepairs.com.au/metal-roof-replacement/",
                                            "anchor_text": "METAL ROOF REPLACEMENT"
                                        }
                                    ]
                                },
                                {
                                    "text": "ROOF TILE REPAIR & REPLACEMENT",
                                    "url": "https://www.innerwestroofrepairs.com.au/roof-tile-repair-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://www.innerwestroofrepairs.com.au/roof-tile-repair-replacement/",
                                            "anchor_text": "ROOF TILE REPAIR & REPLACEMENT"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "About Us",
                                "main_title": "Emergency Services\u00a024/7",
                                "author": "Inner West Roof Repairs",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Inner West Roof Repairs are a family run company and provide all commercial and domestic tile and metal roof repairs 24 hours a day, 7 days a week. We always aim to provide you with top quality work at competitive and reasonable prices. No shortcuts are taken, and no job is too big or too small. Our tradesmen are highly qualified, trained and reliable roofing contractors. You can trust our team to provide you with expert advice and professional workmanship. With over 30 years\u2019 experience in the roof repairs industry, you can trust Inner West Roof Repairs to get the job done. Inner West Roof Repairs are fully licenced and insured so you can have peace of mind that you have made the right choice when you call Inner West Roof Repairs.",
                                        "url": "https://www.innerwestroofrepairs.com.au/commercial/",
                                        "urls": [
                                            {
                                                "url": "https://www.innerwestroofrepairs.com.au/commercial/",
                                                "anchor_text": "commercial"
                                            },
                                            {
                                                "url": "https://www.innerwestroofrepairs.com.au/domestic/",
                                                "anchor_text": "domestic"
                                            },
                                            {
                                                "url": "https://www.innerwestroofrepairs.com.au/emergency-24-7/",
                                                "anchor_text": "24 hours a day, 7 days a week"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What we do",
                                "main_title": "Emergency Services\u00a024/7",
                                "author": "Inner West Roof Repairs",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Replacement of broken tiles",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Gutter repair and replacement",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Blocked gutters and downpipes",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Valley and Flashing replacement",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Leaking Roof repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sydney storm repair experts",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Commercial and Domestic Work",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Re-Bed and Pointing",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Emergency 24/7 Service",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Free Quotes",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How we do it",
                                "main_title": "Emergency Services\u00a024/7",
                                "author": "Inner West Roof Repairs",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "At Inner West Roof Repairs, we use only the best and high-quality materials. We work with only the best roofing suppliers across Sydney to bring you the best materials at a competitive price. Our roofing contractors are expertly trained in all areas of roof repairs by the very best in the business.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "This is why we are the leaders in Sydney for all of your domestic and commercial roof repair needs. We have worked on thousands of roofs for over 30 years. There is no repair we cannot do or haven\u2019t seen before. From start to finish you will be happy with your choice to call Inner West Roof Repairs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What to expect",
                                "main_title": "Emergency Services\u00a024/7",
                                "author": "Inner West Roof Repairs",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Give Inner West Roof Repairs a call and one of our friendly staff will take all of your details and book you in at a convenient time and day that suits you. We will arrive on time and in uniform ready to offer our experienced advice. Our tradesman will discuss with you any of your concerns and inspect your roof inside and out. We will identify the source of the problem and outline a detailed plan for the repairs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our office will then organise a comprehensive and competitive quote emailed to you within a few hours. On approval of your quote, we endeavour to have all of your work completed within a few days. We will work with you from start to finish to make sure your experience with Inner West Roof Repairs is nothing but the best.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Emergency Services\u00a024/7",
                                "main_title": "Emergency Services\u00a024/7",
                                "author": "Inner West Roof Repairs",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Emergency Services\u00a024/7",
                                        "url": "https://www.innerwestroofrepairs.com.au/emergency-24-7/",
                                        "urls": [
                                            {
                                                "url": "https://www.innerwestroofrepairs.com.au/emergency-24-7/",
                                                "anchor_text": "Emergency Services\u00a0 24/7"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "EMERGENCY 24/7",
                                "main_title": "Emergency Services\u00a024/7",
                                "author": "Inner West Roof Repairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "EMERGENCY 24/7",
                                        "url": "https://www.innerwestroofrepairs.com.au/emergency-24-7/",
                                        "urls": [
                                            {
                                                "url": "https://www.innerwestroofrepairs.com.au/emergency-24-7/",
                                                "anchor_text": "EMERGENCY 24/7"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "DOMESTIC",
                                "main_title": "Emergency Services\u00a024/7",
                                "author": "Inner West Roof Repairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "DOMESTIC",
                                        "url": "https://www.innerwestroofrepairs.com.au/domestic/",
                                        "urls": [
                                            {
                                                "url": "https://www.innerwestroofrepairs.com.au/domestic/",
                                                "anchor_text": "DOMESTIC"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "COMMERCIAL",
                                "main_title": "Emergency Services\u00a024/7",
                                "author": "Inner West Roof Repairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "COMMERCIAL",
                                        "url": "https://www.innerwestroofrepairs.com.au/commercial/",
                                        "urls": [
                                            {
                                                "url": "https://www.innerwestroofrepairs.com.au/commercial/",
                                                "anchor_text": "COMMERCIAL"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "REQUEST A CALLBACK",
                                "main_title": "Emergency Services\u00a024/7",
                                "author": "Inner West Roof Repairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "The Roofing Specialist that You Can Trust at a Price You Can Afford",
                                "main_title": "Emergency Services\u00a024/7",
                                "author": "Inner West Roof Repairs",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "+61386796452",
                                "1300169810",
                                "1300 617 360",
                                "%201300%20169%20810",
                                "1300169810"
                            ],
                            "emails": [
                                "info@innerwestroofrepairs.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}