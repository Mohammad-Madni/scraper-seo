{
    "id": "01190727-1132-0216-0000-e4e04c8df3bd",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0235 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://innerwestlocalroofing.com.au/roofing-balmain/",
        "target": "innerwestlocalroofing.com.au",
        "start_url": "https://innerwestlocalroofing.com.au/roofing-balmain/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Balmain\\organic\\type-organic_rg14_ra19_innerwestlocalroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:13 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "Inner West Local Roofing",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "About Us",
                                    "url": "https://innerwestlocalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                            "anchor_text": "Gutter Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/residential-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/residential-roofing/",
                                            "anchor_text": "Residential Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                            "anchor_text": "Roof Inspection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Repair",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                            "anchor_text": "Skylight Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Whirlybird Installation",
                                    "url": "https://innerwestlocalroofing.com.au/whirlybird-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/whirlybird-installation/",
                                            "anchor_text": "Whirlybird Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Installation",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-installation/",
                                            "anchor_text": "Gutter Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repointing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-leak-detection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-leak-detection/",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Installation",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-installation/",
                                            "anchor_text": "Skylight Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Storm Damage Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/storm-damage-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/storm-damage-repairs/",
                                            "anchor_text": "Storm Damage Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/terracotta-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/terracotta-roofing/",
                                            "anchor_text": "Terracotta Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/tile-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/tile-roofing/",
                                            "anchor_text": "Tile Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/tile-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/tile-roof-repairs/",
                                            "anchor_text": "Tile Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Balmain East",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                            "anchor_text": "Balmain East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dulwich Hill",
                                    "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                            "anchor_text": "Dulwich Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Inner West",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-inner-west/",
                                            "anchor_text": "Inner West"
                                        }
                                    ]
                                },
                                {
                                    "text": "St. Peters",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                            "anchor_text": "St. Peters"
                                        }
                                    ]
                                },
                                {
                                    "text": "Summer Hill",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                            "anchor_text": "Summer Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://innerwestlocalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                            "anchor_text": "Gutter Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/residential-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/residential-roofing/",
                                            "anchor_text": "Residential Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                            "anchor_text": "Roof Inspection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Repair",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                            "anchor_text": "Skylight Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Whirlybird Installation",
                                    "url": "https://innerwestlocalroofing.com.au/whirlybird-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/whirlybird-installation/",
                                            "anchor_text": "Whirlybird Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Installation",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-installation/",
                                            "anchor_text": "Gutter Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repointing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-leak-detection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-leak-detection/",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Installation",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-installation/",
                                            "anchor_text": "Skylight Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Storm Damage Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/storm-damage-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/storm-damage-repairs/",
                                            "anchor_text": "Storm Damage Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/terracotta-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/terracotta-roofing/",
                                            "anchor_text": "Terracotta Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/tile-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/tile-roofing/",
                                            "anchor_text": "Tile Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/tile-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/tile-roof-repairs/",
                                            "anchor_text": "Tile Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Balmain East",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                            "anchor_text": "Balmain East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dulwich Hill",
                                    "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                            "anchor_text": "Dulwich Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Inner West",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-inner-west/",
                                            "anchor_text": "Inner West"
                                        }
                                    ]
                                },
                                {
                                    "text": "St. Peters",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                            "anchor_text": "St. Peters"
                                        }
                                    ]
                                },
                                {
                                    "text": "Summer Hill",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                            "anchor_text": "Summer Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://innerwestlocalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                            "anchor_text": "Gutter Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/residential-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/residential-roofing/",
                                            "anchor_text": "Residential Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                            "anchor_text": "Roof Inspection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Repair",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                            "anchor_text": "Skylight Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Whirlybird Installation",
                                    "url": "https://innerwestlocalroofing.com.au/whirlybird-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/whirlybird-installation/",
                                            "anchor_text": "Whirlybird Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Installation",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-installation/",
                                            "anchor_text": "Gutter Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repointing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-leak-detection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-leak-detection/",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Installation",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-installation/",
                                            "anchor_text": "Skylight Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Storm Damage Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/storm-damage-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/storm-damage-repairs/",
                                            "anchor_text": "Storm Damage Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/terracotta-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/terracotta-roofing/",
                                            "anchor_text": "Terracotta Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/tile-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/tile-roofing/",
                                            "anchor_text": "Tile Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/tile-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/tile-roof-repairs/",
                                            "anchor_text": "Tile Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Balmain East",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                            "anchor_text": "Balmain East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dulwich Hill",
                                    "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                            "anchor_text": "Dulwich Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Inner West",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-inner-west/",
                                            "anchor_text": "Inner West"
                                        }
                                    ]
                                },
                                {
                                    "text": "St. Peters",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                            "anchor_text": "St. Peters"
                                        }
                                    ]
                                },
                                {
                                    "text": "Summer Hill",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                            "anchor_text": "Summer Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://innerwestlocalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                            "anchor_text": "Gutter Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/residential-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/residential-roofing/",
                                            "anchor_text": "Residential Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                            "anchor_text": "Roof Inspection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Repair",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                            "anchor_text": "Skylight Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Whirlybird Installation",
                                    "url": "https://innerwestlocalroofing.com.au/whirlybird-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/whirlybird-installation/",
                                            "anchor_text": "Whirlybird Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Installation",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-installation/",
                                            "anchor_text": "Gutter Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repointing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-leak-detection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-leak-detection/",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Installation",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-installation/",
                                            "anchor_text": "Skylight Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Storm Damage Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/storm-damage-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/storm-damage-repairs/",
                                            "anchor_text": "Storm Damage Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/terracotta-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/terracotta-roofing/",
                                            "anchor_text": "Terracotta Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/tile-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/tile-roofing/",
                                            "anchor_text": "Tile Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/tile-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/tile-roof-repairs/",
                                            "anchor_text": "Tile Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Balmain East",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                            "anchor_text": "Balmain East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dulwich Hill",
                                    "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                            "anchor_text": "Dulwich Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Inner West",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-inner-west/",
                                            "anchor_text": "Inner West"
                                        }
                                    ]
                                },
                                {
                                    "text": "St. Peters",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                            "anchor_text": "St. Peters"
                                        }
                                    ]
                                },
                                {
                                    "text": "Summer Hill",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                            "anchor_text": "Summer Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Address: Inner West, Sydney, NSW",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Opening Hours:\u00a0Monday to Sunday \u2013 24 hours",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "About Us",
                                    "url": "https://innerwestlocalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://innerwestlocalroofing.com.au/privacy-policy/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/privacy-policy/",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terms and Conditions",
                                    "url": "https://innerwestlocalroofing.com.au/terms-and-conditions/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/terms-and-conditions/",
                                            "anchor_text": "Terms and Conditions"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                            "anchor_text": "Gutter Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                            "anchor_text": "Roof Inspection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                            "anchor_text": "Skylight Repairs"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "The Roofer You Can Trust",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "At Inner West Local Roofing, we\u2019re proud to serve Balmain with reliable roofing solutions. From Darling Street to Mort Bay and beyond, our team understands the suburb\u2019s mix of sandstone cottages, heritage terraces, and contemporary homes, delivering expert repairs, maintenance, and replacements tailored to every property.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "As your local Balmain specialists, we\u2019re committed to keeping roofs strong, weatherproof, and built to last.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "About Balmain Roofing",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At Inner West Local Roofing, customer satisfaction is our top priority. We\u2019re proud to serve homeowners and businesses in Balmain with high-quality workmanship, backed by full licensing and insurance for complete peace of mind.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "No matter the size or complexity of your roofing project, our experienced team is here to help. We specialise in roof repairs, replacements, and new installations in Balmain, and we offer free, no-obligation quotes so you can plan your project with confidence.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Professionalism in Roofing Services",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "What sets us apart from other roofing companies in Balmain is our attention to detail and commitment to professionalism. We know how important your roof is, which is why we treat every project with the care it deserves \u2014 from the first on-site inspection to the final clean-up.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our process is straightforward and stress-free: we assess your roof, provide a clear and honest estimate, and deliver quality work on time and within budget. Respecting your schedule, we work efficiently to minimise disruption to your home or business.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Commitment",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing in Balmain isn\u2019t just our job \u2014 it\u2019s our passion. From heritage sandstone cottages and Victorian terraces to waterfront homes near Mort Bay, we understand the unique roofing needs of the area. We pride ourselves on honesty, transparency, and integrity, and we\u2019ll never recommend services you don\u2019t need. As your trusted Balmain roofing specialists, our goal is to protect your property, enhance its value, and give you lasting peace of mind.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Contact us today to discuss your Balmain roofing needs \u2014 whether it\u2019s a minor repair, a full roof replacement, or expert advice. We\u2019re here to help you every step of the way.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Looking for roofing services in the Inner West?",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "When it comes to keeping your Balmain property safe, you need a roofing team that brings together skill, trust, and genuine local knowledge. At Inner West Local Roofing, we\u2019re not just tradies \u2014 we\u2019re part of the community. With years spent restoring heritage terraces on Darling Street, repairing slate and iron roofs on Victorian cottages, and maintaining modern waterfront homes overlooking the harbour, we know the unique challenges Balmain roofs face. From salt air corrosion to ageing tiles, our tailored roofing solutions are designed to last. With a focus on quality workmanship, transparent advice, and reliable service, we give Balmain homeowners confidence and peace of mind under every roof we repair or replace.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Emergency Roof Repairs",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "When wild weather or sudden damage strikes, our Balmain team provides rapid emergency roof repairs to safeguard your home or business.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter Repair",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "From leaks to blockages, we carry out expert gutter repairs in Balmain, preventing water damage and protecting properties from costly issues.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "FREQUENTLY ASKED QUESTIONS",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "What types of roofing services do you offer in Balmain?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We provide a full range of roofing services in Balmain, including roof repairs, restorations, new roof installations, roof cleaning, roof painting, and skylight repairs for both residential and commercial properties.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "How quickly can you respond to roof damage in Balmain?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our local team provides fast response times across Balmain, handling urgent roof repairs from storm damage, leaks, or sudden emergencies to keep your property safe.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Do you work on older or heritage-style homes in Balmain?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yes \u2014 we specialise in Balmain\u2019s Victorian terraces, sandstone cottages, and Federation homes, delivering careful roof restorations that maintain original character while improving durability.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "What roofing materials do you recommend for homes in Balmain?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We recommend durable, weather-resistant materials suited to Balmain\u2019s harbour climate and housing styles, including Colorbond, slate, terracotta, and metal roofing for long-lasting protection.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Is roof maintenance really necessary for homes in Balmain?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Regular roof maintenance is essential in Balmain, especially for heritage terraces and older properties, as it helps prevent rust, leaks, and structural issues while extending your roof\u2019s lifespan.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What Our Clients Say",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 5,
                                "primary_content": [
                                    {
                                        "text": "\u201cAfter a big storm, our terrace in Balmain developed a serious roof leak. The team from Inner West Local Roofing were quick to respond, professional, and explained every step of the repair clearly. They even matched the new materials perfectly with the heritage style of our home. It\u2019s rare to find tradies this reliable \u2014 I wouldn\u2019t hesitate to recommend them to other Balmain locals.\u201d",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "At Inner West Roofing, we\u2019re proud to serve the Balmain community with trusted, high-quality roofing services. From restoring slate and iron roofs on Darling Street terraces to installing new roofing on waterfront homes overlooking Mort Bay, we\u2019ve helped homeowners across Balmain protect and enhance their properties with tailored solutions and expert workmanship. With Balmain\u2019s unique blend of heritage cottages, Victorian terraces, and modern residences, we understand the specific roofing challenges locals face \u2014 here\u2019s what some of our happy Balmain clients have shared about working with us.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sarah M.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Get a Free Quote Today!",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": [
                                    {
                                        "text": "When it comes to roofing needs, look no further than Inner West Local Roofing. We\u2019re the most reputable choice in the industry. Contact us today and discover the exceptional service we offer. You won\u2019t be let down.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Why Choose Us?",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "SAFETY & RELIABILITY",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "LONG-TERM PLANS",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "FULLY EXPERIENCED",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "QUALITY MATERIALS",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "OUR SERVICES\u200b",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Commercial Roofing",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We deliver reliable commercial roofing solutions throughout Balmain, helping local shops, cafes, and businesses stay protected with strong, long-lasting roofs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Residential Roofing",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our residential roofing services in Balmain cater to all styles \u2014 from sandstone cottages and terraces to modern harbourfront homes.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Cleaning",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We offer professional roof cleaning across Balmain, removing moss, dirt, and debris to restore appearance and extend roof life.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Inspection",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our detailed roof inspections in Balmain identify issues early, saving property owners time, money, and stress in the long term.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Installation",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Need a new roof? We provide expert roof installations throughout Balmain, using durable materials designed for Sydney\u2019s coastal climate.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Maintenance",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Regular roof maintenance keeps Balmain homes secure. Our team ensures your roof withstands salt air, storms, and everyday wear.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Painting",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We deliver professional roof painting in Balmain, protecting against the elements while giving homes a fresh, modern look.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "From small leaks to major damage, our Balmain roof repair services provide lasting solutions for local homeowners and businesses.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Revive your roof with our specialist roof restoration services in Balmain \u2014 a cost-effective way to avoid full replacement.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Skylight Repair",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We carry out professional skylight repairs across Balmain, fixing leaks and restoring natural light to homes and businesses.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What Do We Do?",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Built for Balmain\u2019s Harbour Climate",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Designed to withstand Balmain\u2019s salty sea air, summer heat, and sudden Sydney storms",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Helps prevent common roofing issues in Balmain, including rust on iron roofs and leaks in older terraces",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Uses durable, weather-resistant materials suited to Balmain\u2019s heritage and modern properties",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Delivers long-lasting roofing solutions tailored to the peninsula\u2019s unique conditions",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Heritage & Modern Home Expertise",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Experienced in restoring Balmain\u2019s Victorian terraces, Federation cottages, and sandstone homes",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Careful roof restorations that preserve historic charm while strengthening durability",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Custom solutions for Balmain\u2019s mix of heritage dwellings, apartments, and contemporary builds",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Tailored advice for extensions, renovations, and upgrading older Balmain roofs",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Fast, Local & Trusted Service",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Quick response times for roof repairs in Balmain, from storm damage to everyday wear and tear",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Fully familiar with Inner West council guidelines and Balmain\u2019s heritage building requirements",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Trusted by homeowners and small businesses along Darling Street, Montague Street, and surrounding areas",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Committed to delivering quality workmanship and dependable local service every time",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "GET IN TOUCH",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Copyright \u00a9 2025 | Inner West Local Roofing",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 5,
                                "max_rating_value": 5,
                                "rating_count": 12,
                                "relative_rating": 1
                            }
                        ],
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0280743728"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}