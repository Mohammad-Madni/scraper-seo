# Type: people_also_search | Rank: 26 | RG: 2
### Raw Row Data:
{
    "rank_group": "2",
    "rank_absolute": "26",
    "service": "roofer",
    "suburb": "Balmain",
    "title": "People also search for",
    "domain": "",
    "url": "",
    "description": "",
    "type": "people_also_search"
}