import csv
import json
import aiohttp
import asyncio
import base64
import os
import re
from config import USERNAME, PASSWORD
from typing import List, Dict, Tuple
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor

@dataclass
class TaskMetadata:
    issue_val: str
    suburb: str
    service: str
    type: str
    rank: str
    rank_group: str
    url: str
    file_path: str

class AsyncRetryProcessor:
    def __init__(self, base_folder="parsed_content_markdowns", new_folder="parsed_content_markdowns2"):
        self.base_folder = base_folder
        self.new_folder = new_folder
        self.summary_csv_path = os.path.join(base_folder, "_error_summary.csv")
        self.new_summary_path = os.path.join(new_folder, "_retry_organic_report.csv")
        
        auth_str = f"{USERNAME}:{PASSWORD}"
        token = base64.b64encode(auth_str.encode()).decode()
        self.headers = {
            'Authorization': f'Basic {token}',
            'Content-Type': 'application/json'
        }
        
        self.summary_fields = ['Issue', 'suburb', 'service', 'type', 'rank', 'rank_group', 'url', 'error_type', 'status']
        self.processed_count = 0
        self.skipped_count = 0
        self.failed_tasks = []
        
    def setup_folders(self):
        """Create necessary folders"""
        if not os.path.exists(self.new_folder):
            print(f"📂 Creating {self.new_folder}...")
            os.makedirs(self.new_folder)
        
        with open(self.new_summary_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=self.summary_fields)
            writer.writeheader()
    
    def collect_tasks(self) -> Tuple[List[Dict], Dict[str, TaskMetadata]]:
        """Collect all tasks that need retry"""
        if not os.path.exists(self.summary_csv_path):
            print(f"❌ Error: {self.summary_csv_path} not found!")
            return [], {}
        
        tasks_bucket = []
        metadata_map = {}
        
        print("🚀 Collecting tasks for retry...")
        
        with open(self.summary_csv_path, mode='r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            for row in reader:
                issue_val = str(row.get('Issue', '')).upper().strip()
                type_val = str(row.get('type', '')).lower().strip()
                status_val = str(row.get('status', '')).lower().strip()
                rank_gp = row.get('rank_group', '0')
                
                # Check Rank Group (1-5)
                try:
                    rg_int = int(rank_gp)
                except:
                    rg_int = 100
                
                if rg_int < 1 or rg_int > 5:
                    self.skipped_count += 1
                    continue
                
                if "organic" not in type_val:
                    self.skipped_count += 1
                    continue
                
                # Check Issue or Status
                is_target = False
                if issue_val in ["CRITICAL", "ERROR"]:
                    is_target = True
                elif "pending" in status_val or "pending" in issue_val.lower():
                    is_target = True
                
                if not is_target:
                    self.skipped_count += 1
                    continue
                
                suburb = row.get('suburb', 'Unknown')
                service = row.get('service', 'service')
                item_type = type_val.replace(' ', '_')
                rank_abs = row.get('rank', '0')
                url = row.get('url', '')
                
                if not url or "google.com" in url or not url.startswith("http"):
                    continue
                
                suburb_slug = str(suburb).strip().replace(' ', '-')
                target_path = os.path.join(self.new_folder, suburb_slug, item_type)
                os.makedirs(target_path, exist_ok=True)
                
                domain_match = re.sub(r'(https?://|www\.)', '', url).split('/')[0].split('.')[0]
                filename = f"type-{item_type}_rg{rank_gp}_ra{rank_abs}_{domain_match}.md"
                file_path = os.path.join(target_path, filename)
                
                task_payload = {
                    "target": re.sub(r'(https?://|www\.)', '', url).split('/')[0],
                    "start_url": url,
                    "url": url,
                    "enable_content_parsing": True,
                    "max_crawl_pages": 1,
                    "enable_javascript": True,
                    "enable_browser_rendering": True,
                    "load_resources": True,
                    "disable_cookie_popup": True,
                    "browser_wait_until": "fully_loaded",
                    "tag": file_path
                }
                
                tasks_bucket.append(task_payload)
                
                metadata_map[file_path] = TaskMetadata(
                    issue_val=issue_val,
                    suburb=suburb,
                    service=service,
                    type=item_type,
                    rank=rank_abs,
                    rank_group=rank_gp,
                    url=url,
                    file_path=file_path
                )
                
                print(f"➕ Queued: {domain_match}")
        
        return tasks_bucket, metadata_map
    
    async def post_batch(self, session: aiohttp.ClientSession, batch: List[Dict], batch_num: int) -> Tuple[List[str], Dict[str, str]]:
        """Post a batch of tasks asynchronously"""
        endpoint = "https://api.dataforseo.com/v3/on_page/task_post"
        
        try:
            async with session.post(endpoint, json=batch, timeout=aiohttp.ClientTimeout(total=120)) as resp:
                if resp.status != 200:
                    print(f"❌ Batch {batch_num} post failed: {resp.status}")
                    return [], {}
                
                resp_data = await resp.json()
                task_ids = []
                id_to_tag = {}
                
                for task in resp_data.get('tasks', []):
                    tid = task.get('id')
                    tag = task.get('data', {}).get('tag')
                    if tid and tag:
                        task_ids.append(tid)
                        id_to_tag[tid] = tag
                
                print(f"✅ Batch {batch_num} posted: {len(task_ids)} tasks")
                return task_ids, id_to_tag
        
        except Exception as e:
            print(f"❌ Batch {batch_num} error: {e}")
            return [], {}
    
    async def fetch_results(self, session: aiohttp.ClientSession, task_ids: List[str], 
                          id_to_tag: Dict[str, str], metadata_map: Dict[str, TaskMetadata], 
                          batch_num: int):
        """Fetch results for a batch of tasks"""
        endpoint = "https://api.dataforseo.com/v3/on_page/content_parsing"
        
        fetch_payload = []
        for tid in task_ids:
            tag = id_to_tag.get(tid)
            meta = metadata_map.get(tag)
            if meta:
                fetch_payload.append({"id": tid, "url": meta.url})
        
        if not fetch_payload:
            return
        
        try:
            async with session.post(endpoint, json=fetch_payload, timeout=aiohttp.ClientTimeout(total=120)) as resp:
                if resp.status != 200:
                    print(f"❌ Batch {batch_num} fetch failed: {resp.status}")
                    return
                
                res_json = await resp.json()
                
                # Process results in thread pool to avoid blocking
                loop = asyncio.get_event_loop()
                with ThreadPoolExecutor(max_workers=10) as executor:
                    tasks = []
                    for task_res in res_json.get("tasks", []):
                        tasks.append(
                            loop.run_in_executor(
                                executor,
                                self.save_result,
                                task_res,
                                id_to_tag,
                                metadata_map
                            )
                        )
                    await asyncio.gather(*tasks)
        
        except Exception as e:
            print(f"❌ Batch {batch_num} fetch error: {e}")
    
    def save_result(self, task_res: Dict, id_to_tag: Dict[str, str], metadata_map: Dict[str, TaskMetadata]):
        """Save individual result (runs in thread pool)"""
        tag_path = task_res.get("data", {}).get("tag")
        
        if not tag_path:
            tid = task_res.get("id")
            tag_path = id_to_tag.get(tid)
        
        if not tag_path:
            return
        
        status_msg = task_res.get('status_message')
        
        if status_msg == 'Ok.':
            try:
                with open(tag_path, "w", encoding="utf-8") as f:
                    json.dump(task_res, f, indent=4)
                print(f"✅ Saved: {os.path.basename(tag_path)}")
                self.processed_count += 1
            except Exception as e:
                print(f"❌ Save Error {tag_path}: {e}")
        else:
            meta = metadata_map.get(tag_path)
            if meta:
                self.failed_tasks.append({
                    'Issue': f"RETRY_FAILED_{meta.issue_val}",
                    'suburb': meta.suburb,
                    'service': meta.service,
                    'type': meta.type,
                    'rank': meta.rank,
                    'rank_group': meta.rank_group,
                    'url': meta.url,
                    'error_type': 'api_error',
                    'status': status_msg
                })
    
    async def process_batch_with_wait(self, session: aiohttp.ClientSession, batch: List[Dict], 
                                     metadata_map: Dict[str, TaskMetadata], batch_num: int, 
                                     wait_time: int = 120):
        """Process a single batch: post, wait, fetch"""
        print(f"📡 Processing batch {batch_num} ({len(batch)} tasks)...")
        
        # Post batch
        task_ids, id_to_tag = await self.post_batch(session, batch, batch_num)
        
        if not task_ids:
            return
        
        # Wait for processing
        print(f"⏳ Waiting {wait_time}s for batch {batch_num}...")
        await asyncio.sleep(wait_time)
        
        # Fetch results
        print(f"📥 Fetching results for batch {batch_num}...")
        await self.fetch_results(session, task_ids, id_to_tag, metadata_map, batch_num)
    
    async def process_all_batches(self, tasks_bucket: List[Dict], metadata_map: Dict[str, TaskMetadata], 
                                 batch_size: int = 100, max_concurrent_batches: int = 3):
        """Process all batches with controlled concurrency"""
        connector = aiohttp.TCPConnector(limit=50, limit_per_host=20)
        timeout = aiohttp.ClientTimeout(total=300)
        
        async with aiohttp.ClientSession(headers=self.headers, connector=connector, timeout=timeout) as session:
            # Create batch tasks
            batch_tasks = []
            for i in range(0, len(tasks_bucket), batch_size):
                batch = tasks_bucket[i:i + batch_size]
                batch_num = i // batch_size + 1
                batch_tasks.append(
                    self.process_batch_with_wait(session, batch, metadata_map, batch_num)
                )
            
            # Process batches with semaphore to limit concurrency
            semaphore = asyncio.Semaphore(max_concurrent_batches)
            
            async def controlled_batch(batch_task):
                async with semaphore:
                    await batch_task
            
            # Run all batches with controlled concurrency
            await asyncio.gather(*[controlled_batch(task) for task in batch_tasks])
    
    def write_failed_tasks(self):
        """Write failed tasks to CSV"""
        if self.failed_tasks:
            with open(self.new_summary_path, 'a', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=self.summary_fields)
                writer.writerows(self.failed_tasks)
    
    async def run(self, batch_size: int = 100, max_concurrent_batches: int = 3):
        """Main execution method"""
        self.setup_folders()
        tasks_bucket, metadata_map = self.collect_tasks()
        
        if not tasks_bucket:
            print("⚠️ No tasks to process!")
            return
        
        print(f"\n{'='*40}")
        print(f"🚀 Starting async processing...")
        print(f"📊 Total tasks: {len(tasks_bucket)}")
        print(f"📦 Batch size: {batch_size}")
        print(f"⚡ Max concurrent batches: {max_concurrent_batches}")
        print(f"{'='*40}\n")
        
        await self.process_all_batches(tasks_bucket, metadata_map, batch_size, max_concurrent_batches)
        
        self.write_failed_tasks()
        
        print(f"\n{'='*40}")
        print(f"✨ Task Finished!")
        print(f"✅ Total Queued: {len(tasks_bucket)}")
        print(f"✅ Processed/Saved: {self.processed_count}")
        print(f"⏭️ Total Skipped (Filter): {self.skipped_count}")
        print(f"❌ Failed: {len(self.failed_tasks)}")
        print(f"📊 New Report: {self.new_summary_path}")
        print(f"{'='*40}")


def retry_organic_critical_and_errors(batch_size=100, max_concurrent_batches=3):
    """Main entry point"""
    processor = AsyncRetryProcessor()
    asyncio.run(processor.run(batch_size, max_concurrent_batches))


if __name__ == "__main__":
    # Adjust these parameters based on your needs and API rate limits
    # batch_size: Number of tasks per batch
    # max_concurrent_batches: Number of batches to process simultaneously
    retry_organic_critical_and_errors(batch_size=100, max_concurrent_batches=3)