import os, csv, re, json, time, base64
import asyncio
import aiohttp
import aiofiles
from concurrent.futures import ThreadPoolExecutor
from base import Helper
from itertools import cycle

# Import all API credentials from config
from config import USERNAME, PASSWORD, USERNAME1, PASSWORD1

# --- تنظیمات ---
MIN_SIZE_KB = 10 

DIRECTORY_DOMAINS = [
    'hipages.com.au', 'yelp.com', 'yelp.com.au', 'yellowpages.com.au', 
    'truelocal.com.au', 'facebook.com', 'instagram.com', 'starofservice.com.au',
    'checkatrade.com', 'buy.nsw.gov.au', 'localsearch.com.au', 'au.nextdoor.com', 'www.oneflare.com.au'
]

# Multiple API credentials - add more as needed
API_CREDENTIALS = [
    {'username': USERNAME, 'password': PASSWORD},
    {'username': USERNAME1, 'password': PASSWORD1},
    # Add more credentials here as needed
]

class SmartFixer(Helper):
    def __init__(self):
        super().__init__(base_output_folder="parsed_content_markdowns")
        self.report_csv = os.path.join(self.base_output_folder, "_final_scan_report.csv")
        self.executor = ThreadPoolExecutor(max_workers=10)
        
        # Create headers for each API credential
        self.api_headers = self._setup_multiple_apis()
        
        # Create locks for each API to prevent rate limiting
        self.api_locks = [asyncio.Lock() for _ in self.api_headers]
        
        # Track API usage statistics
        self.api_stats = [{'posted': 0, 'fetched': 0, 'errors': 0} for _ in self.api_headers]

    def _setup_multiple_apis(self):
        """Setup authentication headers for all API credentials"""
        headers_list = []
        
        print(f"🔐 Setting up {len(API_CREDENTIALS)} API accounts...")
        
        for i, cred in enumerate(API_CREDENTIALS):
            auth_str = f"{cred['username']}:{cred['password']}"
            token = base64.b64encode(auth_str.encode()).decode()
            
            headers = {
                'Authorization': f'Basic {token}',
                'Content-Type': 'application/json',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            headers_list.append(headers)
            print(f"   ✓ API #{i+1} configured")
        
        return headers_list

    def clean_target_url(self, url):
        """اصلاح یو‌ار‌ال مخصوص سایت Empire Roofing و حذف .php"""
        if "empireroofing.com.au" in url.lower():
            clean_url = re.sub(r'\.php$', '', url.strip())
            return clean_url
        return url.strip()

    async def process_file_async(self, file_path):
        """Process a single file asynchronously"""
        try:
            file_size = os.path.getsize(file_path) / 1024
            
            if file_size >= MIN_SIZE_KB:
                return None
                
            async with aiofiles.open(file_path, 'r', encoding='utf-8') as f:
                content = await f.read()
                data = json.loads(content)
                raw_url = data.get('data', {}).get('start_url')
            
            if "http" not in raw_url.lower():
                return None
                
            final_url = self.clean_target_url(raw_url)
            rg_match = re.search(r'_rg(\d+)', os.path.basename(file_path))
            r_grp = int(rg_match.group(1)) if rg_match else 0
            is_directory = any(domain in final_url.lower() for domain in DIRECTORY_DOMAINS)
            
            if is_directory:
                issue_type = "Error (Directory)"
                status = 'Skipped'
                is_target = False
            else:
                if r_grp <= 10:
                    issue_type = "CRITICAL (Top 10)"
                else:
                    issue_type = f"Error (Rank: {r_grp})"
                status = 'Pending'
                is_target = True

            return {
                'Issue': issue_type,
                'suburb': os.path.basename(os.path.dirname(os.path.dirname(file_path))),
                'rank_group': r_grp,
                'url': final_url,
                'actual_size': f"{file_size:.2f} KB",
                'status': status,
                'file_path': file_path,
                'is_target': is_target
            }
        except:
            return None

    async def scan_files_async(self):
        """Scan all files asynchronously"""
        print(f"🔍 Step 1: Scanning and Prioritizing (Async Mode)...")
        
        file_paths = []
        for root, dirs, files in os.walk(self.base_output_folder):
            if "organic" not in root.lower():
                continue
            for file in files:
                if file.endswith(".md") and not file.startswith("_"):
                    file_paths.append(os.path.join(root, file))
        
        tasks = [self.process_file_async(fp) for fp in file_paths]
        results = await asyncio.gather(*tasks)
        
        all_files_data = [r for r in results if r is not None]
        targets = [r for r in all_files_data if r.get('is_target')]
        
        csv_data = []
        for row in all_files_data:
            csv_row = {k: v for k, v in row.items() if k != 'is_target'}
            csv_data.append(csv_row)
        
        with open(self.report_csv, mode='w', newline='', encoding='utf-8') as csvfile:
            fields = ['Issue', 'suburb', 'rank_group', 'url', 'actual_size', 'status', 'file_path']
            writer = csv.DictWriter(csvfile, fieldnames=fields)
            writer.writeheader()
            writer.writerows(csv_data)
        
        print(f"✅ Step 1 Done. Found {len(targets)} targets from {len(file_paths)} files.")
        print(f"   💡 Using {len(self.api_headers)} API accounts for parallel processing")
        print(f"   - Top 10: {len([t for t in targets if t['rank_group'] <= 10])}")
        print(f"   - Others: {len([t for t in targets if t['rank_group'] > 10])}")
        return targets

    async def post_batch_async(self, session, batch, batch_num, smart_fix_dir, api_index):
        """Post a batch asynchronously using specific API credentials"""
        import post_page
        
        headers = self.api_headers[api_index]
        print(f"📡 Posting batch {batch_num} ({len(batch)} tasks) via API #{api_index + 1}...")
        
        try:
            loop = asyncio.get_event_loop()
            resp = await loop.run_in_executor(
                self.executor,
                lambda: post_page.post_onpage_task(
                    headers, batch, output_dir=smart_fix_dir, 
                    filename=f"smart_fix_batch_{batch_num}_api{api_index}.json"
                )
            )
            
            if not resp or resp.status_code != 200:
                print(f"❌ Batch post failed for batch {batch_num} (API #{api_index + 1})")
                self.api_stats[api_index]['errors'] += 1
                return None, None
            
            resp_data = resp.json()
            task_ids = []
            id_to_tag = {}
            
            for task in resp_data.get('tasks', []):
                tid = task.get('id')
                tag = task.get('data', {}).get('tag')
                if tid and tag:
                    task_ids.append(tid)
                    id_to_tag[tid] = tag
            
            self.api_stats[api_index]['posted'] += len(task_ids)
            return task_ids, id_to_tag
            
        except Exception as e:
            print(f"❌ Exception in post_batch (API #{api_index + 1}): {e}")
            self.api_stats[api_index]['errors'] += 1
            return None, None

    async def fetch_results_async(self, session, fetch_payload, batch_num, api_index):
        """Fetch results asynchronously using specific API credentials"""
        endpoint = "https://api.dataforseo.com/v3/on_page/content_parsing"
        headers = self.api_headers[api_index]
        
        try:
            async with session.post(
                endpoint, 
                headers=headers, 
                json=fetch_payload,
                timeout=aiohttp.ClientTimeout(total=120)
            ) as response:
                if response.status == 200:
                    self.api_stats[api_index]['fetched'] += len(fetch_payload)
                    return await response.json()
                else:
                    print(f"❌ Fetch API Error for batch {batch_num} (API #{api_index + 1}): {response.status}")
                    self.api_stats[api_index]['errors'] += 1
                    return None
        except Exception as e:
            print(f"❌ Fetch Connection Error for batch {batch_num} (API #{api_index + 1}): {e}")
            self.api_stats[api_index]['errors'] += 1
            return None

    async def save_result_async(self, tag_path, result_data):
        """Save result to file asynchronously"""
        try:
            async with aiofiles.open(tag_path, 'w', encoding='utf-8') as f:
                await f.write(json.dumps(result_data, indent=4))
            size = os.path.getsize(tag_path) / 1024
            print(f"   ✨ Success! New size: {size:.2f} KB")
            return True
        except Exception as e:
            print(f"   💥 Save Error {tag_path}: {e}")
            return False

    async def process_batch_async(self, session, batch, metadata_map, batch_num, smart_fix_dir, api_index):
        """Process a complete batch: post, wait, fetch, save"""
        # Use lock to prevent API rate limiting
        async with self.api_locks[api_index]:
            task_ids, id_to_tag = await self.post_batch_async(session, batch, batch_num, smart_fix_dir, api_index)
            # Small delay after posting to respect rate limits
            await asyncio.sleep(1)
        
        if not task_ids:
            return 0
        
        fetch_payload = []
        for tid in task_ids:
            tag = id_to_tag.get(tid)
            meta = metadata_map.get(tag)
            if meta:
                fetch_url = meta.get('url')
                if fetch_url:
                    fetch_payload.append({"id": tid, "url": fetch_url})
        
        print(f"⏳ Waiting 2 minutes for batch {batch_num} results (API #{api_index + 1})...")
        await asyncio.sleep(120)
        
        print(f"📥 Fetching results for {len(fetch_payload)} tasks (batch {batch_num}, API #{api_index + 1})...")
        
        async with self.api_locks[api_index]:
            res_json = await self.fetch_results_async(session, fetch_payload, batch_num, api_index)
            await asyncio.sleep(1)
        
        if not res_json:
            return 0
        
        save_tasks = []
        
        for task_res in res_json.get("tasks", []):
            tag_path = task_res.get("data", {}).get("tag")
            
            if not tag_path:
                tid = task_res.get("id")
                tag_path = id_to_tag.get(tid)
            
            if not tag_path:
                continue
            
            item = metadata_map.get(tag_path)
            status_msg = task_res.get('status_message')
            
            if status_msg == 'Ok.':
                save_tasks.append(self.save_result_async(tag_path, task_res))
            else:
                if item:
                    print(f"   ❌ API Error for {item['url']}: {status_msg}")
        
        if save_tasks:
            results = await asyncio.gather(*save_tasks)
            return sum(results)
        
        return 0

    async def process_all_batches_async(self, targets):
        """Process all batches concurrently using multiple APIs"""
        import post_page
        
        smart_fix_dir = "smart_fix"
        if not os.path.exists(smart_fix_dir):
            os.makedirs(smart_fix_dir)
        
        # Prepare all batches
        tasks_bucket = []
        metadata_map = {}
        
        for item in targets:
            tag = item['file_path']
            url = item['url']
            
            post_data = {
                "target": re.sub(r'(https?://|www\.)', '', url).split('/')[0],
                "start_url": url,
                "url": url,
                "enable_content_parsing": True,
                "max_crawl_pages": 1,
                "enable_javascript": True,
                "switch_pool": False,
                "load_resources": False,
                "enable_browser_rendering": False,
                "enable_xhr": False,
                "disable_cookie_popup": False,
                "browser_preset": "desktop",
                "proxy_country": "AU",
                "use_advanced_anti_robot_protection": False,
                "browser_wait_until": "fully_loaded",
                "wait_for_content_timeout": 60,
                "tag": tag
            }
            tasks_bucket.append(post_data)
            metadata_map[tag] = item
        
        # Split into batches
        batch_size = 50
        batches = [tasks_bucket[i:i + batch_size] for i in range(0, len(tasks_bucket), batch_size)]
        
        print(f"📦 Total batches to process: {len(batches)}")
        print(f"⚡ Parallel processing with {len(self.api_headers)} APIs")
        
        # Process batches concurrently using multiple APIs
        async with aiohttp.ClientSession() as session:
            # Process multiple batches at once (one per API account)
            num_apis = len(self.api_headers)
            concurrent_batches = num_apis  # Process as many batches as we have APIs
            total_processed = 0
            
            for i in range(0, len(batches), concurrent_batches):
                batch_group = batches[i:i + concurrent_batches]
                
                # Assign each batch to a different API (round-robin)
                batch_tasks = [
                    self.process_batch_async(
                        session, batch, metadata_map, 
                        i + j, smart_fix_dir, j % num_apis  # Distribute across APIs
                    )
                    for j, batch in enumerate(batch_group)
                ]
                
                results = await asyncio.gather(*batch_tasks)
                total_processed += sum(results)
                
                print(f"📊 Progress: {total_processed}/{len(targets)} files processed")
                self._print_api_stats()
        
        return total_processed

    def _print_api_stats(self):
        """Print API usage statistics"""
        print("\n📈 API Usage Statistics:")
        for i, stats in enumerate(self.api_stats):
            print(f"   API #{i+1}: Posted={stats['posted']}, Fetched={stats['fetched']}, Errors={stats['errors']}")
        print()

    async def run_mega_fixer_async(self):
        """Main async orchestrator"""
        print("=" * 60)
        print("🚀 MULTI-API SMART FIXER STARTED")
        print("=" * 60)
        
        # Step 1: Scan files
        targets = await self.scan_files_async()
        
        if not targets:
            print("🏁 No targets to rescue.")
            return
        
        # Step 2: Process batches with multiple APIs
        total_processed = await self.process_all_batches_async(targets)
        
        print("\n" + "=" * 60)
        print(f"🏁 FINISHED: Rescued {total_processed}/{len(targets)} files")
        print("=" * 60)
        self._print_api_stats()

    def run_mega_fixer(self):
        """Sync wrapper for async execution"""
        asyncio.run(self.run_mega_fixer_async())

if __name__ == "__main__":
    SmartFixer().run_mega_fixer()