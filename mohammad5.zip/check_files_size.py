import os
import csv
from collections import defaultdict

def check_file_sizes(directory, min_size_kb=5):
    # تبدیل کیلوبایت به بایت
    min_size_bytes = min_size_kb * 1024
    results = []
    
    if not os.path.exists(directory):
        print(f"❌ Error: Directory '{directory}' not found!")
        return

    print(f"🔍 Scanning files in '{directory}' for sizes below {min_size_kb}KB...")
    
    # Dictionary to track statistics by folder type
    folder_stats = defaultdict(lambda: {'total': 0, 'low_quality': 0})
    
    low_quality_count = 0
    total_files_scanned = 0
    
    for root, dirs, files in os.walk(directory):
        for filename in files:
            if filename.endswith('.md'):  # Only .md files
                filepath = os.path.join(root, filename)
                file_size = os.path.getsize(filepath)
                
                # Extract folder type (e.g., "organic", "people_also_ask", etc.)
                path_parts = root.split(os.sep)
                folder_type = path_parts[-1] if len(path_parts) > 0 else 'unknown'
                
                # Update folder statistics
                folder_stats[folder_type]['total'] += 1
                total_files_scanned += 1
                
                if file_size < min_size_bytes:
                    size_kb = round(file_size / 1024, 2)
                    results.append({
                        'file_name': filename,
                        'full_path': filepath,
                        'folder_type': folder_type,
                        'size_kb': size_kb,
                        'status': '⚠️ LOW_CONTENT'
                    })
                    folder_stats[folder_type]['low_quality'] += 1
                    low_quality_count += 1
                    print(f"⚠️ Warning: {filepath} is only {size_kb}KB")
    
    # ذخیره نتایج در یک فایل CSV
    output_file = 'low_quality_content_report.csv'
    with open(output_file, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=['file_name', 'full_path', 'folder_type', 'size_kb', 'status'])
        writer.writeheader()
        writer.writerows(results)

    # Print summary
    print("\n" + "="*60)
    print(f"✅ Scan Complete!")
    print(f"📊 Total Files Scanned: {total_files_scanned}")
    print(f"🚨 Low Quality Files Found: {low_quality_count}")
    print("="*60)
    
    # Print statistics by folder type
    print("\n📁 Statistics by Folder Type:")
    print("-"*60)
    for folder_type in sorted(folder_stats.keys()):
        stats = folder_stats[folder_type]
        percentage = (stats['low_quality'] / stats['total'] * 100) if stats['total'] > 0 else 0
        print(f"📂 {folder_type}:")
        print(f"   Total: {stats['total']} | Low Quality: {stats['low_quality']} ({percentage:.1f}%)")
    
    print("-"*60)
    print(f"📝 Report saved to: {output_file}")
    print("="*60)

if __name__ == "__main__":
    # مسیر پوشه‌ای که فایل‌های مارک‌داون در آن هستند
    target_directory = 'parsed_content_markdowns'
    check_file_sizes(target_directory)