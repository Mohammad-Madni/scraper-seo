import os
import csv
import json
import re
from datetime import datetime

PROGRESS_FILE = "parsing_progress.json"


class Helper:
    def __init__(self):
        # base folder where parsed markdowns should be
        self.base_output_folder = "parsed_content_markdowns"
        self.summary_path = "parsed_content_markdowns/_error_summary.csv"
        self.summary_fields = [
            "Issue",
            "suburb",
            "service",
            "type",
            "rank",
            "rank_group",
            "url",
            "error_type",
            "status",
        ]

    def _slugify(self, text):
        return str(text).strip().replace(" ", "-")

    def _extract_domain(self, url):
        if not url:
            return "metadata"
        return re.sub(r"(https?://|www\.)", "", url).split("/")[0].split(".")[0]

    def log_error_to_files(
        self,
        type_path,
        error_msg,
        item_type,
        rank_abs,
        rank_gp,
        suburb,
        service,
        url,
    ):
        """ثبت خطاها در فایل‌های مربوطه"""
        try:
            rank_int = int(rank_abs) if str(rank_abs).isdigit() else 0
        except:
            rank_int = 0

        issue_label = "CRITICAL" if rank_int <= 5 else "Error"
        log_name = "warning.txt" if rank_int <= 5 else "error.txt"

        item_path = os.path.join(
            "parsed_content_markdowns", self._slugify(suburb), self._slugify(item_type)
        )
        if not os.path.exists(item_path):
            os.makedirs(item_path)

        with open(os.path.join(item_path, log_name), "a", encoding="utf-8") as f:
            f.write(
                f"[{issue_label}] Rank: {rank_abs} (RG: {rank_gp}) | Error: {error_msg} | URL: {url}\n"
             )

        with open(self.summary_path, "a", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=self.summary_fields)
            writer.writerow(
                {
                    "Issue": issue_label,
                    "suburb": suburb,
                    "service": service,
                    "type": item_type,
                    "rank": rank_abs,
                    "rank_group": rank_gp,
                    "url": url,
                    "error_type": log_name.replace(".txt", ""),
                    "status": error_msg,
                }
            )


# ---- Enhanced Missing File Checker with File Creation ----
class MissingFileChecker(Helper):
    def __init__(self, create_missing=True):
        super().__init__()
        self.input_folder = "serp_outputs"
        self.create_missing = create_missing
        self.created_count = 0
        self.missing_count = 0

    def create_empty_md_file(self, file_path, url, suburb, service, item_type, rank_abs, rank_gp):
        """Create an empty markdown file with metadata in JSON format"""
        
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        
        # Create JSON structure similar to your parsed files
        file_content = {
            "id": None,
            "status_code": 20000,
            "status_message": "File created as placeholder - content not parsed",
            "time": datetime.now().strftime("%H:%M:%S.%f")[:-3],
            "cost": 0,
            "result_count": 1,
            "path": [],
            "data": {
                "api": "on_page",
                "function": "content_parsing",
                "se": None,
                "se_type": None,
                "language_code": None,
                "location_code": None,
                "keyword": None,
                "device": None,
                "os": None,
                "tag": file_path,
                "start_url": url,
                "target": self._extract_domain(url)
            },
            "result": [
                {
                    "crawl_progress": "placeholder",
                    "crawl_status": {
                        "max_crawl_pages": 1,
                        "pages_in_queue": 0,
                        "pages_crawled": 0
                    },
                    "total_items_count": 0,
                    "items_count": 0,
                    "items": [],
                    "metadata": {
                        "suburb": suburb,
                        "service": service,
                        "type": item_type,
                        "rank_absolute": rank_abs,
                        "rank_group": rank_gp,
                        "url": url,
                        "created_as_placeholder": True,
                        "created_at": datetime.now().isoformat()
                    }
                }
            ]
        }
        
        # Write JSON content to file
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(file_content, f, indent=4, ensure_ascii=False)
        
        # Get file size
        size_kb = os.path.getsize(file_path) / 1024
        
        return size_kb

    def check_files(self):
        csv_files = sorted(
            [f for f in os.listdir(self.input_folder) if f.endswith(".csv")]
        )

        print(f"🔍 Found {len(csv_files)} SERP CSV files.")
        print(f"{'='*60}\n")

        for csv_filename in csv_files:
            full_path = os.path.join(self.input_folder, csv_filename)
            print(f"📄 Checking: {csv_filename}")

            with open(full_path, mode="r", encoding="utf-8") as file:
                reader = list(csv.DictReader(file))
                file_missing_count = 0
                file_created_count = 0
                
                for row in reader:
                    item_type = str(row.get("type", "other")).lower().replace(" ", "_")
                    url = row.get("url") or ""
                    suburb = row.get("suburb") or row.get("Suburb") or "Unknown"
                    service = row.get("service") or row.get("Service") or "service"
                    rank_abs = row.get("rank_absolute", "0")
                    rank_gp = row.get("rank_group", "0")

                    domain_match = self._extract_domain(url)
                    file_name = (
                        f"type-{item_type}_rg{rank_gp}_ra{rank_abs}_{domain_match}.md"
                    )
                    full_file_path = os.path.join(
                        "parsed_content_markdowns",
                        self._slugify(suburb),
                        self._slugify(item_type),
                        file_name,
                    )
                    
                    if not os.path.exists(full_file_path):
                        self.missing_count += 1
                        file_missing_count += 1
                        
                        if self.create_missing:
                            # Create the missing file
                            size_kb = self.create_empty_md_file(
                                full_file_path, url, suburb, service, 
                                item_type, rank_abs, rank_gp
                            )
                            self.created_count += 1
                            file_created_count += 1
                            print(f"   ✅ Created: {file_name} ({size_kb:.2f} KB)")
                        else:
                            print(f"   ❌ Missing: {file_name}")
                        
                        # Still log the error
                        self.log_error_to_files(
                            type_path=os.path.join(item_type),
                            error_msg="File Not Found - Placeholder Created" if self.create_missing else "File Not Found",
                            item_type=item_type,
                            rank_abs=rank_abs,
                            rank_gp=rank_gp,
                            suburb=suburb,
                            service=service,
                            url=url,
                        )
                
                if file_missing_count > 0:
                    print(f"   📊 Summary: {file_missing_count} missing", end="")
                    if self.create_missing:
                        print(f" → {file_created_count} created")
                    else:
                        print()
                else:
                    print(f"   ✅ All files present")
            
            print()  # Empty line between files
        
        # Final summary
        print(f"{'='*60}")
        print(f"🏁 FINAL SUMMARY")
        print(f"{'='*60}")
        print(f"Total missing files found: {self.missing_count}")
        if self.create_missing:
            print(f"Total files created: {self.created_count}")
            print(f"✨ All missing files have been created as placeholders!")
        print(f"{'='*60}")


if __name__ == "__main__":
    # Set create_missing=True to create files, False to just report
    checker = MissingFileChecker(create_missing=True)
    checker.check_files()