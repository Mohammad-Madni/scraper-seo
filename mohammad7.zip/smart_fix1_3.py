import os, csv, re, json, time
import asyncio
import aiohttp
import aiofiles
from concurrent.futures import ThreadPoolExecutor
from base import Helper

# --- تنظیمات ---
MIN_SIZE_KB = 10 

DIRECTORY_DOMAINS = [
    'hipages.com.au', 'yelp.com', 'yelp.com.au', 'yellowpages.com.au', 
    'truelocal.com.au', 'facebook.com', 'instagram.com', 'starofservice.com.au',
    'checkatrade.com', 'buy.nsw.gov.au', 'localsearch.com.au', 'au.nextdoor.com'
]

# Fallback configurations - from minimal to full
FALLBACK_CONFIGS = [
    {
        "name": "Minimal",
        "config": {}
    },
    {
        "name": "JavaScript Enabled",
        "config": {
            "enable_javascript": True
        }
    },
    {
        "name": "Browser Rendering",
        "config": {
            "enable_javascript": True,
            "enable_browser_rendering": True
        }
    },
    {
        "name": "Full Stack",
        "config": {
            "enable_javascript": True,
            "enable_browser_rendering": True,
            "enable_xhr": True,
            "disable_cookie_popup": True,
            "load_resources": True,
            "browser_wait_until": "fully_loaded",
            "wait_for_content_timeout": 30
        }
    }
]

class SmartFixer(Helper):
    def __init__(self):
        super().__init__(base_output_folder="parsed_content_markdowns")
        self.report_csv = os.path.join(self.base_output_folder, "_final_scan_report.csv")
        self.executor = ThreadPoolExecutor(max_workers=10)
        self.fallback_stats = {config["name"]: 0 for config in FALLBACK_CONFIGS}

    def clean_target_url(self, url):
        """اصلاح یو‌ار‌ال مخصوص سایت Empire Roofing و حذف .php"""
        if "empireroofing.com.au" in url.lower():
            clean_url = re.sub(r'\.php$', '', url.strip())
            return clean_url
        return url.strip()

    async def process_file_async(self, file_path):
        """Process a single file asynchronously"""
        try:
            file_size = os.path.getsize(file_path) / 1024
            
            if file_size >= MIN_SIZE_KB:
                return None
                
            async with aiofiles.open(file_path, 'r', encoding='utf-8') as f:
                content = await f.read()
                data = json.loads(content)
                raw_url = data.get('data', {}).get('start_url')
            
            if "http" not in raw_url.lower():
                return None
                
            final_url = self.clean_target_url(raw_url)
            rg_match = re.search(r'_rg(\d+)', os.path.basename(file_path))
            r_grp = int(rg_match.group(1)) if rg_match else 0
            is_directory = any(domain in final_url.lower() for domain in DIRECTORY_DOMAINS)
            
            issue_type = "Error (Directory)" if is_directory else "CRITICAL (Top 10)"
            if not is_directory and r_grp > 10:
                issue_type = f"Error (Low Rank: {r_grp})"

            return {
                'Issue': issue_type,
                'suburb': os.path.basename(os.path.dirname(os.path.dirname(file_path))),
                'rank_group': r_grp,
                'url': final_url,
                'actual_size': f"{file_size:.2f} KB",
                'status': 'Skipped' if (is_directory or r_grp > 10) else 'Pending',
                'file_path': file_path,
                'is_critical': issue_type == "CRITICAL (Top 10)"
            }
        except:
            return None

    async def scan_files_async(self):
        """Scan all files asynchronously"""
        print(f"🔍 Step 1: Scanning and Prioritizing (Async Mode)...")
        
        file_paths = []
        for root, dirs, files in os.walk(self.base_output_folder):
            if "organic" not in root.lower():
                continue
            for file in files:
                if file.endswith(".md") and not file.startswith("_"):
                    file_paths.append(os.path.join(root, file))
        
        # Process files concurrently
        tasks = [self.process_file_async(fp) for fp in file_paths]
        results = await asyncio.gather(*tasks)
        
        # Filter out None results
        all_files_data = [r for r in results if r is not None]
        targets = [r for r in all_files_data if r.get('is_critical')]
        
        # Write CSV synchronously (fast operation) - remove is_critical field for CSV
        csv_data = []
        for row in all_files_data:
            csv_row = {k: v for k, v in row.items() if k != 'is_critical'}
            csv_data.append(csv_row)
        
        with open(self.report_csv, mode='w', newline='', encoding='utf-8') as csvfile:
            fields = ['Issue', 'suburb', 'rank_group', 'url', 'actual_size', 'status', 'file_path']
            writer = csv.DictWriter(csvfile, fieldnames=fields)
            writer.writeheader()
            writer.writerows(csv_data)
        
        print(f"✅ Step 1 Done. Found {len(targets)} Top 10 targets from {len(file_paths)} files.")
        return targets

    def create_post_data(self, url, tag, fallback_level=0):
        """Create post data with specified fallback configuration"""
        base_config = {
            "target": re.sub(r'(https?://|www\.)', '', url).split('/')[0],
            "start_url": url,
            "url": url,
            "enable_content_parsing": True,
            "max_crawl_pages": 1,
            "browser_preset": "desktop",
            "proxy_country": "AU",
            "use_advanced_anti_robot_protection": True,
            "tag": tag
        }
        
        # Merge with fallback config
        if fallback_level < len(FALLBACK_CONFIGS):
            fallback_config = FALLBACK_CONFIGS[fallback_level]["config"]
            base_config.update(fallback_config)
        
        return base_config

    async def post_batch_with_fallback_async(self, session, batch, batch_num, smart_fix_dir, fallback_level=0):
        """Post a batch with specified fallback level"""
        import post_page
        
        config_name = FALLBACK_CONFIGS[fallback_level]["name"] if fallback_level < len(FALLBACK_CONFIGS) else "Custom"
        print(f"📡 Posting batch {batch_num} ({len(batch)} tasks) - Config: {config_name}...")
        
        # Use sync post_page in executor to avoid blocking
        loop = asyncio.get_event_loop()
        resp = await loop.run_in_executor(
            self.executor,
            lambda: post_page.post_onpage_task(
                self.headers, batch, output_dir=smart_fix_dir, 
                filename=f"smart_fix_batch_{batch_num}_lvl{fallback_level}.json"
            )
        )
        
        if not resp or resp.status_code != 200:
            print(f"❌ Batch post failed for batch {batch_num}")
            return None, None
        
        resp_data = resp.json()
        task_ids = []
        id_to_tag = {}
        
        for task in resp_data.get('tasks', []):
            tid = task.get('id')
            tag = task.get('data', {}).get('tag')
            if tid and tag:
                task_ids.append(tid)
                id_to_tag[tid] = tag
        
        return task_ids, id_to_tag

    async def fetch_results_async(self, session, fetch_payload, batch_num):
        """Fetch results asynchronously"""
        endpoint = "https://api.dataforseo.com/v3/on_page/content_parsing"
        
        try:
            async with session.post(
                endpoint, 
                headers=self.headers, 
                json=fetch_payload,
                timeout=aiohttp.ClientTimeout(total=120)
            ) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    print(f"❌ Fetch API Error for batch {batch_num}: {response.status}")
                    return None
        except Exception as e:
            print(f"❌ Fetch Connection Error for batch {batch_num}: {e}")
            return None

    async def save_result_async(self, tag_path, result_data):
        """Save result to file asynchronously"""
        try:
            async with aiofiles.open(tag_path, 'w', encoding='utf-8') as f:
                await f.write(json.dumps(result_data, indent=4))
            size = os.path.getsize(tag_path) / 1024
            print(f"   ✨ Success! New size: {size:.2f} KB")
            return True
        except Exception as e:
            print(f"   💥 Save Error {tag_path}: {e}")
            return False

    def validate_result(self, result_data, min_size_kb=MIN_SIZE_KB):
        """Check if result is valid and has sufficient content"""
        try:
            # Check if result has content
            content = result_data.get('result', [{}])[0].get('items', [{}])[0].get('content', '')
            if not content:
                return False
            
            # Check content size
            content_size = len(json.dumps(result_data)) / 1024
            if content_size < min_size_kb:
                return False
            
            return True
        except:
            return False

    async def process_batch_with_fallback_async(self, session, batch, metadata_map, batch_num, smart_fix_dir):
        """Process a batch with progressive fallback"""
        failed_items = []
        successful_count = 0
        
        # Try each fallback level
        for fallback_level in range(len(FALLBACK_CONFIGS)):
            if fallback_level == 0:
                current_batch = batch
            else:
                # Only retry failed items
                if not failed_items:
                    break
                current_batch = failed_items
                failed_items = []
            
            config_name = FALLBACK_CONFIGS[fallback_level]["name"]
            print(f"\n🔄 Batch {batch_num} - Trying {config_name} configuration ({len(current_batch)} items)...")
            
            # Post batch with current fallback level
            task_ids, id_to_tag = await self.post_batch_with_fallback_async(
                session, current_batch, batch_num, smart_fix_dir, fallback_level
            )
            
            if not task_ids:
                print(f"❌ Failed to post batch with {config_name}")
                continue
            
            # Prepare fetch payload
            fetch_payload = []
            for tid in task_ids:
                tag = id_to_tag.get(tid)
                meta = metadata_map.get(tag)
                if meta:
                    fetch_url = meta.get('url')
                    if fetch_url:
                        fetch_payload.append({"id": tid, "url": fetch_url})
            
            # Wait for processing
            wait_time = 120 if fallback_level < 2 else 180  # More time for browser rendering
            print(f"⏳ Waiting {wait_time} seconds for {config_name} results...")
            await asyncio.sleep(wait_time)
            
            # Fetch results
            print(f"📥 Fetching results for {len(fetch_payload)} tasks...")
            res_json = await self.fetch_results_async(session, fetch_payload, batch_num)
            
            if not res_json:
                print(f"❌ Failed to fetch results with {config_name}")
                continue
            
            # Process results
            for task_res in res_json.get("tasks", []):
                tag_path = task_res.get("data", {}).get("tag")
                
                if not tag_path:
                    tid = task_res.get("id")
                    tag_path = id_to_tag.get(tid)
                
                if not tag_path:
                    continue
                
                item = metadata_map.get(tag_path)
                status_msg = task_res.get('status_message')
                
                if status_msg == 'Ok.' and self.validate_result(task_res):
                    # Valid result - save it
                    if await self.save_result_async(tag_path, task_res):
                        successful_count += 1
                        self.fallback_stats[config_name] += 1
                        print(f"   ✅ Saved with {config_name}")
                else:
                    # Failed or insufficient content - add to retry list
                    if fallback_level < len(FALLBACK_CONFIGS) - 1:
                        # Find original post_data for this item
                        for post_data in current_batch:
                            if post_data.get('tag') == tag_path:
                                failed_items.append(post_data)
                                break
                        print(f"   ⚠️ Will retry with next configuration")
                    else:
                        print(f"   ❌ Failed all fallback attempts for {item.get('url', 'unknown')}")
        
        return successful_count

    async def process_all_batches_async(self, targets):
        """Process all batches concurrently with fallback support"""
        import post_page
        
        smart_fix_dir = "smart_fix"
        if not os.path.exists(smart_fix_dir):
            os.makedirs(smart_fix_dir)
        
        # Prepare all batches
        tasks_bucket = []
        metadata_map = {}
        
        for item in targets:
            tag = item['file_path']
            url = item['url']
            
            # Start with minimal config (level 0)
            post_data = self.create_post_data(url, tag, fallback_level=0)
            tasks_bucket.append(post_data)
            metadata_map[tag] = item
        
        # Split into batches
        batch_size = 100
        batches = [tasks_bucket[i:i + batch_size] for i in range(0, len(tasks_bucket), batch_size)]
        
        # Process batches with controlled concurrency
        async with aiohttp.ClientSession() as session:
            concurrent_batches = 2  # Reduced for fallback processing
            total_processed = 0
            
            for i in range(0, len(batches), concurrent_batches):
                batch_group = batches[i:i + concurrent_batches]
                batch_tasks = [
                    self.process_batch_with_fallback_async(
                        session, batch, metadata_map, 
                        i + j, smart_fix_dir
                    )
                    for j, batch in enumerate(batch_group)
                ]
                
                results = await asyncio.gather(*batch_tasks)
                total_processed += sum(results)
        
        return total_processed

    async def run_mega_fixer_async(self):
        """Main async orchestrator"""
        # Step 1: Scan files
        targets = await self.scan_files_async()
        
        if not targets:
            print("🏁 No high-priority targets to rescue.")
            return
        
        # Step 2: Process batches with fallback
        total_processed = await self.process_all_batches_async(targets)
        
        # Print fallback statistics
        print("\n" + "="*60)
        print("📊 Fallback Configuration Statistics:")
        print("="*60)
        for config_name, count in self.fallback_stats.items():
            print(f"   {config_name}: {count} successful")
        print("="*60)
        
        print(f"\n🏁 Finished. Rescued {total_processed}/{len(targets)} files.")

    def run_mega_fixer(self):
        """Sync wrapper for async execution"""
        asyncio.run(self.run_mega_fixer_async())

if __name__ == "__main__":
    SmartFixer().run_mega_fixer()