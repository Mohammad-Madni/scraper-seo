import os, csv, re, json, time
import asyncio
import aiohttp
import aiofiles
from concurrent.futures import ThreadPoolExecutor
from base import Helper

# --- تنظیمات ---
MIN_SIZE_KB = 10 

DIRECTORY_DOMAINS = [
    'hipages.com.au', 'yelp.com', 'yelp.com.au', 'yellowpages.com.au', 
    'truelocal.com.au', 'facebook.com', 'instagram.com', 'starofservice.com.au',
    'checkatrade.com', 'buy.nsw.gov.au', 'localsearch.com.au', 'au.nextdoor.com'
]

class SmartFixer(Helper):
    def __init__(self):
        super().__init__(base_output_folder="parsed_content_markdowns")
        self.report_csv = os.path.join(self.base_output_folder, "_final_scan_report.csv")
        self.executor = ThreadPoolExecutor(max_workers=10)

    def clean_target_url(self, url):
        """اصلاح یو‌ار‌ال مخصوص سایت Empire Roofing و حذف .php"""
        if "empireroofing.com.au" in url.lower():
            clean_url = re.sub(r'\.php$', '', url.strip())
            return clean_url
        return url.strip()

    async def process_file_async(self, file_path):
        """Process a single file asynchronously"""
        try:
            file_size = os.path.getsize(file_path) / 1024
            
            if file_size >= MIN_SIZE_KB:
                return None
                
            async with aiofiles.open(file_path, 'r', encoding='utf-8') as f:
                content = await f.read()
                data = json.loads(content)
                raw_url = data.get('data', {}).get('start_url')
            
            if "http" not in raw_url.lower():
                return None
                
            final_url = self.clean_target_url(raw_url)
            rg_match = re.search(r'_rg(\d+)', os.path.basename(file_path))
            r_grp = int(rg_match.group(1)) if rg_match else 0
            is_directory = any(domain in final_url.lower() for domain in DIRECTORY_DOMAINS)
            
            issue_type = "Error (Directory)" if is_directory else "CRITICAL (Top 10)"
            if not is_directory and r_grp > 10:
                issue_type = f"Error (Low Rank: {r_grp})"

            return {
                'Issue': issue_type,
                'suburb': os.path.basename(os.path.dirname(os.path.dirname(file_path))),
                'rank_group': r_grp,
                'url': final_url,
                'actual_size': f"{file_size:.2f} KB",
                'status': 'Skipped' if (is_directory or r_grp > 10) else 'Pending',
                'file_path': file_path,
                'is_critical': issue_type == "CRITICAL (Top 10)"
            }
        except:
            return None

    async def scan_files_async(self):
        """Scan all files asynchronously"""
        print(f"🔍 Step 1: Scanning and Prioritizing (Async Mode)...")
        
        file_paths = []
        for root, dirs, files in os.walk(self.base_output_folder):
            if "organic" not in root.lower():
                continue
            for file in files:
                if file.endswith(".md") and not file.startswith("_"):
                    file_paths.append(os.path.join(root, file))
        
        # Process files concurrently
        tasks = [self.process_file_async(fp) for fp in file_paths]
        results = await asyncio.gather(*tasks)
        
        # Filter out None results
        all_files_data = [r for r in results if r is not None]
        targets = [r for r in all_files_data if r.get('is_critical')]
        
        # Write CSV synchronously (fast operation) - remove is_critical field for CSV
        csv_data = []
        for row in all_files_data:
            csv_row = {k: v for k, v in row.items() if k != 'is_critical'}
            csv_data.append(csv_row)
        
        with open(self.report_csv, mode='w', newline='', encoding='utf-8') as csvfile:
            fields = ['Issue', 'suburb', 'rank_group', 'url', 'actual_size', 'status', 'file_path']
            writer = csv.DictWriter(csvfile, fieldnames=fields)
            writer.writeheader()
            writer.writerows(csv_data)
        
        print(f"✅ Step 1 Done. Found {len(targets)} Top 10 targets from {len(file_paths)} files.")
        return targets

    async def post_batch_async(self, session, batch, batch_num, smart_fix_dir):
        """Post a batch asynchronously"""
        import post_page
        
        print(f"📡 Posting batch {batch_num} ({len(batch)} tasks)...")
        
        # Use sync post_page in executor to avoid blocking
        loop = asyncio.get_event_loop()
        resp = await loop.run_in_executor(
            self.executor,
            lambda: post_page.post_onpage_task(
                self.headers, batch, output_dir=smart_fix_dir, 
                filename=f"smart_fix_batch_{batch_num}.json"
            )
        )
        
        if not resp or resp.status_code != 200:
            print(f"❌ Batch post failed for batch {batch_num}")
            return None, None
        
        resp_data = resp.json()
        task_ids = []
        id_to_tag = {}
        
        for task in resp_data.get('tasks', []):
            tid = task.get('id')
            tag = task.get('data', {}).get('tag')
            if tid and tag:
                task_ids.append(tid)
                id_to_tag[tid] = tag
        
        return task_ids, id_to_tag

    async def fetch_results_async(self, session, fetch_payload, batch_num):
        """Fetch results asynchronously"""
        endpoint = "https://api.dataforseo.com/v3/on_page/content_parsing"
        
        try:
            async with session.post(
                endpoint, 
                headers=self.headers, 
                json=fetch_payload,
                timeout=aiohttp.ClientTimeout(total=120)
            ) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    print(f"❌ Fetch API Error for batch {batch_num}: {response.status}")
                    return None
        except Exception as e:
            print(f"❌ Fetch Connection Error for batch {batch_num}: {e}")
            return None

    async def save_result_async(self, tag_path, result_data):
        """Save result to file asynchronously"""
        try:
            async with aiofiles.open(tag_path, 'w', encoding='utf-8') as f:
                await f.write(json.dumps(result_data, indent=4))
            size = os.path.getsize(tag_path) / 1024
            print(f"   ✨ Success! New size: {size:.2f} KB")
            return True
        except Exception as e:
            print(f"   💥 Save Error {tag_path}: {e}")
            return False

    async def process_batch_async(self, session, batch, metadata_map, batch_num, smart_fix_dir):
        """Process a complete batch: post, wait, fetch, save"""
        # Post batch
        task_ids, id_to_tag = await self.post_batch_async(session, batch, batch_num, smart_fix_dir)
        
        if not task_ids:
            return 0
        
        # Prepare fetch payload
        fetch_payload = []
        for tid in task_ids:
            tag = id_to_tag.get(tid)
            meta = metadata_map.get(tag)
            if meta:
                fetch_url = meta.get('url')
                if fetch_url:
                    fetch_payload.append({"id": tid, "url": fetch_url})
        
        # Wait for processing
        print(f"⏳ Waiting 2 minutes for batch {batch_num} results...")
        await asyncio.sleep(120)
        
        # Fetch results
        print(f"📥 Fetching results for {len(fetch_payload)} tasks (batch {batch_num})...")
        res_json = await self.fetch_results_async(session, fetch_payload, batch_num)
        
        if not res_json:
            return 0
        
        # Save results concurrently
        save_tasks = []
        successful_count = 0
        
        for task_res in res_json.get("tasks", []):
            tag_path = task_res.get("data", {}).get("tag")
            
            if not tag_path:
                tid = task_res.get("id")
                tag_path = id_to_tag.get(tid)
            
            if not tag_path:
                continue
            
            item = metadata_map.get(tag_path)
            status_msg = task_res.get('status_message')
            
            if status_msg == 'Ok.':
                save_tasks.append(self.save_result_async(tag_path, task_res))
            else:
                if item:
                    print(f"   ❌ API Error for {item['url']}: {status_msg}")
        
        # Wait for all saves to complete
        if save_tasks:
            results = await asyncio.gather(*save_tasks)
            successful_count = sum(results)
        
        return successful_count

    async def process_all_batches_async(self, targets):
        """Process all batches concurrently"""
        import post_page
        
        smart_fix_dir = "smart_fix"
        if not os.path.exists(smart_fix_dir):
            os.makedirs(smart_fix_dir)
        
        # Prepare all batches
        tasks_bucket = []
        metadata_map = {}
        
        for item in targets:
            tag = item['file_path']
            url = item['url']
            
            post_data = {
                "target": re.sub(r'(https?://|www\.)', '', url).split('/')[0],
                "start_url": url,
                "url": url,
                "enable_content_parsing": True,
                "max_crawl_pages": 1,
                "enable_javascript": True,
                "switch_pool": True,
                "load_resources": False,
                "enable_browser_rendering": False,
                "enable_xhr": False,
                "disable_cookie_popup": False,
                "browser_preset": "desktop",
                "proxy_country": "AU",
                "use_advanced_anti_robot_protection": False,
                "browser_wait_until": "fully_loaded",
                "wait_for_content_timeout": 30,
                "tag": tag
            }
            tasks_bucket.append(post_data)
            metadata_map[tag] = item
        
        # Split into batches
        batch_size = 100
        batches = [tasks_bucket[i:i + batch_size] for i in range(0, len(tasks_bucket), batch_size)]
        
        # Process batches concurrently (with some limit to avoid overwhelming API)
        async with aiohttp.ClientSession() as session:
            # Process 3 batches at a time to balance speed and API limits
            concurrent_batches = 3
            total_processed = 0
            
            for i in range(0, len(batches), concurrent_batches):
                batch_group = batches[i:i + concurrent_batches]
                batch_tasks = [
                    self.process_batch_async(
                        session, batch, metadata_map, 
                        i + j, smart_fix_dir
                    )
                    for j, batch in enumerate(batch_group)
                ]
                
                results = await asyncio.gather(*batch_tasks)
                total_processed += sum(results)
        
        return total_processed

    async def run_mega_fixer_async(self):
        """Main async orchestrator"""
        # Step 1: Scan files
        targets = await self.scan_files_async()
        
        if not targets:
            print("🏁 No high-priority targets to rescue.")
            return
        
        # Step 2: Process batches
        total_processed = await self.process_all_batches_async(targets)
        
        print(f"🏁 Finished. Rescued {total_processed}/{len(targets)} files.")

    def run_mega_fixer(self):
        """Sync wrapper for async execution"""
        asyncio.run(self.run_mega_fixer_async())

if __name__ == "__main__":
    SmartFixer().run_mega_fixer()