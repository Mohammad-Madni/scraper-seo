import os, csv, re, json, time
import argparse
from base import Helper

DIRECTORY_DOMAINS = [
    'hipages.com.au', 'yelp.com', 'yelp.com.au', 'yellowpages.com.au', 
    'truelocal.com.au', 'facebook.com', 'instagram.com', 'starofservice.com.au',
    'checkatrade.com', 'buy.nsw.gov.au', 'localsearch.com.au', 'au.nextdoor.com'
]

class UnifiedSmartFixer(Helper):
    def __init__(self, folder="parsed_content_markdowns", mode="heavy", min_size_kb=5):
        """
        Unified fixer for both folders
        
        Args:
            folder: Target folder to fix
            mode: 'heavy' (full JS rendering) or 'light' (switch pool only)
            min_size_kb: Minimum file size threshold
        """
        super().__init__(base_output_folder=folder)
        self.mode = mode
        self.min_size_kb = min_size_kb
        self.report_csv = os.path.join(self.base_output_folder, f"_fix_report_{mode}.csv")
        
        print(f"\n{'='*70}")
        print(f"🔧 Smart Fixer - {mode.upper()} MODE")
        print(f"📁 Target: {folder}")
        print(f"📏 Min Size: {min_size_kb}KB")
        print(f"{'='*70}\n")

    def extract_url_from_json(self, file_path):
        """
        FIXED: Properly extract URL from DataForSEO JSON response
        """
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                
            # DataForSEO structure: tasks[0].result[0].items[0] OR tasks[0].data.start_url
            # Try multiple paths
            
            # Path 1: From data field (most reliable)
            url = data.get('data', {}).get('start_url')
            if url and 'http' in url:
                return url
                
            # Path 2: From result items
            result = data.get('result', [])
            if result and len(result) > 0:
                items = result[0].get('items', [])
                if items and len(items) > 0:
                    url = items[0].get('url')
                    if url and 'http' in url:
                        return url
            
            # Path 3: Check if entire file is just URL metadata (legacy format)
            if isinstance(data, dict) and 'url' in data:
                url = data.get('url')
                if url and 'http' in url:
                    return url
                    
            return None
            
        except json.JSONDecodeError:
            # Try reading as plain text (legacy markdown format)
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    # Look for URL pattern
                    url_match = re.search(r'https?://[^\s\n]+', content)
                    if url_match:
                        return url_match.group(0)
            except:
                pass
        except Exception as e:
            print(f"⚠️ URL extraction error for {file_path}: {e}")
            
        return None

    def clean_target_url(self, url):
        """Clean URL (remove .php from Empire Roofing, etc.)"""
        if "empireroofing.com.au" in url.lower():
            url = re.sub(r'\.php$', '', url.strip())
        return url.strip()

    def scan_and_prioritize(self):
        """Scan folder and identify targets for fixing"""
        targets = []
        all_files_data = []
        
        if not os.path.exists(self.base_output_folder):
            print(f"❌ Error: Folder '{self.base_output_folder}' not found!")
            return []

        print(f"🔍 Scanning for files < {self.min_size_kb}KB...")
        
        file_count = 0
        for root, dirs, files in os.walk(self.base_output_folder):
            # Only process organic results
            if "organic" not in root.lower():
                continue

            for file in files:
                if file.endswith(".md") and not file.startswith("_"):
                    file_path = os.path.join(root, file)
                    file_size = os.path.getsize(file_path) / 1024
                    file_count += 1

                    if file_size < self.min_size_kb:
                        url = self.extract_url_from_json(file_path)
                        
                        if url and "http" in url.lower():
                            final_url = self.clean_target_url(url)
                            
                            # Extract rank from filename
                            rg_match = re.search(r'_rg(\d+)', file)
                            r_grp = int(rg_match.group(1)) if rg_match else 0
                            
                            # Check if directory
                            is_directory = any(domain in final_url.lower() for domain in DIRECTORY_DOMAINS)
                            
                            # Classify issue
                            if is_directory:
                                issue_type = "Error (Directory)"
                                status = "Skipped"
                            elif r_grp <= 10:
                                issue_type = "CRITICAL (Top 10)"
                                status = "Pending"
                            else:
                                issue_type = f"Error (Low Rank: {r_grp})"
                                status = "Skipped"

                            row = {
                                'Issue': issue_type,
                                'suburb': os.path.basename(os.path.dirname(os.path.dirname(file_path))),
                                'rank_group': r_grp,
                                'url': final_url,
                                'actual_size': f"{file_size:.2f} KB",
                                'status': status,
                                'file_path': file_path
                            }
                            all_files_data.append(row)
                            
                            # Only add top 10 non-directories to targets
                            if issue_type == "CRITICAL (Top 10)":
                                targets.append(row)
        
        print(f"✅ Scanned {file_count} files")
        print(f"🎯 Found {len(targets)} high-priority targets (Top 10, non-directory)")
        print(f"⏭️ Skipped {len(all_files_data) - len(targets)} low-priority files")

        # Save report
        with open(self.report_csv, mode='w', newline='', encoding='utf-8') as csvfile:
            fields = ['Issue', 'suburb', 'rank_group', 'url', 'actual_size', 'status', 'file_path']
            writer = csv.DictWriter(csvfile, fieldnames=fields)
            writer.writeheader()
            writer.writerows(all_files_data)
        
        print(f"📊 Report saved: {self.report_csv}\n")
        
        return targets

    def build_api_settings(self, url):
        """Build API settings based on mode"""
        domain = re.sub(r'(https?://|www\.)', '', url).split('/')[0]
        
        base_settings = {
            "target": domain,
            "start_url": url,
            "url": url,
            "enable_content_parsing": True,
            "max_crawl_pages": 1,
            "proxy_country": "AU"
        }
        
        if self.mode == "heavy":
            # Full settings for original folder
            base_settings.update({
                "enable_javascript": True,
                "load_resources": True,
                "enable_browser_rendering": True,
                "enable_xhr": True,
                "disable_cookie_popup": True,
                "browser_preset": "desktop",
                "use_advanced_anti_robot_protection": True,
                "browser_wait_until": "fully_loaded",
                "wait_for_content_timeout": 30,
                "switch_pool": True
            })
        else:  # light
            # Minimal settings for retry folder
            base_settings.update({
                "enable_javascript": False,
                "enable_browser_rendering": False,
                "enable_xhr": False,
                "switch_pool": True
            })
        
        return base_settings

    def run_fixer(self):
        """Main execution flow"""
        targets = self.scan_and_prioritize()
        
        if not targets:
            print("🏁 No high-priority targets to rescue.")
            return

        import post_page
        import requests
        
        # Ensure smart_fix directory exists
        smart_fix_dir = "smart_fix"
        os.makedirs(smart_fix_dir, exist_ok=True)
        
        # Prepare tasks
        tasks_bucket = []
        metadata_map = {}
        
        for item in targets:
            tag = item['file_path']
            url = item['url']
            
            post_data = self.build_api_settings(url)
            post_data['tag'] = tag
            
            tasks_bucket.append(post_data)
            metadata_map[tag] = item
        
        # Process in batches
        batch_size = 100
        total_processed = 0
        
        for i in range(0, len(tasks_bucket), batch_size):
            batch = tasks_bucket[i:i + batch_size]
            batch_num = i//batch_size + 1
            
            print(f"\n{'='*70}")
            print(f"📡 Batch {batch_num} - Posting {len(batch)} tasks...")
            print(f"{'='*70}\n")
            
            # Post batch
            resp = post_page.post_onpage_task(
                self.headers, 
                batch, 
                output_dir=smart_fix_dir, 
                filename=f"fix_{self.mode}_batch_{i}.json"
            )
            
            if not resp or resp.status_code != 200:
                print(f"❌ Batch post failed")
                continue
            
            # Extract task IDs
            resp_data = resp.json()
            task_ids = []
            id_to_tag = {}
            
            for task in resp_data.get('tasks', []):
                tid = task.get('id')
                tag = task.get('data', {}).get('tag')
                if tid and tag:
                    task_ids.append(tid)
                    id_to_tag[tid] = tag
            
            # Build fetch payload
            fetch_payload = []
            for tid in task_ids:
                tag = id_to_tag.get(tid)
                meta = metadata_map.get(tag)
                if meta:
                    fetch_url = meta.get('url')
                    if fetch_url:
                        fetch_payload.append({"id": tid, "url": fetch_url})
            
            # Wait for processing
            wait_time = 120  # 2 minutes
            print(f"⏳ Waiting {wait_time}s for API processing...")
            time.sleep(wait_time)
            
            # Fetch results
            print(f"📥 Fetching results for {len(fetch_payload)} tasks...")
            
            endpoint = "https://api.dataforseo.com/v3/on_page/content_parsing"
            try:
                fetch_resp = requests.post(
                    endpoint, 
                    headers=self.headers, 
                    json=fetch_payload, 
                    timeout=120
                )
                
                if fetch_resp.status_code == 200:
                    res_json = fetch_resp.json()
                    
                    for task_res in res_json.get("tasks", []):
                        tag_path = task_res.get("data", {}).get("tag")
                        
                        if not tag_path:
                            tid = task_res.get("id")
                            tag_path = id_to_tag.get(tid)
                        
                        if not tag_path:
                            continue
                        
                        status_msg = task_res.get('status_message')
                        
                        if status_msg == 'Ok.':
                            try:
                                with open(tag_path, 'w', encoding='utf-8') as f:
                                    json.dump(task_res, f, indent=4)
                                
                                new_size = os.path.getsize(tag_path) / 1024
                                print(f"   ✅ Saved: {os.path.basename(tag_path)} ({new_size:.2f}KB)")
                                total_processed += 1
                            except Exception as e:
                                print(f"   ❌ Save Error: {e}")
                        else:
                            item = metadata_map.get(tag_path)
                            if item:
                                print(f"   ⚠️ API Error for {item['url']}: {status_msg}")
                else:
                    print(f"❌ Fetch failed: {fetch_resp.status_code}")
                    
            except Exception as e:
                print(f"❌ Fetch error: {e}")
        
        print(f"\n{'='*70}")
        print(f"🏁 FINISHED")
        print(f"✅ Successfully rescued: {total_processed}/{len(targets)} files")
        print(f"📊 Full report: {self.report_csv}")
        print(f"{'='*70}\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Unified Smart Fixer for both folders')
    parser.add_argument(
        '--folder', 
        default='parsed_content_markdowns',
        choices=['parsed_content_markdowns', 'parsed_content_markdowns2'],
        help='Target folder to fix'
    )
    parser.add_argument(
        '--mode',
        default='heavy',
        choices=['heavy', 'light'],
        help='API settings mode (heavy=full JS, light=switch pool only)'
    )
    parser.add_argument(
        '--min-size',
        type=int,
        default=5,
        help='Minimum file size in KB (default: 5)'
    )
    
    args = parser.parse_args()
    
    # Auto-select mode based on folder if not explicitly set
    if args.folder == 'parsed_content_markdowns2' and args.mode == 'heavy':
        print("ℹ️ Auto-switching to 'light' mode for parsed_content_markdowns2")
        args.mode = 'light'
    
    fixer = UnifiedSmartFixer(
        folder=args.folder,
        mode=args.mode,
        min_size_kb=args.min_size
    )
    fixer.run_fixer()