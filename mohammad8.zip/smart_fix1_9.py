import os, csv, re, json, time, base64
import asyncio
import aiohttp
import aiofiles
from concurrent.futures import ThreadPoolExecutor
from base import Helper
from datetime import datetime

# Import all API credentials from config
from config import USERNAME, PASSWORD, USERNAME1, PASSWORD1

# --- تنظیمات ---
MIN_SIZE_KB = 10 
BATCH_SIZE = 20  # Tasks per batch
WORKER_INTERVAL = 30  # Check for ready tasks every 30 seconds
MAX_PROCESSING_TIME = 900  # 15 minutes max wait per task

DIRECTORY_DOMAINS = [
    'hipages.com.au', 'yelp.com', 'yelp.com.au', 'yellowpages.com.au', 
    'truelocal.com.au', 'facebook.com', 'instagram.com', 'starofservice.com.au',
    'checkatrade.com', 'buy.nsw.gov.au', 'localsearch.com.au', 'au.nextdoor.com', 'www.oneflare.com.au'
]

API_CREDENTIALS = [
    {'username': USERNAME, 'password': PASSWORD},
    {'username': USERNAME1, 'password': PASSWORD1},
]

class TaskDatabase:
    """Simple JSON-based task tracking database"""
    def __init__(self, db_file="task_database.json"):
        self.db_file = db_file
        self.data = self._load()
    
    def _load(self):
        if os.path.exists(self.db_file):
            try:
                with open(self.db_file, 'r') as f:
                    return json.load(f)
            except:
                return {'pending': {}, 'completed': {}, 'failed': {}}
        return {'pending': {}, 'completed': {}, 'failed': {}}
    
    def _save(self):
        with open(self.db_file, 'w') as f:
            json.dump(self.data, f, indent=2)
    
    def add_pending_task(self, task_id, metadata):
        """Add a task to pending queue"""
        self.data['pending'][task_id] = {
            'metadata': metadata,
            'posted_at': datetime.now().isoformat(),
            'api_index': metadata.get('api_index')
        }
        self._save()
    
    def mark_completed(self, task_id):
        """Move task from pending to completed"""
        if task_id in self.data['pending']:
            self.data['completed'][task_id] = self.data['pending'].pop(task_id)
            self.data['completed'][task_id]['completed_at'] = datetime.now().isoformat()
            self._save()
    
    def mark_failed(self, task_id, error):
        """Move task from pending to failed"""
        if task_id in self.data['pending']:
            self.data['failed'][task_id] = self.data['pending'].pop(task_id)
            self.data['failed'][task_id]['failed_at'] = datetime.now().isoformat()
            self.data['failed'][task_id]['error'] = error
            self._save()
    
    def get_pending_by_api(self, api_index):
        """Get all pending tasks for a specific API"""
        return {
            tid: data for tid, data in self.data['pending'].items()
            if data.get('api_index') == api_index
        }
    
    def get_all_pending(self):
        """Get all pending tasks"""
        return self.data['pending']
    
    def get_stats(self):
        """Get current statistics"""
        return {
            'pending': len(self.data['pending']),
            'completed': len(self.data['completed']),
            'failed': len(self.data['failed'])
        }

class SmartFixer(Helper):
    def __init__(self):
        super().__init__(base_output_folder="parsed_content_markdowns")
        self.report_csv = os.path.join(self.base_output_folder, "_final_scan_report.csv")
        self.executor = ThreadPoolExecutor(max_workers=10)
        self.task_db = TaskDatabase()
        
        # Create headers for each API credential
        self.api_headers = self._setup_multiple_apis()
        self.api_locks = [asyncio.Lock() for _ in self.api_headers]
        self.api_stats = [{'posted': 0, 'fetched': 0, 'errors': 0} for _ in self.api_headers]
        
        self.successful_files = set()

    def _setup_multiple_apis(self):
        """Setup authentication headers for all API credentials"""
        headers_list = []
        print(f"🔐 Setting up {len(API_CREDENTIALS)} API accounts...")
        
        for i, cred in enumerate(API_CREDENTIALS):
            auth_str = f"{cred['username']}:{cred['password']}"
            token = base64.b64encode(auth_str.encode()).decode()
            headers = {
                'Authorization': f'Basic {token}',
                'Content-Type': 'application/json',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            headers_list.append(headers)
            print(f"   ✓ API #{i+1} configured")
        
        return headers_list

    def clean_target_url(self, url):
        """Clean Empire Roofing URLs"""
        if "empireroofing.com.au" in url.lower():
            return re.sub(r'\.php$', '', url.strip())
        return url.strip()

    async def process_file_async(self, file_path):
        """Process a single file asynchronously"""
        try:
            file_size = os.path.getsize(file_path) / 1024
            if file_size >= MIN_SIZE_KB:
                return None
                
            async with aiofiles.open(file_path, 'r', encoding='utf-8') as f:
                content = await f.read()
                data = json.loads(content)
                raw_url = data.get('data', {}).get('start_url')
            
            if "http" not in raw_url.lower():
                return None
                
            final_url = self.clean_target_url(raw_url)
            rg_match = re.search(r'_rg(\d+)', os.path.basename(file_path))
            r_grp = int(rg_match.group(1)) if rg_match else 0
            is_directory = any(domain in final_url.lower() for domain in DIRECTORY_DOMAINS)
            
            if is_directory:
                return None
            
            return {
                'rank_group': r_grp,
                'url': final_url,
                'file_path': file_path,
            }
        except:
            return None

    async def scan_files_async(self):
        """Scan all files asynchronously"""
        print(f"🔍 Step 1: Scanning files...")
        
        file_paths = []
        for root, dirs, files in os.walk(self.base_output_folder):
            if "organic" not in root.lower():
                continue
            for file in files:
                if file.endswith(".md") and not file.startswith("_"):
                    file_paths.append(os.path.join(root, file))
        
        tasks = [self.process_file_async(fp) for fp in file_paths]
        results = await asyncio.gather(*tasks)
        
        targets = [r for r in results if r is not None]
        
        print(f"✅ Found {len(targets)} targets from {len(file_paths)} files.")
        print(f"   - Top 10: {len([t for t in targets if t['rank_group'] <= 10])}")
        return targets

    async def post_batch_async(self, session, batch, api_index):
        """Post a batch and store task IDs in database"""
        import post_page
        
        headers = self.api_headers[api_index]
        
        try:
            loop = asyncio.get_event_loop()
            resp = await loop.run_in_executor(
                self.executor,
                lambda: post_page.post_onpage_task(
                    headers, batch, output_dir="smart_fix", 
                    filename=f"post_api{api_index}_{int(time.time())}.json"
                )
            )
            
            if not resp or resp.status_code != 200:
                print(f"❌ Batch post failed (API #{api_index + 1})")
                self.api_stats[api_index]['errors'] += 1
                return []
            
            resp_data = resp.json()
            posted_tasks = []
            
            for task in resp_data.get('tasks', []):
                task_id = task.get('id')
                tag = task.get('data', {}).get('tag')
                
                if task_id and tag:
                    # Store in database
                    self.task_db.add_pending_task(task_id, {
                        'tag': tag,
                        'api_index': api_index,
                        'batch_data': next((item for item in batch if item.get('tag') == tag), None)
                    })
                    posted_tasks.append(task_id)
            
            self.api_stats[api_index]['posted'] += len(posted_tasks)
            return posted_tasks
            
        except Exception as e:
            print(f"❌ Exception in post_batch (API #{api_index + 1}): {e}")
            self.api_stats[api_index]['errors'] += 1
            return []

    async def post_all_batches(self, targets):
        """Phase 1: Post all batches to DataForSEO"""
        print(f"\n{'='*60}")
        print(f"📤 PHASE 1: POSTING ALL BATCHES")
        print(f"{'='*60}\n")
        
        # Prepare batches
        tasks_bucket = []
        for item in targets:
            tag = item['file_path']
            url = item['url']
            
            post_data = {
                "target": re.sub(r'(https?://|www\.)', '', url).split('/')[0],
                "start_url": url,
                "url": url,
                "enable_content_parsing": True,
                "max_crawl_pages": 1,
                "enable_javascript": True,
                "switch_pool": False,
                "load_resources": False,
                "enable_browser_rendering": False,
                "enable_xhr": False,
                "disable_cookie_popup": False,
                "browser_preset": "desktop",
                "proxy_country": "AU",
                "use_advanced_anti_robot_protection": False,
                "browser_wait_until": "domcontentloaded",
                "wait_for_content_timeout": 60,
                "tag": tag
            }
            tasks_bucket.append(post_data)
        
        batches = [tasks_bucket[i:i + BATCH_SIZE] for i in range(0, len(tasks_bucket), BATCH_SIZE)]
        
        print(f"📦 Posting {len(batches)} batches ({len(targets)} total tasks)")
        print(f"⚡ Using {len(self.api_headers)} APIs in parallel\n")
        
        async with aiohttp.ClientSession() as session:
            num_apis = len(self.api_headers)
            total_posted = 0
            
            # Post batches in groups (parallel processing)
            for i in range(0, len(batches), num_apis):
                batch_group = batches[i:i + num_apis]
                
                # ✅ FIX: Properly assign API index using global batch index
                post_tasks = [
                    self.post_batch_async(session, batches[i + j], (i + j) % num_apis)
                    for j in range(len(batch_group))
                ]
                
                results = await asyncio.gather(*post_tasks)
                posted_count = sum(len(r) for r in results)
                total_posted += posted_count
                
                print(f"   ✅ Posted {posted_count} tasks (batch group {i//num_apis + 1})")
                print(f"      API distribution: {[(i + j) % num_apis + 1 for j in range(len(batch_group))]}")
                await asyncio.sleep(2)  # Small delay between groups
        
        stats = self.task_db.get_stats()
        print(f"\n📊 Posting Complete:")
        print(f"   Total posted: {total_posted}")
        print(f"   Pending in database: {stats['pending']}")
        self._print_api_stats()

    async def check_ready_tasks(self, session, api_index):
        """Check which tasks are ready for a specific API"""
        endpoint = "https://api.dataforseo.com/v3/on_page/tasks_ready"
        headers = self.api_headers[api_index]
        
        try:
            async with session.get(endpoint, headers=headers, timeout=aiohttp.ClientTimeout(total=30)) as response:
                if response.status == 200:
                    data = await response.json()
                    ready_ids = []
                    
                    for task in data.get('tasks', []):
                        result = task.get('result')
                        if result:
                            for item in result:
                                task_id = item.get('id')
                                if task_id:
                                    ready_ids.append(task_id)
                    
                    return ready_ids
                return []
        except Exception as e:
            print(f"   ⚠️ Error checking ready tasks (API #{api_index + 1}): {e}")
            return []

    async def fetch_and_save_task(self, session, task_id, task_data, api_index):
        """Fetch results for a ready task and save"""
        endpoint = "https://api.dataforseo.com/v3/on_page/content_parsing"
        headers = self.api_headers[api_index]
        
        tag = task_data['metadata']['tag']
        batch_data = task_data['metadata'].get('batch_data', {})
        url = batch_data.get('url', '')
        
        fetch_payload = [{"id": task_id, "url": url}]
        
        try:
            async with session.post(endpoint, headers=headers, json=fetch_payload, 
                                  timeout=aiohttp.ClientTimeout(total=180)) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    for task_res in data.get("tasks", []):
                        status_msg = task_res.get('status_message')
                        
                        if status_msg == 'Ok.':
                            # Save result
                            async with aiofiles.open(tag, 'w', encoding='utf-8') as f:
                                await f.write(json.dumps(task_res, indent=4))
                            
                            size = os.path.getsize(tag) / 1024
                            
                            if size >= MIN_SIZE_KB:
                                self.successful_files.add(tag)
                                self.task_db.mark_completed(task_id)
                                self.api_stats[api_index]['fetched'] += 1
                                return True, size
                            else:
                                self.task_db.mark_failed(task_id, f"File too small: {size:.2f} KB")
                                return False, size
                        else:
                            self.task_db.mark_failed(task_id, status_msg)
                            return False, 0
                else:
                    self.task_db.mark_failed(task_id, f"HTTP {response.status}")
                    return False, 0
        except Exception as e:
            self.task_db.mark_failed(task_id, str(e))
            return False, 0

    async def worker_process_api(self, session, api_index, worker_id):
        """Worker process for a specific API"""
        print(f"🔧 Worker #{worker_id} (API #{api_index + 1}) started")
        
        processed_count = 0
        
        while True:
            # Check if there are any pending tasks for this API
            pending_tasks = self.task_db.get_pending_by_api(api_index)
            
            if not pending_tasks:
                print(f"   ✅ Worker #{worker_id} (API #{api_index + 1}): No more pending tasks")
                break
            
            # Check which tasks are ready
            async with self.api_locks[api_index]:
                ready_task_ids = await self.check_ready_tasks(session, api_index)
                await asyncio.sleep(1)
            
            # Process ready tasks
            ready_to_process = [tid for tid in ready_task_ids if tid in pending_tasks]
            
            if ready_to_process:
                print(f"   📥 Worker #{worker_id} (API #{api_index + 1}): Found {len(ready_to_process)} ready tasks")
                
                # Fetch and save each ready task
                for task_id in ready_to_process:
                    task_data = pending_tasks[task_id]
                    
                    async with self.api_locks[api_index]:
                        success, size = await self.fetch_and_save_task(session, task_id, task_data, api_index)
                        await asyncio.sleep(1)
                    
                    if success:
                        processed_count += 1
                        print(f"      ✨ Success: {size:.2f} KB")
                    else:
                        print(f"      ⚠️ Failed: {task_data['metadata']['tag']}")
            else:
                print(f"   ⏳ Worker #{worker_id} (API #{api_index + 1}): {len(pending_tasks)} pending, 0 ready. Waiting...")
            
            # Wait before next check
            await asyncio.sleep(WORKER_INTERVAL)
        
        return processed_count

    async def retrieve_all_results(self):
        """Phase 2: Worker processes to retrieve all results"""
        print(f"\n{'='*60}")
        print(f"📥 PHASE 2: RETRIEVING RESULTS (WORKER PROCESSES)")
        print(f"{'='*60}\n")
        
        stats = self.task_db.get_stats()
        print(f"📊 Starting retrieval:")
        print(f"   Pending tasks: {stats['pending']}")
        print(f"   Worker interval: {WORKER_INTERVAL}s")
        print(f"   Max processing time: {MAX_PROCESSING_TIME}s per task\n")
        
        async with aiohttp.ClientSession() as session:
            num_apis = len(self.api_headers)
            
            # Start worker for each API
            workers = [
                self.worker_process_api(session, i, i + 1)
                for i in range(num_apis)
            ]
            
            # Run all workers concurrently
            results = await asyncio.gather(*workers)
            total_retrieved = sum(results)
        
        final_stats = self.task_db.get_stats()
        print(f"\n📊 Retrieval Complete:")
        print(f"   Retrieved: {total_retrieved}")
        print(f"   Completed: {final_stats['completed']}")
        print(f"   Failed: {final_stats['failed']}")
        print(f"   Still pending: {final_stats['pending']}")

    def _print_api_stats(self):
        """Print API usage statistics"""
        print("📈 API Usage Statistics:")
        for i, stats in enumerate(self.api_stats):
            print(f"   API #{i+1}: Posted={stats['posted']}, Fetched={stats['fetched']}, Errors={stats['errors']}")

    async def run_mega_fixer_async(self):
        """Main orchestrator - 2 phase approach"""
        print("=" * 60)
        print("🚀 2-PHASE BATCH PROCESSOR STARTED")
        print("=" * 60)
        
        # Step 1: Scan files
        targets = await self.scan_files_async()
        
        if not targets:
            print("🏁 No targets to process.")
            return
        
        # Phase 1: Post all batches
        await self.post_all_batches(targets)
        
        # Phase 2: Retrieve all results
        await self.retrieve_all_results()
        
        # Final summary
        stats = self.task_db.get_stats()
        print("\n" + "=" * 60)
        print(f"🏁 PROCESSING COMPLETE")
        print("=" * 60)
        print(f"✅ Completed: {stats['completed']}")
        print(f"❌ Failed: {stats['failed']}")
        print(f"⏳ Still pending: {stats['pending']}")
        
        success_rate = (stats['completed'] / len(targets) * 100) if targets else 0
        print(f"📊 Success Rate: {success_rate:.1f}%")
        print("=" * 60)
        self._print_api_stats()

    def run_mega_fixer(self):
        """Sync wrapper for async execution"""
        asyncio.run(self.run_mega_fixer_async())

if __name__ == "__main__":
    SmartFixer().run_mega_fixer()